# Peach Quest — Terms of Service (Draft for Legal Review)
Presented by **CLASTAD**  
Last Updated: November 2026

> **Note:** This document is a draft prepared for legal review prior to public release. Replace placeholder fields with verified legal details before publishing.

## 1. Permitted Use of Peach Quest
Subject to your compliance with these Terms, CLASTAD grants you a personal, non-exclusive, non-transferable, revocable licence to download and play Peach Quest for personal, non-commercial entertainment on compatible Android devices.

## 2. Parental and Guardian Guidance
If a player is under the age required to enter into legal agreements in their jurisdiction, a parent or legal guardian must review and accept these Terms on their behalf. Nothing in these Terms waives any mandatory consumer or child-protection rights that cannot legally be waived under applicable law.

## 3. Acceptable Behaviour
You agree to use Peach Quest only for lawful, personal play and not to:
- Reverse engineer, decompile, or tamper with the application except where permitted by applicable law.
- Copy, modify, resell, or redistribute Peach Quest or its artwork, sound, or code without prior written permission from CLASTAD.

## 4. Intellectual Property and Branding
All original game code, level designs, Peach Garden artwork, synthesized audio, and the "Peach Quest" and "CLASTAD" names and logos displayed in the app remain the property of CLASTAD or their respective licensors. Display of the Peach Quest name or logo does not constitute a claim of trademark registration unless separately registered.

## 5. Availability and Updates
Peach Quest is provided as an offline game. CLASTAD may release updates, bug fixes, or balance adjustments from time to time, though no ongoing online service or cloud storage is promised in this release.

## 6. Disclaimer of Warranties
To the maximum extent permitted by applicable law, Peach Quest is provided "as is" and "as available" without warranties of any kind. Where local consumer protection laws imply non-excludable warranties, those statutory rights remain unaffected.

## 7. Limitation of Liability
To the extent permitted by applicable law, CLASTAD shall not be liable for indirect or incidental damages arising from use of the app, including loss of local save data if a device is reset or uninstalled. Nothing in these Terms limits liability where such limitation is prohibited by law.

## 8. Changes to These Terms
CLASTAD may update these Terms in future app releases. Material changes will be presented clearly inside the updated application.

## 9. Applicable Law and Jurisdiction
These Terms shall be governed by the laws of `[APPLICABLE_COUNTRY_OR_STATE_TO_BE_CONFIRMED_BY_CLASTAD]`, subject to mandatory consumer protection laws in your country of residence.

## 10. Contact and Support
Developer: **CLASTAD**  
Support Contact: `[DEVELOPER_CONTACT_EMAIL]`
