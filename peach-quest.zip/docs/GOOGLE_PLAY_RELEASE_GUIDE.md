# Peach Quest — Google Play Release Checklist, Testing Report & Build Guide
Presented by **CLASTAD**

> **Important Compliance Note:** This document prepares Peach Quest for submission review. It does **not** claim automatic approval, Google Play Families certification, or trademark registration; those must be confirmed through official review and legal clearance prior to public launch.

---

## 1. Android Build & APK / AAB Instructions

### Prerequisites
- Android SDK Platform 36 (`compileSdk = 36`, `minSdk = 24`, `targetSdk = 36`)
- JDK 11+
- Gradle (configured via system `gradle` or Android Studio)

### Build Commands
1. **Run Unit & Robolectric Tests:**
   ```bash
   gradle :app:testDebugUnitTest
   ```
2. **Build Debug APK (for physical device testing on 2 GB / 3 GB / 4 GB RAM devices):**
   ```bash
   gradle :app:assembleDebug
   ```
   Output: `app/build/outputs/apk/debug/app-debug.apk`
3. **Build Release AAB (Google Play upload):**
   Set signing environment variables (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`), then run:
   ```bash
   gradle :app:bundleRelease
   ```
   Output: `app/build/outputs/bundle/release/app-release.aab`

---

## 2. Google Play Store Listing & Metadata Prep

- **App Name:** `Peach Quest` (11 characters, no emojis, no ALL CAPS, no buzzwords)
- **Developer Name:** `CLASTAD`
- **Application ID:** `com.aistudio.peachquest.kxmpqr` (replace or finalize unique ID before Play Console creation)
- **Version:** `versionCode = 1`, `versionName = "1.0"`
- **Permissions Declaration:** Only normal install-time permissions (`INTERNET`, `ACCESS_NETWORK_STATE`, `VIBRATE`) declared in `AndroidManifest.xml` — zero dangerous runtime permissions.
- **Data Safety Declaration (Draft Basis):**
  - Declare Google Sign-In account identifiers (UID, display name, email) and app progress data synced to Cloud Firestore (`users/{userId}`). Zero ads, zero ad IDs, zero third-party analytics.
- **Advertising Declaration:** **No, my app does not contain ads.**
- **Privacy Policy URL Requirement:** Host `docs/privacy-policy.html` on an active, publicly accessible, non-editable HTTPS webpage and replace `[DEVELOPER_CONTACT_EMAIL]` & `[DEVELOPER_ADDRESS_PLACEHOLDER]` first.
- **Terms of Service & Legal Review:** Have legal counsel review the draft Terms (`com.example.legal.LegalContent.termsOfServiceText`) and fill `[APPLICABLE_COUNTRY_OR_STATE_TO_BE_CONFIRMED_BY_CLASTAD]`.
- **Target Audience & Content Rating:** Complete the Play Console Target Audience questionnaire and IARC Content Rating questionnaire accurately; if targeting children/Families, confirm all Families Policy requirements prior to submission.
- **Store Screenshots Needed:** Capture physical-device screenshots of:
  1. Opening / Auth & Home Lobby screen with Peach Quest & CLASTAD branding
  2. Chapter 1–2 Match-3 Board with Interactive Tutorial & Golden Charge
  3. Chapter 3–6 Obstacles (Ice, Vines, Garden Crates) & 24 Fruits
  4. Peach Garden & Fruit Vault (Skins & Achievements)
  5. Clean 4-Section Settings & Accessibility options

### Suggested Play Store Short Description (Draft)
> Vibrant fruit-matching puzzle game with 24 fruits, 30 levels & Peach Garden.

### Suggested Play Store Full Description (Draft)
> Welcome to Peach Quest, a vibrant, joyful fruit-matching puzzle game by CLASTAD!
>
> Swap and match 24 illustrated fruits across 30 handcrafted levels spanning six colorful orchard chapters.
>
> • Golden Charge Power-Ups: Match 4 or more fruits to create a Golden Pineapple and unleash a sparkling Golden Wave!
> • Fun Orchard Obstacles: Melt Ice tiles, clear tangled Vines, and break wooden Garden Crates.
> • Daily Rewards & Fruit Vault: Build a 7-day reward streak, earn achievements, and unlock glossy Fruit Styles.
> • Grow Your Peach Garden: Every 5 completed levels unlocks a new decorative section in your garden!
> • Google Cloud Sync: Sign in with Google to back up your stars, high scores, and unlocked rewards.

---

## 3. QA & Testing Checklist (20-Point Verification)

1. **First Launch:** Unchecked legal checkboxes; Continue button stays disabled until both are checked.
2. **Loading Screen:** Displays Peach Quest logo, real loading steps, and "A game by CLASTAD" at bottom without hanging.
3. **Home Screen Navigation:** Play, All 30 Levels, Peach Garden, Customise, and Settings all reachable with 48dp+ touch targets.
4. **Fruit Swapping:** Both swipe gestures and tap-then-tap swap adjacent fruits smoothly; invalid swaps bounce back.
5. **Match Detection:** Horizontal, vertical, and L/T matches of 3+ clear cleanly.
6. **Cascading Matches:** Gravity refills board and triggers chained combos with ascending multiplier.
7. **Golden Charge:** 4+ match creates Golden Pineapple; tap/swap releases Golden Wave clearing fruits & obstacles.
8. **Level Objectives:** Score, Fruit Collection, Ice, Vines, Crate, and Golden Wave counters track accurately.
9. **Move Limits:** Valid swaps decrement moves; invalid swaps do not.
10. **Victory Screen:** Triggers immediately when all objectives are met; awards remaining-move bonus.
11. **Failure Screen:** Triggers cleanly when moves reach 0 without completing objectives; offers Retry without manipulative prompts.
12. **Three-Star Scoring:** Calculates 1–3 stars from level thresholds and keeps highest score/stars.
13. **Level Unlocking:** Completing Level N unlocks Level N+1 up to Level 30.
14. **Local Progress Saving:** Persisted via `LocalStorageRepository` in private `SharedPreferences`.
15. **Restart & Resume:** Mid-level board state saves automatically on Pause/background and resumes cleanly from Home.
16. **Offline Operation:** Zero network permissions or SDKs; 100% functional in Airplane Mode.
17. **Sound Controls:** Independent Music, SFX, and Fruit Voices volume sliders and enable switches.
18. **Customisation:** Live preview for Themes, Animations, Music, and Voices.
19. **Privacy & Terms Screens:** Accessible from both First Launch and Settings.
20. **Low-RAM Performance:** Auto-detects low-RAM devices (`isLowRamDevice` / `memoryClass <= 192`), uses `drawable-nodpi` scaled assets, procedural PCM SFX, and reduces particle effects automatically.
