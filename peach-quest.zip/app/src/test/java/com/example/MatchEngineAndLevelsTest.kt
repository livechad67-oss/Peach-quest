package com.example

import com.example.game.BoardState
import com.example.game.MatchEngine
import com.example.levels.LevelRepository
import com.example.levels.OrchardCatalog
import com.example.model.BoosterType
import com.example.model.Chapter
import com.example.model.FruitType
import com.example.model.ObjectiveKind
import com.example.model.ObstacleType
import com.example.model.SpecialKind
import com.example.model.TileCell
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MatchEngineAndLevelsTest {

    @Test
    fun `all 30 levels exist across 4 worlds and cover all 24 collectible fruits`() {
        assertEquals(4, Chapter.entries.size)
        assertEquals(30, LevelRepository.allLevels.size)
        assertEquals(24, FruitType.collectibleFruits.size)
        val engine = MatchEngine(Random(42))
        val coveredFruits = mutableSetOf<FruitType>()

        LevelRepository.allLevels.forEachIndexed { idx, level ->
            assertEquals(idx + 1, level.levelNumber)
            assertTrue("Level ${level.levelNumber} must have positive moves", level.maxMoves > 0)
            assertTrue("Level ${level.levelNumber} must have at least 1 objective", level.objectives.isNotEmpty())
            assertTrue(
                "Star thresholds must ascend in level ${level.levelNumber}",
                level.starThresholds.first <= level.starThresholds.second &&
                    level.starThresholds.second <= level.starThresholds.third
            )

            coveredFruits.addAll(level.availableFruits)

            level.objectives.filter { it.kind == ObjectiveKind.COLLECT_FRUIT }.forEach { obj ->
                assertTrue(
                    "Level ${level.levelNumber} asks for ${obj.fruitType} which is not in availableFruits",
                    obj.fruitType in level.availableFruits
                )
            }

            level.objectives.filter { it.kind == ObjectiveKind.CLEAR_OBSTACLE }.forEach { obj ->
                val placedCount = level.initialObstacles.values.count { it.first == obj.obstacleType }
                assertEquals(
                    "Level ${level.levelNumber} obstacle objective ${obj.obstacleType} count mismatch",
                    placedCount,
                    obj.targetAmount
                )
            }

            val board = engine.createPlayableBoard(level)
            assertEquals(level.rows * level.cols, board.cells.size)
            assertTrue("Level ${level.levelNumber} initial board should have no pre-matches", engine.findMatches(board).isEmpty())
            assertNotNull("Level ${level.levelNumber} initial board must have at least one valid move", engine.findValidMove(board))
        }

        // Confirm every one of the 24 fruits appears in the campaign!
        assertEquals(FruitType.collectibleFruits.toSet(), coveredFruits)
        assertEquals(6, OrchardCatalog.achievements.size)
        assertEquals(7, OrchardCatalog.dailyRewards.size)
    }

    @Test
    fun `4-match creates Lightning, L-shape creates Bomb, 5-match creates Rainbow and triggers work`() {
        val engine = MatchEngine(Random(7))

        // 4-match horizontal -> LIGHTNING_COL
        val cells4 = MutableList(36) { idx ->
            val r = idx / 6
            val c = idx % 6
            val fruit = when {
                r == 2 && c in 0..3 -> FruitType.PEACH
                r == 1 && c == 2 -> FruitType.STRAWBERRY
                else -> if ((r + c) % 2 == 0) FruitType.BLUEBERRY else FruitType.GRAPES
            }
            val obs = if (r == 2 && c == 1) ObstacleType.ICE else ObstacleType.NONE
            TileCell(idx + 1L, r, c, fruit, obs, if (obs == ObstacleType.ICE) 1 else 0)
        }
        val board4 = BoardState(6, 6, cells4)
        val matches4 = engine.findMatches(board4)
        assertEquals(1, matches4.size)
        assertEquals(SpecialKind.LIGHTNING_COL, matches4.first().spawnSpecial)

        val res4 = engine.resolveMatchesStep(board4, matches4, comboStep = 1)
        assertEquals(1, res4.createdGoldenCount)
        assertEquals(1, res4.clearedObstacles[ObstacleType.ICE])
        assertEquals(4, res4.collectedFruits[FruitType.PEACH])

        val lightningCell = res4.boardAfterClear.cells.firstOrNull { it.special == SpecialKind.LIGHTNING_COL }
        assertNotNull(lightningCell)
        val zap = engine.triggerSpecialCell(res4.boardAfterClear, lightningCell!!.row, lightningCell.col)
        assertTrue(SpecialKind.LIGHTNING_COL in zap.triggeredSpecialKinds)
        assertEquals(6, zap.clearedIndices.size)

        // L-shape match -> BOMB
        val cellsL = MutableList(36) { idx ->
            val r = idx / 6
            val c = idx % 6
            val isL = (r == 2 && c in 1..3) || (c == 1 && r in 2..4)
            val fruit = if (isL) FruitType.STRAWBERRY else if ((r + c) % 2 == 0) FruitType.BLUEBERRY else FruitType.BANANA
            TileCell(idx + 1L, r, c, fruit)
        }
        val boardL = BoardState(6, 6, cellsL)
        val matchesL = engine.findMatches(boardL)
        assertEquals(1, matchesL.size)
        assertEquals(SpecialKind.BOMB, matchesL.first().spawnSpecial)

        // 5-in-a-row -> RAINBOW
        val cells5 = MutableList(36) { idx ->
            val r = idx / 6
            val c = idx % 6
            val fruit = if (r == 3 && c in 0..4) FruitType.GRAPES else if ((r + c) % 2 == 0) FruitType.PEACH else FruitType.ORANGE
            TileCell(idx + 1L, r, c, fruit)
        }
        val board5 = BoardState(6, 6, cells5)
        val matches5 = engine.findMatches(board5)
        assertEquals(1, matches5.size)
        assertEquals(SpecialKind.RAINBOW, matches5.first().spawnSpecial)

        // Preserved Magic Peach / Golden Pineapple wave + Special+Special combo
        val comboBoard = board5.withReplaced(
            mapOf(
                board5.indexOf(1, 1) to board5.get(1, 1).copy(special = SpecialKind.BOMB),
                board5.indexOf(1, 2) to board5.get(1, 2).copy(special = SpecialKind.LIGHTNING_ROW)
            )
        )
        val comboRes = engine.triggerSpecialCell(comboBoard, 1, 1, swappedWithCell = comboBoard.get(1, 2))
        assertTrue(SpecialKind.MAGIC_PEACH in comboRes.triggeredSpecialKinds)
        assertTrue(comboRes.clearedIndices.size >= 16)

        // Boosters work for all 4 types
        BoosterType.entries.forEach { booster ->
            val bRes = engine.applyBooster(board5, 2, 2, booster)
            assertTrue("Booster $booster must clear tiles", bRes.clearedIndices.isNotEmpty())
            assertTrue("Booster $booster must award points", bRes.pointsAwarded > 0)
        }
    }

    @Test
    fun `gravity refills empty slots cleanly and deadlock board reshuffles into valid move`() {
        val engine = MatchEngine(Random(99))
        val level1 = LevelRepository.getLevel(1)

        val board = engine.createPlayableBoard(level1)
        val cleared = board.withReplaced(
            mapOf(
                board.indexOf(2, 2) to board.get(2, 2).copy(fruit = null),
                board.indexOf(3, 2) to board.get(3, 2).copy(fruit = null),
                board.indexOf(4, 2) to board.get(4, 2).copy(fruit = null)
            )
        )
        val refilledWithDistances = engine.applyGravityAndRefillWithDistances(cleared, level1.availableFruits)
        assertFalse(refilledWithDistances.board.cells.any { it.fruit == null })
        assertTrue(
            "Falling and spawned tiles in cleared column must report positive fall distances",
            refilledWithDistances.fallRowsByCellId.values.any { it >= 3 }
        )

        val refilled = engine.applyGravityAndRefill(cleared, level1.availableFruits)
        assertFalse(refilled.cells.any { it.fruit == null })

        val shuffled = engine.shuffleBoard(refilled, level1.availableFruits)
        assertNotNull(engine.findValidMove(shuffled))
        assertTrue(engine.findMatches(shuffled).isEmpty())
    }

    @Test
    fun `shaped voidCells remain empty and clearing adjacent cells spreads water stream`() {
        val engine = MatchEngine(Random(2026))
        val level4 = LevelRepository.getLevel(4)
        assertTrue("Level 4 should define shaped corner cutouts", level4.voidCells.isNotEmpty())

        val board = engine.createPlayableBoard(level4)
        level4.voidCells.forEach { (vr, vc) ->
            val cell = board.get(vr, vc)
            assertTrue("Void cell ($vr,$vc) must stay void", cell.isVoid)
            assertEquals("Void cell ($vr,$vc) must have no fruit", null, cell.fruit)
        }

        // Seed water at (1,1) and clear an adjacent match at (1,2),(1,3),(1,4) -> water spreads into (1,2),(1,3),(1,4)
        val seededBoard = board.withReplaced(
            mapOf(
                board.indexOf(1, 1) to board.get(1, 1).copy(isWatered = true, isVoid = false, fruit = FruitType.BLUEBERRY, obstacle = ObstacleType.NONE, obstacleHp = 0),
                board.indexOf(1, 2) to board.get(1, 2).copy(isWatered = false, isVoid = false, fruit = FruitType.PEACH, obstacle = ObstacleType.NONE, obstacleHp = 0),
                board.indexOf(1, 3) to board.get(1, 3).copy(isWatered = false, isVoid = false, fruit = FruitType.PEACH, obstacle = ObstacleType.NONE, obstacleHp = 0),
                board.indexOf(1, 4) to board.get(1, 4).copy(isWatered = false, isVoid = false, fruit = FruitType.PEACH, obstacle = ObstacleType.NONE, obstacleHp = 0)
            )
        )
        val matchGroup = com.example.game.MatchGroup(
            indices = setOf(seededBoard.indexOf(1, 2), seededBoard.indexOf(1, 3), seededBoard.indexOf(1, 4)),
            spawnAtIndex = null
        )
        val cleared = engine.resolveMatchesStep(
            board = seededBoard,
            matches = listOf(matchGroup),
            comboStep = 1
        )
        assertTrue(cleared.boardAfterClear.get(1, 2).isWatered)
        assertTrue(cleared.boardAfterClear.get(1, 3).isWatered)
        assertTrue(cleared.boardAfterClear.get(1, 4).isWatered)
    }
}
