package com.example

import android.content.Context
import android.os.Looper
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.longClick
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.test.core.app.ApplicationProvider
import com.example.game.MatchEngine
import com.example.levels.LevelRepository
import com.example.model.AppSettings
import com.example.model.BoosterType
import com.example.model.DeviceTelemetrySummary
import com.example.model.FruitSkin
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.LevelResult
import com.example.model.ObstacleType
import com.example.model.PlayerProgress
import com.example.model.SavedBoardSnapshot
import com.example.model.SpecialKind
import com.example.model.TileCell
import com.example.model.UsernameValidation
import com.example.model.UsernameValidator
import com.example.storage.LocalStorageRepository
import com.example.ui.GamePhase
import com.example.ui.GameUiState
import com.example.ui.OwnerAuthState
import com.example.ui.PeachQuestViewModel
import com.example.ui.screens.FruitVaultScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LevelMapScreen
import com.example.ui.screens.OwnerDashboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.PeachQuestTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.time.Duration
import kotlin.random.Random

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name and developer credit reflect Peach Quest and From CLASTAD`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Peach Quest", context.getString(R.string.app_name))
        assertEquals("From CLASTAD", context.getString(R.string.developer_credit))
    }

    @Test
    fun `username validator enforces friendly 3 to 18 char display names`() {
        assertTrue(UsernameValidator.validate("ab") is UsernameValidation.Invalid)
        assertTrue(UsernameValidator.validate("   ") is UsernameValidation.Invalid)
        assertTrue(UsernameValidator.validate("1234567890123456789") is UsernameValidation.Invalid)
        assertTrue(UsernameValidator.validate("Player@1") is UsernameValidation.Invalid)
        assertTrue(UsernameValidator.validate("Admin") is UsernameValidation.Invalid)
        assertTrue(UsernameValidator.validate("CLASTAD") is UsernameValidation.Invalid)
        assertTrue(UsernameValidator.validate("PeachQuest") is UsernameValidation.Invalid)

        val valid = UsernameValidator.validate("  Sunny_Peach  ")
        assertTrue(valid is UsernameValidation.Valid)
        assertEquals("Sunny_Peach", (valid as UsernameValidation.Valid).normalized)
    }

    @Test
    fun `local storage saves and restores username progress boosters specials settings telemetry and wipe`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = LocalStorageRepository(context)

        val progress = PlayerProgress(
            playerUsername = "DewdropFox",
            legalAccepted = true,
            tutorialCompleted = true,
            highestUnlockedLevel = 6,
            levelResults = mapOf(
                1 to LevelResult(1, 3, 2500, bestCombo = 4),
                5 to LevelResult(5, 2, 3400, bestCombo = 3)
            ),
            dailyStreak = 3,
            lastDailyClaimDay = 20415,
            unlockedFruitSkins = listOf(FruitSkin.CLASSIC.id, FruitSkin.CANDY_GLAZE.id),
            selectedFruitSkin = FruitSkin.CANDY_GLAZE.id,
            unlockedAchievements = listOf("first_harvest", "combo_master"),
            boosterInventory = mapOf(
                BoosterType.RAINBOW to 4,
                BoosterType.BOMB to 3,
                BoosterType.LIGHTNING to 5,
                BoosterType.MAGIC_PEACH to 2
            ),
            seenMechanics = setOf("lightning", "bomb"),
            activeSnapshot = SavedBoardSnapshot(
                levelNumber = 6,
                rows = 6,
                cols = 6,
                movesRemaining = 15,
                score = 420,
                collectedFruits = mapOf(FruitType.PEACH to 4),
                clearedObstacles = mapOf(ObstacleType.ICE to 2),
                goldenWavesTriggered = 1,
                cells = List(36) { i ->
                    TileCell(
                        id = i + 1L,
                        row = i / 6,
                        col = i % 6,
                        fruit = FruitType.PEACH,
                        special = if (i == 0) SpecialKind.BOMB else SpecialKind.NONE
                    )
                }
            )
        )
        repo.saveProgress(progress)

        val settings = AppSettings(
            masterVolume = 0.7f,
            musicVolume = 0.0f,
            sfxVolume = 0.9f,
            muted = false,
            hapticEnabled = false,
            animationsEnabled = true,
            notificationsEnabled = true,
            colorblindSymbols = true,
            analyticsConsent = true,
            graphicsQuality = GraphicsQuality.LOW_RAM
        )
        repo.saveSettings(settings)

        val telemetry = DeviceTelemetrySummary(
            firstOpenTimestampMs = 1_700_000_000_000L,
            sessionCount = 4,
            totalSessionDurationSec = 360L,
            levelStarts = mapOf(1 to 3),
            levelCompletes = mapOf(1 to 2),
            levelFailures = mapOf(1 to 1),
            avgFpsEstimate = 58.5f,
            nonFatalErrorCount = 0
        )
        repo.saveDeviceTelemetry(telemetry)

        val loadedProgress = repo.loadProgress()
        val loadedSettings = repo.loadSettings()
        val loadedTelemetry = repo.loadDeviceTelemetry()

        assertEquals("DewdropFox", loadedProgress.playerUsername)
        assertTrue(loadedProgress.legalAccepted)
        assertTrue(loadedProgress.tutorialCompleted)
        assertEquals(6, loadedProgress.highestUnlockedLevel)
        assertEquals(3, loadedProgress.levelResults[1]?.stars)
        assertEquals(2500, loadedProgress.levelResults[1]?.highScore)
        assertEquals(4, loadedProgress.levelResults[1]?.bestCombo)
        assertEquals(3, loadedProgress.dailyStreak)
        assertEquals(FruitSkin.CANDY_GLAZE.id, loadedProgress.selectedFruitSkin)
        assertTrue("combo_master" in loadedProgress.unlockedAchievements)
        assertEquals(4, loadedProgress.boosterInventory[BoosterType.RAINBOW])
        assertEquals(5, loadedProgress.boosterInventory[BoosterType.LIGHTNING])
        assertTrue("lightning" in loadedProgress.seenMechanics)
        assertNotNull(loadedProgress.activeSnapshot)
        assertEquals(15, loadedProgress.activeSnapshot?.movesRemaining)
        assertEquals(SpecialKind.BOMB, loadedProgress.activeSnapshot?.cells?.first()?.special)

        assertFalse(loadedSettings.isMusicOn)
        assertTrue(loadedSettings.isSfxOn)
        assertFalse(loadedSettings.hapticEnabled)
        assertTrue(loadedSettings.colorblindSymbols)
        assertTrue(loadedSettings.analyticsConsent)

        assertEquals(4, loadedTelemetry.sessionCount)
        assertEquals(58.5f, loadedTelemetry.avgFpsEstimate, 0.01f)
        assertEquals(3, loadedTelemetry.levelStarts[1])

        val afterReset = repo.resetProgressKeepLegal(true, "DewdropFox")
        assertEquals("DewdropFox", afterReset.playerUsername)
        assertEquals(1, afterReset.highestUnlockedLevel)
        assertTrue(afterReset.levelResults.isEmpty())

        repo.wipeAllLocalPlayerData()
        val wiped = repo.loadProgress()
        assertEquals("", wiped.playerUsername)
        assertFalse(wiped.legalAccepted)
    }

    @Test
    fun `4-screen onboarding Welcome, Username, Garden Reveal, and Home work end-to-end`() {
        // Screen 1: Welcome Loading has Peach Quest logo + From CLASTAD and NO skip button
        composeTestRule.onNodeWithTag("loading_logo").assertIsDisplayed()
        composeTestRule.onNodeWithTag("loading_clastad_credit").assertIsDisplayed()
        composeTestRule.onNodeWithTag("loading_skip_button").assertDoesNotExist()

        repeat(28) {
            Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(180))
            val onOnboarding = runCatching {
                composeTestRule.onNodeWithTag("username_input").assertExists()
                true
            }.getOrDefault(false)
            if (onOnboarding) return@repeat
        }
        composeTestRule.waitForIdle()

        // Screen 2: "What should we call you?" + "Enter your username" + "LET'S PLAY!"
        composeTestRule.onNodeWithText("What should we call you?").assertIsDisplayed()
        composeTestRule.onNodeWithTag("onboarding_continue_button").performScrollTo()
        composeTestRule.onNodeWithTag("onboarding_continue_button").assertIsNotEnabled()

        composeTestRule.onNodeWithTag("username_input").performScrollTo()
        composeTestRule.onNodeWithTag("username_input").performTextInput("BerryBud")
        composeTestRule.onNodeWithTag("onboarding_legal_checkbox").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("onboarding_continue_button").performScrollTo()
        composeTestRule.onNodeWithTag("onboarding_continue_button").assertIsEnabled()

        // Blocked username validation
        composeTestRule.onNodeWithTag("username_input").performScrollTo()
        composeTestRule.onNodeWithTag("username_input").performTextClearance()
        composeTestRule.onNodeWithTag("username_input").performTextInput("peachquest")
        composeTestRule.onNodeWithTag("onboarding_continue_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("onboarding_error_banner").performScrollTo().assertIsDisplayed()

        // Submit valid username -> Screen 3: Garden Reveal!
        composeTestRule.onNodeWithTag("username_input").performScrollTo()
        composeTestRule.onNodeWithTag("username_input").performTextClearance()
        composeTestRule.onNodeWithTag("username_input").performTextInput("SunnyPeach")
        composeTestRule.onNodeWithTag("onboarding_continue_button").performScrollTo().performClick()
        composeTestRule.mainClock.advanceTimeBy(350)
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("garden_reveal_title").assertIsDisplayed()
        composeTestRule.onNodeWithTag("garden_reveal_screen").performClick()
        composeTestRule.mainClock.advanceTimeBy(350)
        composeTestRule.waitForIdle()

        // Screen 4: Home Screen
        composeTestRule.onNodeWithTag("home_logo").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("play_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("profile_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("settings_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("stars_badge").assertIsDisplayed()
    }

    @Test
    fun `returning player with saved username skips onboarding and garden reveal straight to Home`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = LocalStorageRepository(context)
        repo.saveProgress(
            PlayerProgress(
                playerUsername = "ReturningPeach",
                legalAccepted = true,
                highestUnlockedLevel = 4
            )
        )
        repo.saveSettings(AppSettings(animationsEnabled = false))

        val vm = PeachQuestViewModel(context.applicationContext as android.app.Application)
        composeTestRule.activityRule.scenario.onActivity { activity ->
            activity.setContent {
                PeachQuestTheme {
                    PeachQuestRoot(viewModel = vm)
                }
            }
        }

        repeat(25) {
            Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(120))
            val onHome = runCatching {
                composeTestRule.onNodeWithTag("play_button").assertExists()
                true
            }.getOrDefault(false)
            if (onHome) return@repeat
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("play_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("username_input").assertDoesNotExist()
        composeTestRule.onNodeWithTag("garden_reveal_screen").assertDoesNotExist()
    }

    @Test
    fun `home, 4 worlds map, no-countdown game with boosters, 7-item settings, profile, and owner gating work`() {
        val level1 = LevelRepository.getLevel(1)
        val board = MatchEngine(Random(1)).createPlayableBoard(level1)
        val hint = MatchEngine(Random(1)).findValidMove(board)

        composeTestRule.activityRule.scenario.onActivity { activity ->
            activity.setContent {
                PeachQuestTheme {
                    var tab by remember { mutableIntStateOf(0) }
                    var paused by remember { mutableStateOf(false) }
                    var appSettings by remember { mutableStateOf(AppSettings()) }
                    when (tab) {
                        0 -> HomeScreen(
                            progress = PlayerProgress(
                                playerUsername = "Sunny",
                                legalAccepted = true,
                                highestUnlockedLevel = 3
                            ),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            onPlayClick = { tab = 2 },
                            onLevelMapClick = { tab = 1 },
                            onProfileClick = { tab = 3 },
                            onSettingsClick = { tab = 4 },
                            onOpenOwnerConsole = { tab = 5 }
                        )
                        1 -> LevelMapScreen(
                            progress = PlayerProgress(
                                playerUsername = "Sunny",
                                legalAccepted = true,
                                highestUnlockedLevel = 3
                            ),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            canClaimDaily = true,
                            onClaimDailyReward = {},
                            onOpenGarden = {},
                            onOpenVault = { tab = 3 },
                            onSelectLevel = {},
                            onBack = { tab = 0 }
                        )
                        2 -> GameScreen(
                            game = GameUiState(
                                level = level1,
                                board = board,
                                phase = if (paused) GamePhase.PAUSED else GamePhase.IDLE,
                                tutorialActive = true,
                                tutorialHint = hint
                            ),
                            progress = PlayerProgress(playerUsername = "Sunny"),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            objectiveProgress = { 0 to it.targetAmount },
                            onDismissMechanicTip = {},
                            onDismissTutorial = {},
                            onSelectBooster = {},
                            onTileTapped = { _, _ -> },
                            onTileSwiped = { _, _, _, _ -> },
                            onHintClick = {},
                            onPauseClick = { paused = true },
                            onResumeClick = { paused = false },
                            onRestartLevel = {},
                            onNextLevel = {},
                            onExitToHome = {
                                paused = false
                                tab = 0
                            },
                            onOpenLevelMap = { tab = 1 },
                            onOpenGarden = {}
                        )
                        3 -> FruitVaultScreen(
                            progress = PlayerProgress(playerUsername = "Sunny"),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            canClaimDaily = true,
                            onClaimDailyReward = {},
                            onSelectSkin = {},
                            onTabChanged = {},
                            onBack = { tab = 0 }
                        )
                        4 -> SettingsScreen(
                            playerUsername = "Sunny",
                            settings = appSettings,
                            effectiveGraphicsQuality = GraphicsQuality.HIGH,
                            onToggleMusic = { enabled ->
                                appSettings = appSettings.copy(musicVolume = if (enabled) 0.65f else 0f)
                            },
                            onToggleSfx = { enabled ->
                                appSettings = appSettings.copy(sfxVolume = if (enabled) 0.85f else 0f)
                            },
                            onUpdateUsername = { UsernameValidator.validate(it) },
                            onOpenLegalDoc = {},
                            onResetProgress = {},
                            onBack = { tab = 0 }
                        )
                        5 -> OwnerDashboardScreen(
                            ownerAuth = OwnerAuthState(),
                            analyticsSdkConnected = true,
                            analyticsConsentEnabled = false,
                            deviceTelemetry = DeviceTelemetrySummary(),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            onSignInOwner = { tab = 6 },
                            onVerifyFirestore = {},
                            onSignOutOwner = {},
                            onBack = { tab = 0 }
                        )
                        6 -> OwnerDashboardScreen(
                            ownerAuth = OwnerAuthState(
                                userId = "other_uid",
                                email = "notowner@example.com",
                                emailVerified = true,
                                isAllowlistedAdmin = false
                            ),
                            analyticsSdkConnected = true,
                            analyticsConsentEnabled = false,
                            deviceTelemetry = DeviceTelemetrySummary(),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            onSignInOwner = {},
                            onVerifyFirestore = {},
                            onSignOutOwner = { tab = 7 },
                            onBack = { tab = 0 }
                        )
                        7 -> OwnerDashboardScreen(
                            ownerAuth = OwnerAuthState(
                                userId = "owner_uid",
                                email = "livechad67@gmail.com",
                                emailVerified = true,
                                isAllowlistedAdmin = true,
                                firestoreVerified = true
                            ),
                            analyticsSdkConnected = true,
                            analyticsConsentEnabled = true,
                            deviceTelemetry = DeviceTelemetrySummary(sessionCount = 2),
                            settings = appSettings,
                            graphicsQuality = GraphicsQuality.HIGH,
                            onSignInOwner = {},
                            onVerifyFirestore = {},
                            onSignOutOwner = {},
                            onBack = { tab = 0 }
                        )
                    }
                }
            }
        }
        composeTestRule.waitForIdle()

        // HomeScreen -> Profile & Rewards
        composeTestRule.onNodeWithTag("profile_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("claim_daily_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("fruit_gallery_grid").assertIsDisplayed()
        composeTestRule.onNodeWithTag("vault_back").performClick()
        composeTestRule.waitForIdle()

        // HomeScreen -> World Map (4 Worlds) -> Tap Level 1 -> Level Preview Modal -> Play
        composeTestRule.onNodeWithTag("level_map_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("world_card_1").assertIsDisplayed()
        composeTestRule.onNodeWithTag("level_tile_1").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("level_preview_dialog").assertIsDisplayed()
        composeTestRule.onNodeWithTag("level_preview_play_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("level_map_back").performClick()
        composeTestRule.waitForIdle()

        // Play -> GameScreen immediately (NO countdown overlay!) + 4 Booster buttons
        composeTestRule.onNodeWithTag("play_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("level_intro_overlay").assertDoesNotExist()
        composeTestRule.onNodeWithTag("match3_board").assertIsDisplayed()
        composeTestRule.onNodeWithTag("tutorial_hand").assertIsDisplayed()
        composeTestRule.onNodeWithTag("booster_rainbow").assertIsDisplayed()
        composeTestRule.onNodeWithTag("booster_bomb").assertIsDisplayed()
        composeTestRule.onNodeWithTag("booster_lightning").assertIsDisplayed()
        composeTestRule.onNodeWithTag("booster_magic_peach").assertIsDisplayed()

        // Pause -> Return Home -> Settings Popup (strictly 7 items)
        composeTestRule.onNodeWithTag("pause_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("pause_home_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("settings_button").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("switch_music").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("switch_sfx").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("edit_username_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("privacy_info_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("terms_of_use_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("reset_progress_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("settings_return_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("owner_console_button").assertDoesNotExist()
        composeTestRule.onNodeWithTag("settings_return_button").performClick()
        composeTestRule.waitForIdle()

        // Long-press CLASTAD signature opens private Owner Console -> verify allowlist gating
        composeTestRule.onNodeWithTag("clastad_signature").performScrollTo().performTouchInput { longClick() }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("owner_signin_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("owner_access_denied").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("owner_signout_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("owner_dashboard_content").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("owner_local_diagnostics_card").performScrollTo().assertIsDisplayed()
    }
}
