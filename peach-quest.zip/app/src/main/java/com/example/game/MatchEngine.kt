package com.example.game

import com.example.model.BoosterType
import com.example.model.FruitType
import com.example.model.LevelDefinition
import com.example.model.ObstacleType
import com.example.model.SpecialKind
import com.example.model.TileCell
import kotlin.math.abs
import kotlin.random.Random

data class BoardState(
    val rows: Int,
    val cols: Int,
    val cells: List<TileCell>
) {
    fun get(r: Int, c: Int): TileCell = cells[r * cols + c]

    fun indexOf(r: Int, c: Int): Int = r * cols + c

    fun inBounds(r: Int, c: Int): Boolean = r in 0 until rows && c in 0 until cols

    fun withReplaced(updates: Map<Int, TileCell>): BoardState {
        if (updates.isEmpty()) return this
        val mutable = cells.toMutableList()
        updates.forEach { (idx, cell) -> mutable[idx] = cell }
        return copy(cells = mutable)
    }
}

data class MatchGroup(
    val indices: Set<Int>,
    val spawnAtIndex: Int?,
    val spawnSpecial: SpecialKind = SpecialKind.NONE
) {
    // Compatibility alias
    val spawnGoldenAtIndex: Int? get() = spawnAtIndex
}

data class StepResolution(
    val boardAfterClear: BoardState,
    val clearedIndices: Set<Int>,
    val goldenWaveIndices: Set<Int>,
    val collectedFruits: Map<FruitType, Int>,
    val clearedObstacles: Map<ObstacleType, Int>,
    val pointsAwarded: Int,
    val createdGoldenCount: Int,
    val triggeredGoldenWaves: Int,
    val triggeredSpecialKinds: Set<SpecialKind> = emptySet()
)

data class MoveHint(
    val r1: Int,
    val c1: Int,
    val r2: Int,
    val c2: Int
)

data class GravityStepResult(
    val board: BoardState,
    val fallRowsByCellId: Map<Long, Int>
)

class MatchEngine(private val random: Random = Random.Default) {

    private var nextCellId = 1L

    fun nextId(): Long = nextCellId++

    fun ensureNextIdAbove(cells: List<TileCell>) {
        val maxId = cells.maxOfOrNull { it.id } ?: 0L
        if (nextCellId <= maxId) {
            nextCellId = maxId + 1L
        }
    }

    fun createPlayableBoard(level: LevelDefinition): BoardState {
        val rows = level.rows
        val cols = level.cols
        val fruits = level.availableFruits
        val seededWater = level.initialWaterCells.ifEmpty {
            // Default: seed sparkling headwater at top active cells of middle columns
            val out = mutableSetOf<Pair<Int, Int>>()
            for (c in 0 until cols) {
                val topR = (0 until rows).firstOrNull { (it to c) !in level.voidCells }
                if (topR != null && (c == cols / 2 || c == (cols - 1) / 2 || (rows >= 7 && c % 2 == 1))) {
                    out.add(topR to c)
                    if (topR + 1 < rows && (topR + 1 to c) !in level.voidCells && level.initialObstacles[topR + 1 to c]?.first != ObstacleType.CRATE) {
                        out.add((topR + 1) to c)
                    }
                }
            }
            out
        }

        repeat(40) {
            val cells = MutableList(rows * cols) { idx ->
                val r = idx / cols
                val c = idx % cols
                val isVoid = (r to c) in level.voidCells
                val isWatered = !isVoid && (r to c) in seededWater
                if (isVoid) {
                    TileCell(
                        id = nextId(),
                        row = r,
                        col = c,
                        fruit = null,
                        isVoid = true,
                        isWatered = false
                    )
                } else {
                    val obs = level.initialObstacles[r to c]
                    if (obs != null && obs.first == ObstacleType.CRATE) {
                        TileCell(
                            id = nextId(),
                            row = r,
                            col = c,
                            fruit = null,
                            obstacle = obs.first,
                            obstacleHp = obs.second,
                            isWatered = false
                        )
                    } else {
                        TileCell(
                            id = nextId(),
                            row = r,
                            col = c,
                            fruit = fruits.random(random),
                            obstacle = obs?.first ?: ObstacleType.NONE,
                            obstacleHp = obs?.second ?: 0,
                            isWatered = isWatered
                        )
                    }
                }
            }

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val idx = r * cols + c
                    if (cells[idx].isVoid || cells[idx].obstacle == ObstacleType.CRATE) continue
                    val forbidden = mutableSetOf<FruitType>()
                    if (c >= 2) {
                        val a = cells[r * cols + (c - 1)].fruit
                        val b = cells[r * cols + (c - 2)].fruit
                        if (a != null && a == b) forbidden.add(a)
                    }
                    if (r >= 2) {
                        val a = cells[(r - 1) * cols + c].fruit
                        val b = cells[(r - 2) * cols + c].fruit
                        if (a != null && a == b) forbidden.add(a)
                    }
                    val candidates = fruits.filter { it !in forbidden }
                    val chosen = (if (candidates.isNotEmpty()) candidates else fruits).random(random)
                    cells[idx] = cells[idx].copy(fruit = chosen)
                }
            }

            val board = BoardState(rows, cols, cells)
            if (findMatches(board).isEmpty() && findValidMove(board) != null) {
                return board
            }
        }

        return shuffleBoard(
            BoardState(
                rows,
                cols,
                List(rows * cols) { idx ->
                    val r = idx / cols
                    val c = idx % cols
                    val isVoid = (r to c) in level.voidCells
                    val obs = level.initialObstacles[r to c]
                    TileCell(
                        id = nextId(),
                        row = r,
                        col = c,
                        fruit = if (isVoid || obs?.first == ObstacleType.CRATE) null else fruits[idx % fruits.size],
                        obstacle = if (isVoid) ObstacleType.NONE else (obs?.first ?: ObstacleType.NONE),
                        obstacleHp = if (isVoid) 0 else (obs?.second ?: 0),
                        isVoid = isVoid,
                        isWatered = !isVoid && (r to c) in seededWater
                    )
                }
            ),
            fruits
        )
    }

    fun canSwap(board: BoardState, r1: Int, c1: Int, r2: Int, c2: Int): Boolean {
        if (!board.inBounds(r1, c1) || !board.inBounds(r2, c2)) return false
        if (abs(r1 - r2) + abs(c1 - c2) != 1) return false
        val a = board.get(r1, c1)
        val b = board.get(r2, c2)
        return a.isMovable && b.isMovable
    }

    fun swapCells(board: BoardState, r1: Int, c1: Int, r2: Int, c2: Int): BoardState {
        val idx1 = board.indexOf(r1, c1)
        val idx2 = board.indexOf(r2, c2)
        val cell1 = board.cells[idx1]
        val cell2 = board.cells[idx2]
        val updated1 = cell1.copy(id = cell2.id, fruit = cell2.fruit, special = cell2.special)
        val updated2 = cell2.copy(id = cell1.id, fruit = cell1.fruit, special = cell1.special)
        return board.withReplaced(mapOf(idx1 to updated1, idx2 to updated2))
    }

    fun findMatches(board: BoardState): List<MatchGroup> {
        val rows = board.rows
        val cols = board.cols
        val horizontalRuns = mutableListOf<List<Int>>()
        val verticalRuns = mutableListOf<List<Int>>()

        for (r in 0 until rows) {
            var c = 0
            while (c < cols) {
                val cell = board.get(r, c)
                val fruit = cell.fruit
                if (cell.isVoid || fruit == null || fruit == FruitType.GOLDEN_PINEAPPLE || cell.special == SpecialKind.RAINBOW) {
                    c++
                    continue
                }
                var end = c + 1
                while (end < cols) {
                    val nextCell = board.get(r, end)
                    if (!nextCell.isVoid && nextCell.fruit == fruit && nextCell.special != SpecialKind.RAINBOW) {
                        end++
                    } else break
                }
                if (end - c >= 3) {
                    horizontalRuns.add((c until end).map { col -> r * cols + col })
                }
                c = end
            }
        }

        for (c in 0 until cols) {
            var r = 0
            while (r < rows) {
                val cell = board.get(r, c)
                val fruit = cell.fruit
                if (cell.isVoid || fruit == null || fruit == FruitType.GOLDEN_PINEAPPLE || cell.special == SpecialKind.RAINBOW) {
                    r++
                    continue
                }
                var end = r + 1
                while (end < rows) {
                    val nextCell = board.get(end, c)
                    if (!nextCell.isVoid && nextCell.fruit == fruit && nextCell.special != SpecialKind.RAINBOW) {
                        end++
                    } else break
                }
                if (end - r >= 3) {
                    verticalRuns.add((r until end).map { row -> row * cols + c })
                }
                r = end
            }
        }

        val allRuns = horizontalRuns + verticalRuns
        if (allRuns.isEmpty()) return emptyList()

        val visited = BooleanArray(allRuns.size)
        val groups = mutableListOf<MatchGroup>()
        for (i in allRuns.indices) {
            if (visited[i]) continue
            visited[i] = true
            val merged = linkedSetOf<Int>()
            merged.addAll(allRuns[i])
            var hasH = i < horizontalRuns.size
            var hasV = i >= horizontalRuns.size
            var maxRunLen = allRuns[i].size
            var isPrimaryHorizontal = i < horizontalRuns.size

            var changed = true
            while (changed) {
                changed = false
                for (j in allRuns.indices) {
                    if (!visited[j] && allRuns[j].any { it in merged }) {
                        visited[j] = true
                        merged.addAll(allRuns[j])
                        if (j < horizontalRuns.size) hasH = true else hasV = true
                        if (allRuns[j].size > maxRunLen) {
                            maxRunLen = allRuns[j].size
                            isPrimaryHorizontal = j < horizontalRuns.size
                        }
                        changed = true
                    }
                }
            }

            val specialToSpawn = when {
                maxRunLen >= 5 -> SpecialKind.RAINBOW
                hasH && hasV && merged.size >= 5 -> SpecialKind.BOMB
                maxRunLen == 4 -> if (isPrimaryHorizontal) SpecialKind.LIGHTNING_COL else SpecialKind.LIGHTNING_ROW
                else -> SpecialKind.NONE
            }

            val spawnIdx = if (specialToSpawn != SpecialKind.NONE) {
                merged.firstOrNull { board.cells[it].obstacle != ObstacleType.VINES } ?: merged.first()
            } else null

            groups.add(MatchGroup(merged, spawnIdx, specialToSpawn))
        }
        return groups
    }

    fun resolveMatchesStep(
        board: BoardState,
        matches: List<MatchGroup>,
        comboStep: Int
    ): StepResolution {
        val toClear = linkedSetOf<Int>()
        val spawnSpecials = linkedMapOf<Int, SpecialKind>()
        val waveIndices = linkedSetOf<Int>()
        val triggeredKinds = mutableSetOf<SpecialKind>()

        for (group in matches) {
            toClear.addAll(group.indices)
            if (group.spawnAtIndex != null && group.spawnSpecial != SpecialKind.NONE) {
                spawnSpecials[group.spawnAtIndex] = group.spawnSpecial
            }
        }

        // Chain-detonate any existing special fruits caught inside matched lines!
        expandSpecialChain(board, toClear, waveIndices, triggeredKinds)

        return applyClearSet(
            board = board,
            clearIndices = toClear,
            spawnSpecialMap = spawnSpecials,
            waveIndices = waveIndices,
            comboStep = comboStep,
            triggeredWaves = if (triggeredKinds.isNotEmpty()) triggeredKinds.size else 0,
            triggeredSpecialKinds = triggeredKinds
        )
    }

    fun triggerSpecialCell(
        board: BoardState,
        row: Int,
        col: Int,
        swappedWithCell: TileCell? = null
    ): StepResolution {
        val targetCell = board.get(row, col)
        val kind = when {
            targetCell.special != SpecialKind.NONE -> targetCell.special
            targetCell.fruit == FruitType.GOLDEN_PINEAPPLE -> SpecialKind.MAGIC_PEACH
            else -> SpecialKind.MAGIC_PEACH
        }
        val otherSpecial = swappedWithCell?.special ?: SpecialKind.NONE
        val isComboPair = otherSpecial != SpecialKind.NONE ||
            (swappedWithCell?.isGoldenPineapple == true && targetCell.isSpecialFruit)

        val waveIndices = linkedSetOf<Int>()
        val triggeredKinds = mutableSetOf(kind)
        if (otherSpecial != SpecialKind.NONE) triggeredKinds.add(otherSpecial)

        if (isComboPair) {
            // Swapping ANY two special fruits triggers Magic Peach Mega-Wave (cross + 5x5 + bonus target)!
            triggeredKinds.add(SpecialKind.MAGIC_PEACH)
            for (dr in -2..2) {
                for (dc in -2..2) {
                    if (board.inBounds(row + dr, col + dc)) {
                        waveIndices.add(board.indexOf(row + dr, col + dc))
                    }
                }
            }
            for (c in 0 until board.cols) waveIndices.add(board.indexOf(row, c))
            for (r in 0 until board.rows) waveIndices.add(board.indexOf(r, col))
        } else {
            collectSpecialFootprint(
                board = board,
                idx = board.indexOf(row, col),
                kind = kind,
                preferredTargetFruit = swappedWithCell?.fruit,
                outIndices = waveIndices
            )
        }

        expandSpecialChain(board, waveIndices, waveIndices, triggeredKinds, originIdx = board.indexOf(row, col))

        return applyClearSet(
            board = board,
            clearIndices = waveIndices,
            spawnSpecialMap = emptyMap(),
            waveIndices = waveIndices,
            comboStep = 1,
            triggeredWaves = triggeredKinds.size.coerceAtLeast(1),
            triggeredSpecialKinds = triggeredKinds
        )
    }

    fun applyBooster(
        board: BoardState,
        row: Int,
        col: Int,
        booster: BoosterType
    ): StepResolution {
        val targetCell = board.get(row, col)
        val waveIndices = linkedSetOf<Int>()
        val kind = when (booster) {
            BoosterType.RAINBOW -> SpecialKind.RAINBOW
            BoosterType.BOMB -> SpecialKind.BOMB
            BoosterType.LIGHTNING -> SpecialKind.LIGHTNING_ROW
            BoosterType.MAGIC_PEACH -> SpecialKind.MAGIC_PEACH
        }
        val triggeredKinds = mutableSetOf(kind)

        when (booster) {
            BoosterType.RAINBOW -> {
                val chosenFruit = targetCell.fruit?.takeIf { it != FruitType.GOLDEN_PINEAPPLE }
                    ?: mostAbundantFruit(board)
                waveIndices.add(board.indexOf(row, col))
                if (chosenFruit != null) {
                    board.cells.forEachIndexed { idx, c ->
                        if (c.fruit == chosenFruit) waveIndices.add(idx)
                    }
                }
            }
            BoosterType.BOMB -> {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (board.inBounds(row + dr, col + dc)) {
                            waveIndices.add(board.indexOf(row + dr, col + dc))
                        }
                    }
                }
            }
            BoosterType.LIGHTNING -> {
                for (c in 0 until board.cols) waveIndices.add(board.indexOf(row, c))
                for (r in 0 until board.rows) waveIndices.add(board.indexOf(r, col))
            }
            BoosterType.MAGIC_PEACH -> {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (board.inBounds(row + dr, col + dc)) {
                            waveIndices.add(board.indexOf(row + dr, col + dc))
                        }
                    }
                }
                for (d in -3..3) {
                    if (board.inBounds(row + d, col)) waveIndices.add(board.indexOf(row + d, col))
                    if (board.inBounds(row, col + d)) waveIndices.add(board.indexOf(row, col + d))
                }
                val bonusFruit = targetCell.fruit?.takeIf { it != FruitType.GOLDEN_PINEAPPLE }
                if (bonusFruit != null) {
                    var added = 0
                    board.cells.forEachIndexed { idx, c ->
                        if (added < 5 && idx !in waveIndices && c.fruit == bonusFruit) {
                            waveIndices.add(idx)
                            added++
                        }
                    }
                }
            }
        }

        expandSpecialChain(board, waveIndices, waveIndices, triggeredKinds, originIdx = board.indexOf(row, col))

        return applyClearSet(
            board = board,
            clearIndices = waveIndices,
            spawnSpecialMap = emptyMap(),
            waveIndices = waveIndices,
            comboStep = 1,
            triggeredWaves = triggeredKinds.size.coerceAtLeast(1),
            triggeredSpecialKinds = triggeredKinds
        )
    }

    /**
     * Preserved Magic Peach / Golden Pineapple wave entry point.
     */
    fun triggerGoldenPineapple(
        board: BoardState,
        pineappleRow: Int,
        pineappleCol: Int,
        swappedWithFruit: FruitType? = null,
        isSuperDoubleGolden: Boolean = false
    ): StepResolution {
        val waveIndices = linkedSetOf<Int>()
        val radius = if (isSuperDoubleGolden) 2 else 1

        for (dr in -radius..radius) {
            for (dc in -radius..radius) {
                val nr = pineappleRow + dr
                val nc = pineappleCol + dc
                if (board.inBounds(nr, nc)) {
                    waveIndices.add(board.indexOf(nr, nc))
                }
            }
        }

        val crossReach = if (isSuperDoubleGolden) maxOf(board.rows, board.cols) else 2
        for (d in -crossReach..crossReach) {
            if (board.inBounds(pineappleRow + d, pineappleCol)) {
                waveIndices.add(board.indexOf(pineappleRow + d, pineappleCol))
            }
            if (board.inBounds(pineappleRow, pineappleCol + d)) {
                waveIndices.add(board.indexOf(pineappleRow, pineappleCol + d))
            }
        }

        if (swappedWithFruit != null && swappedWithFruit != FruitType.GOLDEN_PINEAPPLE) {
            var extra = 0
            for (idx in board.cells.indices) {
                if (extra >= 5) break
                if (idx !in waveIndices && board.cells[idx].fruit == swappedWithFruit) {
                    waveIndices.add(idx)
                    extra++
                }
            }
        }

        val triggeredKinds = mutableSetOf(SpecialKind.MAGIC_PEACH)
        expandSpecialChain(
            board,
            waveIndices,
            waveIndices,
            triggeredKinds,
            originIdx = board.indexOf(pineappleRow, pineappleCol)
        )

        return applyClearSet(
            board = board,
            clearIndices = waveIndices,
            spawnSpecialMap = emptyMap(),
            waveIndices = waveIndices,
            comboStep = 1,
            triggeredWaves = triggeredKinds.size,
            triggeredSpecialKinds = triggeredKinds
        )
    }

    private fun collectSpecialFootprint(
        board: BoardState,
        idx: Int,
        kind: SpecialKind,
        preferredTargetFruit: FruitType?,
        outIndices: MutableSet<Int>
    ) {
        val r = idx / board.cols
        val c = idx % board.cols
        outIndices.add(idx)
        when (kind) {
            SpecialKind.LIGHTNING_ROW -> {
                for (cc in 0 until board.cols) outIndices.add(board.indexOf(r, cc))
            }
            SpecialKind.LIGHTNING_COL -> {
                for (rr in 0 until board.rows) outIndices.add(board.indexOf(rr, c))
            }
            SpecialKind.BOMB -> {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (board.inBounds(r + dr, c + dc)) {
                            outIndices.add(board.indexOf(r + dr, c + dc))
                        }
                    }
                }
            }
            SpecialKind.RAINBOW -> {
                val target = preferredTargetFruit?.takeIf { it != FruitType.GOLDEN_PINEAPPLE }
                    ?: mostAbundantFruit(board)
                if (target != null) {
                    board.cells.forEachIndexed { cellIdx, cell ->
                        if (cell.fruit == target) outIndices.add(cellIdx)
                    }
                }
            }
            SpecialKind.MAGIC_PEACH -> {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (board.inBounds(r + dr, c + dc)) {
                            outIndices.add(board.indexOf(r + dr, c + dc))
                        }
                    }
                }
                for (d in -2..2) {
                    if (board.inBounds(r + d, c)) outIndices.add(board.indexOf(r + d, c))
                    if (board.inBounds(r, c + d)) outIndices.add(board.indexOf(r, c + d))
                }
            }
            SpecialKind.NONE -> Unit
        }
    }

    private fun expandSpecialChain(
        board: BoardState,
        targetClear: MutableSet<Int>,
        waveIndices: MutableSet<Int>,
        triggeredKinds: MutableSet<SpecialKind>,
        originIdx: Int? = null
    ) {
        val visited = mutableSetOf<Int>()
        if (originIdx != null) visited.add(originIdx)
        val queue = ArrayDeque<Int>()
        targetClear.forEach { idx ->
            val cell = board.cells[idx]
            if (cell.isSpecialFruit && idx !in visited) {
                visited.add(idx)
                queue.add(idx)
            }
        }
        while (queue.isNotEmpty()) {
            val sIdx = queue.removeFirst()
            val cell = board.cells[sIdx]
            val kind = if (cell.special != SpecialKind.NONE) cell.special else SpecialKind.MAGIC_PEACH
            triggeredKinds.add(kind)
            val added = linkedSetOf<Int>()
            collectSpecialFootprint(board, sIdx, kind, preferredTargetFruit = null, outIndices = added)
            added.forEach { nIdx ->
                targetClear.add(nIdx)
                waveIndices.add(nIdx)
                val nCell = board.cells[nIdx]
                if (nCell.isSpecialFruit && nIdx !in visited) {
                    visited.add(nIdx)
                    queue.add(nIdx)
                }
            }
        }
    }

    private fun mostAbundantFruit(board: BoardState): FruitType? {
        val counts = mutableMapOf<FruitType, Int>()
        board.cells.forEach { c ->
            val f = c.fruit
            if (f != null && f != FruitType.GOLDEN_PINEAPPLE) {
                counts[f] = (counts[f] ?: 0) + 1
            }
        }
        return counts.maxByOrNull { it.value }?.key
    }

    private fun applyClearSet(
        board: BoardState,
        clearIndices: Set<Int>,
        spawnSpecialMap: Map<Int, SpecialKind>,
        waveIndices: Set<Int>,
        comboStep: Int,
        triggeredWaves: Int,
        triggeredSpecialKinds: Set<SpecialKind>
    ): StepResolution {
        val collected = mutableMapOf<FruitType, Int>()
        val clearedObstacles = mutableMapOf<ObstacleType, Int>()
        val mutable = board.cells.toMutableList()
        var points = 0
        val multiplier = 1.0 + (comboStep - 1) * 0.45
        val crateHits = mutableSetOf<Int>()

        for (idx in clearIndices) {
            val cell = mutable[idx]
            if (cell.isVoid) continue
            val r = cell.row
            val c = cell.col

            if (cell.obstacle == ObstacleType.CRATE) {
                crateHits.add(idx)
                continue
            }

            val fruit = cell.fruit
            if (fruit != null && fruit != FruitType.GOLDEN_PINEAPPLE) {
                collected[fruit] = (collected[fruit] ?: 0) + 1
                points += (30 * multiplier).toInt()
            } else if (fruit == FruitType.GOLDEN_PINEAPPLE || cell.special != SpecialKind.NONE) {
                points += (100 * multiplier).toInt()
            }

            var newObs = cell.obstacle
            var newHp = cell.obstacleHp
            if (newObs == ObstacleType.ICE || newObs == ObstacleType.VINES) {
                newHp -= 1
                if (newHp <= 0) {
                    clearedObstacles[newObs] = (clearedObstacles[newObs] ?: 0) + 1
                    newObs = ObstacleType.NONE
                    newHp = 0
                    points += 60
                }
            }

            val neighbors = listOf(r - 1 to c, r + 1 to c, r to c - 1, r to c + 1)
            for ((nr, nc) in neighbors) {
                if (board.inBounds(nr, nc)) {
                    val nIdx = board.indexOf(nr, nc)
                    if (mutable[nIdx].obstacle == ObstacleType.CRATE) {
                        crateHits.add(nIdx)
                    }
                }
            }

            val newSpecial = spawnSpecialMap[idx]
            if (newSpecial != null && newSpecial != SpecialKind.NONE) {
                val baseFruit = when (newSpecial) {
                    SpecialKind.MAGIC_PEACH -> FruitType.GOLDEN_PINEAPPLE
                    SpecialKind.RAINBOW -> FruitType.PEACH
                    else -> fruit ?: FruitType.PEACH
                }
                mutable[idx] = cell.copy(
                    id = nextId(),
                    fruit = baseFruit,
                    obstacle = newObs,
                    obstacleHp = newHp,
                    special = newSpecial
                )
                points += 120
            } else {
                mutable[idx] = cell.copy(
                    fruit = null,
                    obstacle = newObs,
                    obstacleHp = newHp,
                    special = SpecialKind.NONE
                )
            }
        }

        for (cIdx in crateHits) {
            val crateCell = mutable[cIdx]
            if (crateCell.obstacle == ObstacleType.CRATE) {
                val hp = crateCell.obstacleHp - 1
                if (hp <= 0) {
                    clearedObstacles[ObstacleType.CRATE] =
                        (clearedObstacles[ObstacleType.CRATE] ?: 0) + 1
                    mutable[cIdx] = crateCell.copy(
                        fruit = null,
                        obstacle = ObstacleType.NONE,
                        obstacleHp = 0,
                        special = SpecialKind.NONE
                    )
                    points += 90
                } else {
                    mutable[cIdx] = crateCell.copy(obstacleHp = hp)
                }
            }
        }

        // Spread sparkling water through any cleared cells connected to an already watered channel
        var waterChanged = true
        while (waterChanged) {
            waterChanged = false
            for (idx in clearIndices) {
                val cell = mutable[idx]
                if (cell.isVoid || cell.obstacle == ObstacleType.CRATE || cell.isWatered) continue
                val r = cell.row
                val c = cell.col
                val adjWatered = listOf(r - 1 to c, r + 1 to c, r to c - 1, r to c + 1).any { (nr, nc) ->
                    board.inBounds(nr, nc) && mutable[board.indexOf(nr, nc)].let { !it.isVoid && it.isWatered }
                }
                if (adjWatered) {
                    mutable[idx] = cell.copy(isWatered = true)
                    waterChanged = true
                }
            }
        }

        if (triggeredWaves > 0) {
            points += triggeredWaves * 180
        }

        return StepResolution(
            boardAfterClear = board.copy(cells = mutable),
            clearedIndices = clearIndices.filter { !board.cells[it].isVoid }.toSet(),
            goldenWaveIndices = waveIndices.filter { !board.cells[it].isVoid }.toSet(),
            collectedFruits = collected,
            clearedObstacles = clearedObstacles,
            pointsAwarded = points,
            createdGoldenCount = spawnSpecialMap.size,
            triggeredGoldenWaves = triggeredWaves,
            triggeredSpecialKinds = triggeredSpecialKinds
        )
    }

    fun applyGravityAndRefill(board: BoardState, availableFruits: List<FruitType>): BoardState =
        applyGravityAndRefillWithDistances(board, availableFruits).board

    fun applyGravityAndRefillWithDistances(
        board: BoardState,
        availableFruits: List<FruitType>
    ): GravityStepResult {
        val rows = board.rows
        val cols = board.cols
        val mutable = board.cells.toMutableList()
        val fallDistances = mutableMapOf<Long, Int>()

        for (c in 0 until cols) {
            for (r in rows - 1 downTo 0) {
                val destIdx = r * cols + c
                val dest = mutable[destIdx]
                if (!dest.isVoid && dest.fruit == null && !dest.blocksGravity) {
                    var srcRow = r - 1
                    var foundIdx = -1
                    while (srcRow >= 0) {
                        val candidateIdx = srcRow * cols + c
                        val candidate = mutable[candidateIdx]
                        if (candidate.blocksGravity) {
                            break
                        }
                        if (candidate.fruit != null) {
                            foundIdx = candidateIdx
                            break
                        }
                        srcRow--
                    }
                    if (foundIdx != -1) {
                        val src = mutable[foundIdx]
                        mutable[destIdx] = dest.copy(id = src.id, fruit = src.fruit, special = src.special)
                        mutable[foundIdx] = src.copy(fruit = null, special = SpecialKind.NONE)
                        fallDistances[src.id] = (r - srcRow).coerceAtLeast(1)
                    }
                }
            }
        }

        for (c in 0 until cols) {
            val topActiveRow = (0 until rows).firstOrNull { !mutable[it * cols + c].isVoid } ?: 0
            for (r in 0 until rows) {
                val idx = r * cols + c
                val cell = mutable[idx]
                if (!cell.isVoid && cell.fruit == null && cell.obstacle != ObstacleType.CRATE) {
                    val newId = nextId()
                    mutable[idx] = cell.copy(
                        id = newId,
                        fruit = availableFruits.random(random),
                        special = SpecialKind.NONE
                    )
                    fallDistances[newId] = (r - topActiveRow) + 1
                }
            }
        }

        return GravityStepResult(
            board = board.copy(cells = mutable),
            fallRowsByCellId = fallDistances
        )
    }

    fun findValidMove(board: BoardState): MoveHint? {
        val rows = board.rows
        val cols = board.cols

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = board.get(r, c)
                if (cell.isSpecialFruit && cell.obstacle != ObstacleType.VINES) {
                    val dirs = listOf(0 to 1, 1 to 0, 0 to -1, -1 to 0)
                    for ((dr, dc) in dirs) {
                        if (canSwap(board, r, c, r + dr, c + dc)) {
                            return MoveHint(r, c, r + dr, c + dc)
                        }
                    }
                    return MoveHint(r, c, r, c)
                }
            }
        }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (c + 1 < cols && canSwap(board, r, c, r, c + 1)) {
                    val swapped = swapCells(board, r, c, r, c + 1)
                    if (findMatches(swapped).isNotEmpty()) {
                        return MoveHint(r, c, r, c + 1)
                    }
                }
                if (r + 1 < rows && canSwap(board, r, c, r + 1, c)) {
                    val swapped = swapCells(board, r, c, r + 1, c)
                    if (findMatches(swapped).isNotEmpty()) {
                        return MoveHint(r, c, r + 1, c)
                    }
                }
            }
        }
        return null
    }

    fun shuffleBoard(board: BoardState, availableFruits: List<FruitType>): BoardState {
        val rows = board.rows
        val cols = board.cols

        repeat(35) {
            val mutable = board.cells.toMutableList()
            val movableIndices = mutable.indices.filter { idx ->
                val cell = mutable[idx]
                cell.isMovable && !cell.isSpecialFruit
            }
            val pool = movableIndices.mapNotNull { mutable[it].fruit }.shuffled(random)
            movableIndices.forEachIndexed { i, boardIdx ->
                mutable[boardIdx] = mutable[boardIdx].copy(
                    id = nextId(),
                    fruit = pool[i]
                )
            }
            val candidate = board.copy(cells = mutable)
            if (findMatches(candidate).isEmpty() && findValidMove(candidate) != null) {
                return candidate
            }
        }

        val mutable = board.cells.toMutableList()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val idx = r * cols + c
                val cell = mutable[idx]
                if (!cell.isMovable || cell.isSpecialFruit) continue
                val forbidden = mutableSetOf<FruitType>()
                if (c >= 2) {
                    val a = mutable[r * cols + (c - 1)].fruit
                    val b = mutable[r * cols + (c - 2)].fruit
                    if (a != null && a == b) forbidden.add(a)
                }
                if (r >= 2) {
                    val a = mutable[(r - 1) * cols + c].fruit
                    val b = mutable[(r - 2) * cols + c].fruit
                    if (a != null && a == b) forbidden.add(a)
                }
                val candidates = availableFruits.filter { it !in forbidden }
                mutable[idx] = cell.copy(
                    id = nextId(),
                    fruit = (if (candidates.isNotEmpty()) candidates else availableFruits).random(random)
                )
            }
        }

        val cleanBoard = board.copy(cells = mutable)
        if (findValidMove(cleanBoard) != null) return cleanBoard

        val f = availableFruits.first()
        for (r in 0 until rows) {
            for (c in 0..cols - 4) {
                val i0 = r * cols + c
                val i1 = r * cols + c + 1
                val i2 = r * cols + c + 2
                val i3 = r * cols + c + 3
                if (mutable[i0].isMovable && mutable[i1].isMovable && mutable[i2].isMovable && mutable[i3].isMovable) {
                    val alt = availableFruits.last()
                    mutable[i0] = mutable[i0].copy(fruit = f)
                    mutable[i1] = mutable[i1].copy(fruit = f)
                    mutable[i2] = mutable[i2].copy(fruit = alt)
                    mutable[i3] = mutable[i3].copy(fruit = f)
                    val guaranteed = board.copy(cells = mutable)
                    if (findMatches(guaranteed).isEmpty()) return guaranteed
                }
            }
        }
        return board.copy(cells = mutable)
    }
}
