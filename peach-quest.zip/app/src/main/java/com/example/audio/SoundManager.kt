package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import com.example.model.AppSettings
import com.example.model.Chapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

enum class SoundCue {
    // UI interactions
    BUTTON_TAP,
    MENU_OPEN,
    MENU_CLOSE,
    TAB_SWITCH,
    TOGGLE_ON,
    TOGGLE_OFF,
    SLIDER_TICK,
    BACK,
    REWARD_CLAIM,
    NOTIFICATION_POP,
    // Opening & Level Intro
    OPENING_CHIME,
    COUNTDOWN_TICK,
    COUNTDOWN_GO,
    // Gameplay & Water
    TILE_SELECT,
    WATER_RIPPLE,
    SWAP,
    INVALID_SWAP,
    MATCH,
    FRUIT_POP,
    CASCADE_COMBO,
    FALL,
    GOLDEN_CHARGE,
    LIGHTNING_ZAP,
    BOMB_BLAST,
    RAINBOW_BURST,
    MAGIC_PEACH,
    GARDEN_GATE_OPEN,
    TUTORIAL_SUCCESS,
    VICTORY,
    RETRY
}

enum class MusicMood {
    LOBBY,
    GAMEPLAY,
    VICTORY,
    REWARDS
}

/**
 * CLASTAD Fairy-Inspired Audio Engine:
 * - Seamless enchanted-garden soundtrack blending celesta bells, plucked harp, airy pads & soft water stream ambience
 * - Bubbly droplet UI pops, bouncy button clicks, juicy fruit pops, ascending combo chimes & magical victory fanfare
 * - Separate Music / SFX / Mute controls + interaction gate + AudioFocus integration
 */
class SoundManager(context: Context? = null) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var musicJob: Job? = null
    private var settings = AppSettings()
    private var activeChapter = Chapter.SUNNY_SPROUT
    private var activeMood = MusicMood.LOBBY
    private var isForeground = true
    private var hasAudioFocus = false
    @Volatile
    private var hasUserInteracted = false

    private val sampleRate = 22050
    private val sfxCache = ConcurrentHashMap<String, ShortArray>()
    private val musicLoopCache = ConcurrentHashMap<MusicMood, ShortArray>()
    private val lastCuePlayTime = ConcurrentHashMap<SoundCue, Long>()

    private val audioManager: AudioManager? = try {
        context?.applicationContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    } catch (_: Throwable) {
        null
    }

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                hasAudioFocus = false
                stopMusicLoop()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                hasAudioFocus = true
                if (canPlayMusic()) startMusicLoop()
            }
        }
    }

    private val focusRequest: AudioFocusRequest? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        try {
            AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener(focusChangeListener)
                .build()
        } catch (_: Throwable) {
            null
        }
    } else null

    init {
        preloadCoreAudio()
    }

    private fun preloadCoreAudio() {
        scope.launch {
            listOf(
                SoundCue.BUTTON_TAP,
                SoundCue.TILE_SELECT,
                SoundCue.WATER_RIPPLE,
                SoundCue.SWAP,
                SoundCue.MATCH,
                SoundCue.FRUIT_POP,
                SoundCue.COUNTDOWN_TICK,
                SoundCue.COUNTDOWN_GO
            ).forEach { cue ->
                getOrBuildSfx(cue, 1)
            }
            getOrBuildMusicLoop(MusicMood.LOBBY)
        }
    }

    /**
     * Marks that the player has actively interacted with the game, allowing ambient music
     * and playback to begin smoothly without unprompted auto-audio before interaction.
     */
    fun notifyUserInteraction() {
        if (!hasUserInteracted) {
            hasUserInteracted = true
            if (canPlayMusic()) {
                requestFocusIfNeeded()
                startMusicLoop()
            }
        }
    }

    private fun canPlayMusic(): Boolean =
        hasUserInteracted &&
            isForeground &&
            !settings.muted &&
            settings.masterVolume > 0.01f &&
            settings.musicVolume > 0.01f

    private fun effectiveSfxVolume(): Float {
        if (settings.muted) return 0f
        return (settings.masterVolume * settings.sfxVolume).coerceIn(0f, 1f)
    }

    private fun effectiveMusicVolume(): Float {
        if (settings.muted) return 0f
        return (settings.masterVolume * settings.musicVolume).coerceIn(0f, 1f)
    }

    fun updateSettings(newSettings: AppSettings) {
        val prevMusic = effectiveMusicVolume()
        settings = newSettings
        val nextMusic = effectiveMusicVolume()
        if ((prevMusic <= 0.01f) != (nextMusic <= 0.01f) || (canPlayMusic() && musicJob?.isActive != true)) {
            if (canPlayMusic()) {
                requestFocusIfNeeded()
                startMusicLoop()
            } else {
                stopMusicLoop()
                abandonFocusIfNeeded()
            }
        }
    }

    fun setChapter(chapter: Chapter) {
        activeChapter = chapter
    }

    fun setMusicMood(mood: MusicMood) {
        if (activeMood != mood) {
            activeMood = mood
            if (canPlayMusic()) {
                stopMusicLoop()
                requestFocusIfNeeded()
                startMusicLoop()
            }
        }
    }

    fun onForegroundChanged(foreground: Boolean) {
        isForeground = foreground
        if (canPlayMusic()) {
            requestFocusIfNeeded()
            startMusicLoop()
        } else {
            stopMusicLoop()
            abandonFocusIfNeeded()
        }
    }

    fun playSfx(cue: SoundCue, comboMultiplier: Int = 1) {
        if (!hasUserInteracted && cue != SoundCue.OPENING_CHIME) {
            hasUserInteracted = true
            if (canPlayMusic()) {
                requestFocusIfNeeded()
                startMusicLoop()
            }
        }
        val vol = effectiveSfxVolume()
        if (vol <= 0.01f) return

        val now = System.currentTimeMillis()
        val cooldownMs = when (cue) {
            SoundCue.SLIDER_TICK -> 70L
            SoundCue.FALL, SoundCue.FRUIT_POP, SoundCue.WATER_RIPPLE -> 55L
            SoundCue.BUTTON_TAP, SoundCue.TILE_SELECT -> 40L
            else -> 30L
        }
        val prev = lastCuePlayTime[cue] ?: 0L
        if (now - prev < cooldownMs) return
        lastCuePlayTime[cue] = now

        scope.launch {
            val pcm = getOrBuildSfx(cue, comboMultiplier)
            playPcmBuffer(pcm, vol)
        }
    }

    private fun requestFocusIfNeeded() {
        val am = audioManager ?: run {
            hasAudioFocus = true
            return
        }
        if (hasAudioFocus) return
        try {
            val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
                am.requestAudioFocus(focusRequest)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    focusChangeListener,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
            hasAudioFocus = (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
        } catch (_: Throwable) {
            hasAudioFocus = true
        }
    }

    private fun abandonFocusIfNeeded() {
        val am = audioManager ?: return
        if (!hasAudioFocus) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
                am.abandonAudioFocusRequest(focusRequest)
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(focusChangeListener)
            }
        } catch (_: Throwable) {
        } finally {
            hasAudioFocus = false
        }
    }

    /**
     * Streams a seamless, gentle fairy-inspired instrumental loop (soft celesta bells,
     * delicate plucked harp arpeggios, airy warm pad, and quiet flowing water ambience).
     */
    private fun startMusicLoop() {
        if (musicJob?.isActive == true) return
        val moodSnapshot = activeMood
        musicJob = scope.launch {
            val loopPcm = getOrBuildMusicLoop(moodSnapshot)
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBuf <= 0) return@launch
                val chunkSamples = 2048
                val bufBytes = maxOf(chunkSamples * 4, minBuf)
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                track.play()
                var offset = 0
                while (isActive && canPlayMusic()) {
                    val vol = (effectiveMusicVolume() * 0.28f).coerceIn(0f, 1f)
                    track.setVolume(vol)
                    val remaining = loopPcm.size - offset
                    val writeCount = minOf(chunkSamples, remaining)
                    track.write(loopPcm, offset, writeCount)
                    offset += writeCount
                    if (offset >= loopPcm.size) offset = 0
                }
            } catch (_: Throwable) {
                // Gracefully ignore audio errors on headless/Robolectric runners
            } finally {
                try {
                    track?.stop()
                    track?.release()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun stopMusicLoop() {
        musicJob?.cancel()
        musicJob = null
    }

    private fun getOrBuildMusicLoop(mood: MusicMood): ShortArray {
        musicLoopCache[mood]?.let { return it }
        val built = synthesizeFairyGardenLoop(mood)
        musicLoopCache[mood] = built
        return built
    }

    /**
     * Synthesizes an original 12.8-second enchanted-garden loop in D Lydian / F#m fairy harmony
     * with seamless loop crossfading, plucked harp, soft bell chimes, airy pad, and gentle stream noise.
     */
    private fun synthesizeFairyGardenLoop(mood: MusicMood): ShortArray {
        val durationSec = 12.8
        val totalSamples = (sampleRate * durationSec).toInt()
        val mix = DoubleArray(totalSamples)

        // D Lydian dreamy chords (gentle root + fifth + airy ninth): Dmaj9, Bm7, Gmaj7, A6
        val chordRoots = doubleArrayOf(146.83, 123.47, 196.00, 220.00)
        val chordFifths = doubleArrayOf(220.00, 185.00, 293.66, 329.63)
        val chordNinths = doubleArrayOf(329.63, 277.18, 440.00, 493.88)

        // Harp arpeggio scale tones per bar (delicate plucked pattern)
        val harpPatterns = arrayOf(
            doubleArrayOf(293.66, 369.99, 440.00, 554.37, 659.25, 440.00, 587.33, 440.00),
            doubleArrayOf(246.94, 369.99, 440.00, 493.88, 659.25, 493.88, 554.37, 440.00),
            doubleArrayOf(196.00, 293.66, 369.99, 493.88, 587.33, 493.88, 440.00, 369.99),
            doubleArrayOf(220.00, 329.63, 440.00, 554.37, 659.25, 554.37, 493.88, 369.99)
        )

        // Soft celesta/bell melody sparse dreamy chimes
        val melodyNotes = when (mood) {
            MusicMood.VICTORY -> doubleArrayOf(880.0, 987.77, 1174.66, 1318.51, 1174.66, 987.77, 1174.66, 1479.98)
            MusicMood.REWARDS -> doubleArrayOf(739.99, 880.0, 987.77, 1174.66, 987.77, 880.0, 739.99, 659.25)
            else -> doubleArrayOf(587.33, 739.99, 880.0, 659.25, 739.99, 987.77, 880.0, 587.33)
        }

        // 1. Airy ambient pad + subtle flowing water stream texture
        var waterFilter1 = 0.0
        var waterFilter2 = 0.0
        val rng = Random(42)
        val includeStream = (mood == MusicMood.GAMEPLAY || mood == MusicMood.LOBBY)

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val barIdx = ((t / 3.2).toInt()) % 4
            val barFrac = (t % 3.2) / 3.2
            val swell = sin(PI * barFrac) // Smooth breathing swell per chord bar

            val pad = (
                sin(2.0 * PI * chordRoots[barIdx] * t) * 0.42 +
                    sin(2.0 * PI * chordFifths[barIdx] * t) * 0.30 +
                    sin(2.0 * PI * chordNinths[barIdx] * t) * 0.16
                ) * (0.28 + 0.72 * swell) * 0.19

            // Quiet natural water stream ambience (gentle smoothed noise with slow bubble ripple modulation)
            val water = if (includeStream) {
                val white = rng.nextDouble(-1.0, 1.0)
                waterFilter1 = waterFilter1 * 0.92 + white * 0.08
                waterFilter2 = waterFilter2 * 0.85 + (white - waterFilter1) * 0.15
                val lfo = 0.65 + 0.35 * sin(2.0 * PI * 0.23 * t)
                waterFilter2 * 0.045 * lfo
            } else 0.0

            mix[i] += pad + water
        }

        // 2. Delicate plucked harp notes (32 eighth-note steps over 12.8s = 0.4s per step)
        val harpStepSamples = (sampleRate * 0.40).toInt()
        val harpDecaySamples = (sampleRate * 0.95).toInt()
        for (step in 0 until 32) {
            val bar = (step / 8) % 4
            val freq = harpPatterns[bar][step % 8]
            val startIdx = step * harpStepSamples
            for (k in 0 until harpDecaySamples) {
                val idx = (startIdx + k) % totalSamples
                val kt = k.toDouble() / sampleRate
                val attack = (k.toDouble() / (sampleRate * 0.008)).coerceAtMost(1.0)
                val env = attack * exp(-4.8 * kt)
                val pluck = sin(2.0 * PI * freq * kt) * 0.75 +
                    sin(2.0 * PI * freq * 2.0 * kt) * 0.22 * exp(-8.0 * kt) +
                    sin(2.0 * PI * freq * 3.0 * kt) * 0.06 * exp(-12.0 * kt)
                mix[idx] += pluck * env * 0.18
            }
        }

        // 3. Soft bell-like celesta melody (8 gentle chimes, 1.6s spacing)
        val bellStepSamples = (sampleRate * 1.60).toInt()
        val bellDecaySamples = (sampleRate * 1.75).toInt()
        for (m in 0 until 8) {
            val freq = melodyNotes[m]
            val startIdx = m * bellStepSamples + (sampleRate * 0.20).toInt()
            for (k in 0 until bellDecaySamples) {
                val idx = (startIdx + k) % totalSamples
                val kt = k.toDouble() / sampleRate
                val attack = (k.toDouble() / (sampleRate * 0.005)).coerceAtMost(1.0)
                val env = attack * exp(-3.4 * kt)
                // Bell partials (fundamental + 2x octave + subtle 3.01x chime shimmer)
                val bell = sin(2.0 * PI * freq * kt) * 0.72 +
                    sin(2.0 * PI * freq * 2.0 * kt) * 0.20 * exp(-5.2 * kt) +
                    sin(2.0 * PI * freq * 3.01 * kt) * 0.08 * exp(-9.0 * kt)
                mix[idx] += bell * env * 0.16
            }
        }

        // Seamless crossfade wrap on boundary (first 80ms blends smoothly)
        val fadeSamples = (sampleRate * 0.08).toInt()
        for (i in 0 until fadeSamples) {
            val w = i.toDouble() / fadeSamples
            mix[i] = mix[i] * w + mix[totalSamples - fadeSamples + i] * (1.0 - w)
        }

        return ShortArray(totalSamples) { i ->
            val v = (mix[i] * 14500.0).toInt()
            v.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    private fun getOrBuildSfx(cue: SoundCue, combo: Int): ShortArray {
        val key = "${cue.name}_${combo.coerceIn(1, 6)}"
        sfxCache[key]?.let { return it }
        val built = when (cue) {
            // Gentle pleasant bouncy click for buttons
            SoundCue.BUTTON_TAP -> buildBubbleClick(480.0, 620.0, 48)
            SoundCue.MENU_OPEN -> buildCelestaArpeggio(listOf(523.25, 659.25, 783.99), 42)
            SoundCue.MENU_CLOSE -> buildCelestaArpeggio(listOf(783.99, 659.25, 523.25), 42)
            // Soft bubbly water-droplet pops for UI tabs & tiles
            SoundCue.TAB_SWITCH, SoundCue.TILE_SELECT -> buildWaterDropletPop(520.0, 920.0, 52)
            SoundCue.WATER_RIPPLE -> buildWaterRipple(440.0)
            SoundCue.TOGGLE_ON -> buildWaterDropletPop(540.0, 960.0, 60)
            SoundCue.TOGGLE_OFF -> buildWaterDropletPop(760.0, 460.0, 58)
            SoundCue.SLIDER_TICK -> buildWaterDropletPop(720.0, 880.0, 24)
            SoundCue.BACK -> buildWaterDropletPop(620.0, 410.0, 54)
            SoundCue.REWARD_CLAIM -> buildCelestaArpeggio(listOf(587.33, 739.99, 880.0, 1174.66), 72)
            SoundCue.NOTIFICATION_POP -> buildWaterDropletPop(660.0, 1080.0, 64)
            SoundCue.OPENING_CHIME -> buildCelestaArpeggio(listOf(440.0, 587.33, 739.99, 880.0, 1174.66), 105)
            SoundCue.COUNTDOWN_TICK -> buildCelestaTone(659.25, 90, decay = 9f)
            SoundCue.COUNTDOWN_GO -> buildCelestaArpeggio(listOf(659.25, 880.0, 1174.66), 68)
            SoundCue.SWAP -> buildWaterDropletPop(420.0, 640.0, 65)
            SoundCue.INVALID_SWAP -> buildBubbleClick(320.0, 210.0, 110)
            // Juicy fruit pops & light sparkles
            SoundCue.MATCH -> buildJuicySparkle(587.33, 880.0)
            SoundCue.FRUIT_POP -> buildWaterDropletPop(620.0, 1180.0, 58)
            // Ascending musical fairy chimes per combo step
            SoundCue.CASCADE_COMBO -> {
                val shift = 1.0 + (combo.coerceIn(1, 6) - 1) * 0.11
                buildCelestaArpeggio(
                    listOf(587.33 * shift, 739.99 * shift, 880.0 * shift, 1174.66 * shift),
                    56
                )
            }
            SoundCue.FALL -> buildWaterDropletPop(300.0, 210.0, 46)
            SoundCue.GOLDEN_CHARGE -> buildCelestaArpeggio(listOf(587.33, 739.99, 880.0, 1174.66, 1479.98), 66)
            SoundCue.LIGHTNING_ZAP -> buildCelestaArpeggio(listOf(1046.50, 1318.51, 1567.98, 2093.00), 42)
            SoundCue.BOMB_BLAST -> buildJuicySparkle(392.0, 784.0)
            SoundCue.RAINBOW_BURST -> buildCelestaArpeggio(listOf(523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98), 54)
            SoundCue.MAGIC_PEACH -> buildCelestaArpeggio(listOf(587.33, 739.99, 880.0, 1174.66, 1479.98, 1760.0), 68)
            SoundCue.GARDEN_GATE_OPEN -> buildCelestaArpeggio(listOf(440.0, 554.37, 659.25, 880.0, 1108.73), 95)
            SoundCue.TUTORIAL_SUCCESS -> buildCelestaArpeggio(listOf(587.33, 739.99, 880.0, 1174.66), 62)
            SoundCue.VICTORY -> buildCelestaArpeggio(
                listOf(587.33, 739.99, 880.0, 1174.66, 1318.51, 1479.98, 1760.0),
                85
            )
            SoundCue.RETRY -> buildCelestaArpeggio(listOf(587.33, 493.88, 440.0, 369.99), 100)
        }
        if (sfxCache.size < 64) {
            sfxCache[key] = built
        }
        return built
    }

    private fun buildWaterDropletPop(startFreq: Double, endFreq: Double, durationMs: Int): ShortArray {
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val p = i.toDouble() / count
            val freq = startFreq + (endFreq - startFreq) * (p * p)
            val env = sin(PI * p) * exp(-2.5 * p)
            phase += 2.0 * PI * freq / sampleRate
            val sample = (sin(phase) + 0.15 * sin(phase * 2.0)) * env
            buffer[i] = (sample * 11500.0).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun buildBubbleClick(startFreq: Double, endFreq: Double, durationMs: Int): ShortArray {
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val p = i.toDouble() / count
            val freq = startFreq + (endFreq - startFreq) * sin(p * PI * 0.5)
            val env = exp(-9.0 * p) * sin(PI * p.coerceAtMost(0.95))
            phase += 2.0 * PI * freq / sampleRate
            buffer[i] = (sin(phase) * env * 12000.0).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun buildWaterRipple(baseFreq: Double): ShortArray {
        return buildCelestaArpeggio(listOf(baseFreq, baseFreq * 1.25, baseFreq * 1.5), 42)
    }

    private fun buildJuicySparkle(f1: Double, f2: Double): ShortArray {
        val pop = buildWaterDropletPop(540.0, 1080.0, 62)
        val chime = buildCelestaArpeggio(listOf(f1, f2, f2 * 1.33), 50)
        val total = ShortArray(maxOf(pop.size, chime.size))
        for (i in total.indices) {
            val a = if (i < pop.size) pop[i].toInt() else 0
            val b = if (i < chime.size) chime[i].toInt() else 0
            total[i] = ((a + b) / 2).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return total
    }

    private fun buildCelestaTone(freq: Double, durationMs: Int, decay: Float): ShortArray {
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val env = (i.toDouble() / (sampleRate * 0.004)).coerceAtMost(1.0) *
                exp((-decay * i.toFloat() / count.toFloat()).toDouble())
            val wave = sin(2.0 * PI * freq * t) * 0.72 +
                sin(2.0 * PI * freq * 2.0 * t) * 0.22 +
                sin(2.0 * PI * freq * 3.01 * t) * 0.08
            buffer[i] = (wave * env * 10500.0).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun buildCelestaArpeggio(freqs: List<Double>, noteMs: Int): ShortArray {
        val noteSamples = (sampleRate * noteMs) / 1000
        val tailSamples = (sampleRate * 0.14).toInt()
        val total = ShortArray(noteSamples * freqs.size + tailSamples)
        freqs.forEachIndexed { idx, freq ->
            val part = buildCelestaTone(freq, noteMs + 130, decay = 5.2f)
            val start = idx * noteSamples
            for (k in part.indices) {
                val pos = start + k
                if (pos < total.size) {
                    val mixed = total[pos].toInt() + part[k].toInt()
                    total[pos] = mixed.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
            }
        }
        return total
    }

    private fun playPcmBuffer(pcm: ShortArray, volume: Float) {
        if (pcm.isEmpty()) return
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf <= 0) return
            val byteSize = maxOf(pcm.size * 2, minBuf)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(byteSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.setVolume(volume.coerceIn(0f, 1f))
            track.write(pcm, 0, pcm.size)
            track.play()
            val durationMs = (pcm.size * 1000L) / sampleRate + 60L
            scope.launch {
                delay(durationMs)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {
                }
            }
        } catch (_: Throwable) {
            // Gracefully ignore audio errors on headless/Robolectric runners
        }
    }

    fun release() {
        stopMusicLoop()
        abandonFocusIfNeeded()
        scope.cancel()
    }
}
