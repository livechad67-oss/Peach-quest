package com.example.audio

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

enum class HapticCue {
    TAP,
    MATCH,
    COMBO,
    GOLDEN,
    REWARD,
    VICTORY,
    ERROR
}

class HapticManager(context: Context) {

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.applicationContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.applicationContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Throwable) {
        null
    }

    @Volatile
    var enabled: Boolean = true

    fun trigger(cue: HapticCue) {
        if (!enabled) return
        val vib = vibrator ?: return
        try {
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (cue) {
                    HapticCue.TAP -> VibrationEffect.createOneShot(14L, 65)
                    HapticCue.MATCH -> VibrationEffect.createOneShot(24L, 110)
                    HapticCue.COMBO -> VibrationEffect.createWaveform(longArrayOf(0, 22, 35, 32), intArrayOf(0, 120, 0, 180), -1)
                    HapticCue.GOLDEN -> VibrationEffect.createWaveform(longArrayOf(0, 35, 30, 50), intArrayOf(0, 170, 0, 220), -1)
                    HapticCue.REWARD -> VibrationEffect.createWaveform(longArrayOf(0, 25, 40, 40), intArrayOf(0, 130, 0, 190), -1)
                    HapticCue.VICTORY -> VibrationEffect.createWaveform(longArrayOf(0, 30, 40, 35, 45, 55), intArrayOf(0, 140, 0, 180, 0, 230), -1)
                    HapticCue.ERROR -> VibrationEffect.createOneShot(40L, 140)
                }
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(
                    when (cue) {
                        HapticCue.TAP -> 14L
                        HapticCue.MATCH -> 24L
                        HapticCue.COMBO, HapticCue.REWARD -> 45L
                        HapticCue.GOLDEN, HapticCue.VICTORY -> 75L
                        HapticCue.ERROR -> 40L
                    }
                )
            }
        } catch (_: Throwable) {
            // Safely ignore on devices/emulators without vibrator hardware
        }
    }
}
