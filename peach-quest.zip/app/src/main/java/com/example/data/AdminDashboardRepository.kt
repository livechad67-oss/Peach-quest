package com.example.data

import android.content.Context
import android.util.Log
import com.example.R
import com.example.model.AdminMetricSnapshotDoc
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

enum class FirestoreOperation {
    CREATE, UPDATE, DELETE, GET, LIST
}

class AdminDashboardRepository(context: Context) {

    private val databaseId: String = context.getString(R.string.firestore_database_id)
    private val db: FirebaseFirestore by lazy {
        FirebaseFirestore.getInstance(databaseId)
    }

    fun isAllowlistedAdmin(email: String?, emailVerified: Boolean): Boolean {
        if (!emailVerified || email.isNullOrBlank()) return false
        return ADMIN_EMAIL_ALLOWLIST.any { it.equals(email.trim(), ignoreCase = true) }
    }

    fun observeAdminMetrics(): Flow<List<AdminMetricSnapshotDoc>> {
        return db.collection("adminMetrics")
            .snapshots(MetadataChanges.INCLUDE)
            .map { querySnapshot ->
                querySnapshot.documents.mapNotNull { doc ->
                    doc.toObject(
                        AdminMetricSnapshotDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
            }
    }

    /**
     * Tests real server-side Firestore security rule authorization by verifying read/write access
     * on the owner-only /adminMetrics/overview document without inventing any player metrics.
     */
    suspend fun verifyOwnerConnection(uid: String): Result<Unit> {
        val docRef = db.collection("adminMetrics").document("overview")
        val path = "adminMetrics/overview"
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val createPayload = mapOf(
                    "metricKey" to "overview",
                    "sourceNote" to "CLASTAD Owner Console verified — connect Firebase Analytics / BigQuery export for global aggregates.",
                    "updatedByUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(createPayload).await()
            } else {
                val updatePayload = mapOf(
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updatePayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, FirestoreOperation.UPDATE, path)
            Result.failure(e)
        }
    }

    private fun handleFirestoreError(
        error: Exception,
        operation: FirestoreOperation,
        path: String
    ) {
        val currentUser = try {
            Firebase.auth.currentUser
        } catch (_: IllegalStateException) {
            null
        }
        val payload = """
            {
              "error": "${error.message?.replace("\"", "'") ?: "Unknown Firestore error"}",
              "operation": "${operation.name}",
              "path": "$path",
              "uid": "${currentUser?.uid ?: "null"}",
              "provider": "${currentUser?.providerData?.joinToString(",") { it.providerId } ?: "none"}"
            }
        """.trimIndent()
        Log.e(TAG, "Admin Firestore error: $payload", error)
    }

    companion object {
        private const val TAG = "AdminDashboardRepo"
        val ADMIN_EMAIL_ALLOWLIST = setOf("livechad67@gmail.com")
    }
}
