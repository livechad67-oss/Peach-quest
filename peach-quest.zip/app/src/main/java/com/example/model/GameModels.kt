package com.example.model

import androidx.annotation.Keep
import androidx.compose.ui.graphics.Color
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class FruitType(
    val displayName: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val symbolTag: String
) {
    PEACH("Peach", Color(0xFFFF9872), Color(0xFFFF6E8A), "P"),
    STRAWBERRY("Strawberry", Color(0xFFFF5277), Color(0xFFFF90AA), "S"),
    RED_APPLE("Red Apple", Color(0xFFE93B52), Color(0xFFFF7A8F), "RA"),
    GREEN_APPLE("Green Apple", Color(0xFF42C27D), Color(0xFF8EE5B3), "GA"),
    ORANGE("Orange", Color(0xFFFF9424), Color(0xFFFFCA68), "O"),
    LEMON("Lemon", Color(0xFFFFDC3C), Color(0xFFFFF399), "L"),
    WATERMELON("Watermelon", Color(0xFF34C8A4), Color(0xFFFF607B), "W"),
    GRAPES("Grapes", Color(0xFF935BF2), Color(0xFFC5A3FF), "G"),
    BLUEBERRY("Blueberry", Color(0xFF4994FF), Color(0xFF95C3FF), "B"),
    BLACKBERRY("Blackberry", Color(0xFF4C3A78), Color(0xFF836BB8), "BK"),
    CHERRY("Cherries", Color(0xFFE01E44), Color(0xFFFF6B86), "CH"),
    PEAR("Pear", Color(0xFF9ED42B), Color(0xFFD5F096), "PR"),
    PINEAPPLE("Pineapple", Color(0xFFF6AD2B), Color(0xFFFFDC7A), "PN"),
    MANGO("Mango", Color(0xFFFF9B26), Color(0xFFFF6433), "M"),
    BANANA("Banana", Color(0xFFFFE548), Color(0xFFFFF7A6), "BN"),
    KIWI("Kiwi", Color(0xFF6BBF47), Color(0xFFC0EB9E), "K"),
    COCONUT("Coconut", Color(0xFF8D6346), Color(0xFFFDF8F2), "C"),
    DRAGON_FRUIT("Dragon Fruit", Color(0xFFEF478B), Color(0xFFFFBDD9), "DF"),
    RASPBERRY("Raspberry", Color(0xFFE3366E), Color(0xFFFF88AE), "R"),
    PLUM("Plum", Color(0xFF7B449C), Color(0xFFB580D4), "PL"),
    POMEGRANATE("Pomegranate", Color(0xFFC72652), Color(0xFFF57497), "PM"),
    PAPAYA("Papaya", Color(0xFFFF835C), Color(0xFFFFBC7D), "PY"),
    AVOCADO("Avocado", Color(0xFF569440), Color(0xFFBBE38D), "AV"),
    PASSION_FRUIT("Passion Fruit", Color(0xFF8648D6), Color(0xFFFFCC33), "PF"),
    GOLDEN_PINEAPPLE("Magic Peach", Color(0xFFFFC533), Color(0xFFFFF09E), "★");

    companion object {
        val collectibleFruits: List<FruitType>
            get() = entries.filter { it != GOLDEN_PINEAPPLE }
    }
}

enum class SpecialKind {
    NONE,
    LIGHTNING_ROW,
    LIGHTNING_COL,
    BOMB,
    RAINBOW,
    MAGIC_PEACH;

    val isSpecial: Boolean get() = this != NONE
}

enum class BoosterType(
    val id: String,
    val title: String,
    val shortDescription: String,
    val accentColor: Color
) {
    RAINBOW(
        id = "rainbow",
        title = "Rainbow",
        shortDescription = "Clears every fruit of the tapped kind!",
        accentColor = Color(0xFF935BF2)
    ),
    BOMB(
        id = "bomb",
        title = "Bomb",
        shortDescription = "3×3 fruit splash blast around a tile!",
        accentColor = Color(0xFFFF5277)
    ),
    LIGHTNING(
        id = "lightning",
        title = "Lightning",
        shortDescription = "Zaps across the entire row & column!",
        accentColor = Color(0xFF35AEE5)
    ),
    MAGIC_PEACH(
        id = "magic_peach",
        title = "Magic Peach",
        shortDescription = "Golden crown burst + matches extra fruits!",
        accentColor = Color(0xFFFF8811)
    );

    companion object {
        fun defaultStarterInventory(): Map<BoosterType, Int> = mapOf(
            RAINBOW to 2,
            BOMB to 2,
            LIGHTNING to 2,
            MAGIC_PEACH to 2
        )
    }
}

enum class FruitSkin(
    val id: String,
    val title: String,
    val description: String,
    val requiredStars: Int
) {
    CLASSIC("classic", "Dewdrop Gloss", "Soft, bubbly glossy highlights on every fruit", 0),
    CANDY_GLAZE("candy_glaze", "Crystal Sparkle", "Extra twinkling water-drop shimmer", 10),
    ROYAL_CROWN("royal_gold", "Sunbeam Halo", "Warm golden glow around every fruit", 25);

    companion object {
        fun fromId(id: String): FruitSkin = entries.find { it.id == id } ?: CLASSIC
    }
}

enum class ObstacleType(val displayName: String) {
    NONE("None"),
    ICE("Frost Dew"),
    VINES("Garden Vines"),
    CRATE("Mossy Crate")
}

data class TileCell(
    val id: Long,
    val row: Int,
    val col: Int,
    val fruit: FruitType?,
    val obstacle: ObstacleType = ObstacleType.NONE,
    val obstacleHp: Int = 0,
    val special: SpecialKind = SpecialKind.NONE,
    val isVoid: Boolean = false,
    val isWatered: Boolean = false
) {
    val isMovable: Boolean
        get() = !isVoid && fruit != null && obstacle != ObstacleType.VINES && obstacle != ObstacleType.CRATE

    val blocksGravity: Boolean
        get() = isVoid || obstacle == ObstacleType.CRATE || obstacle == ObstacleType.VINES

    val isGoldenPineapple: Boolean
        get() = fruit == FruitType.GOLDEN_PINEAPPLE || special == SpecialKind.MAGIC_PEACH

    val isSpecialFruit: Boolean
        get() = !isVoid && (special.isSpecial || fruit == FruitType.GOLDEN_PINEAPPLE)
}

enum class ObjectiveKind {
    SCORE,
    COLLECT_FRUIT,
    CLEAR_OBSTACLE,
    TRIGGER_GOLDEN_WAVE
}

data class LevelObjective(
    val kind: ObjectiveKind,
    val targetAmount: Int,
    val fruitType: FruitType? = null,
    val obstacleType: ObstacleType? = null,
    val label: String
)

enum class Chapter(
    val number: Int,
    val title: String,
    val subtitle: String,
    val accentColor: Color,
    val skyColor: Color,
    val meadowColor: Color
) {
    SUNNY_SPROUT(
        1,
        "Sunny Sprout",
        "Peaches, strawberries, grapes, bananas & sunny blossoms",
        Color(0xFFFF7D29),
        Color(0xFFD6F2FF),
        Color(0xFF7BE29F)
    ),
    BERRY_WOODS(
        2,
        "Berry Woods",
        "Sparkling frost tiles & sweet woodland berries",
        Color(0xFFFF5277),
        Color(0xFFE7EEFF),
        Color(0xFF63D094)
    ),
    TROPICAL_PARADISE(
        3,
        "Tropical Paradise",
        "Sunlit streams, citrus groves, crates & garden vines",
        Color(0xFF28A9E0),
        Color(0xFFCFF6FF),
        Color(0xFF49D4A7)
    ),
    BLOSSOM_VALLEY(
        4,
        "Blossom Valley",
        "Enchanted 24-fruit celebration & royal garden blooms",
        Color(0xFF935BF2),
        Color(0xFFFFE5F2),
        Color(0xFF83DFB2)
    );

    companion object {
        fun forLevel(levelNumber: Int): Chapter = when (levelNumber) {
            in 1..7 -> SUNNY_SPROUT
            in 8..15 -> BERRY_WOODS
            in 16..22 -> TROPICAL_PARADISE
            else -> BLOSSOM_VALLEY
        }
    }
}

data class LevelDefinition(
    val levelNumber: Int,
    val title: String,
    val chapter: Chapter,
    val rows: Int,
    val cols: Int,
    val availableFruits: List<FruitType>,
    val maxMoves: Int,
    val objectives: List<LevelObjective>,
    val starThresholds: Triple<Int, Int, Int>,
    val initialObstacles: Map<Pair<Int, Int>, Pair<ObstacleType, Int>> = emptyMap(),
    val voidCells: Set<Pair<Int, Int>> = emptySet(),
    val initialWaterCells: Set<Pair<Int, Int>> = emptySet(),
    val tutorialTip: String? = null
)

data class LevelResult(
    val levelNumber: Int,
    val stars: Int,
    val highScore: Int,
    val bestCombo: Int = 1
)

enum class GraphicsQuality(val label: String, val description: String) {
    AUTO("Auto", "Automatically adjusts effects for your device"),
    HIGH("Lush", "Full ripples, sparkles & floating petals"),
    BALANCED("Balanced", "Smooth 60 FPS with light effects"),
    LOW_RAM("Power Saver", "Minimal particles for older devices")
}

data class GardenSection(
    val index: Int,
    val title: String,
    val description: String,
    val requiredCompletedLevels: Int
)

data class AchievementDefinition(
    val id: String,
    val title: String,
    val description: String,
    val rewardText: String
)

data class GameNotification(
    val id: Long,
    val title: String,
    val message: String,
    val isUnread: Boolean = true
)

data class AppSettings(
    val masterVolume: Float = 0.85f,
    val musicVolume: Float = 0.65f,
    val sfxVolume: Float = 0.85f,
    val muted: Boolean = false,
    val hapticEnabled: Boolean = true,
    val animationsEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val colorblindSymbols: Boolean = false,
    val analyticsConsent: Boolean = false,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.AUTO
) {
    val isMusicOn: Boolean get() = !muted && musicVolume > 0.01f
    val isSfxOn: Boolean get() = !muted && sfxVolume > 0.01f
}

data class PlayerProgress(
    val playerUsername: String = "",
    val legalAccepted: Boolean = false,
    val tutorialCompleted: Boolean = false,
    val highestUnlockedLevel: Int = 1,
    val levelResults: Map<Int, LevelResult> = emptyMap(),
    val dailyStreak: Int = 0,
    val lastDailyClaimDay: Int = 0,
    val unlockedFruitSkins: List<String> = listOf(FruitSkin.CLASSIC.id),
    val selectedFruitSkin: String = FruitSkin.CLASSIC.id,
    val unlockedAchievements: List<String> = emptyList(),
    val boosterInventory: Map<BoosterType, Int> = BoosterType.defaultStarterInventory(),
    val seenMechanics: Set<String> = emptySet(),
    val activeSnapshot: SavedBoardSnapshot? = null
) {
    val completedCount: Int get() = levelResults.count { it.value.stars > 0 }
    val totalStars: Int get() = levelResults.values.sumOf { it.stars }
    val totalScore: Int get() = levelResults.values.sumOf { it.highScore }
}

data class SavedBoardSnapshot(
    val levelNumber: Int,
    val rows: Int,
    val cols: Int,
    val movesRemaining: Int,
    val score: Int,
    val collectedFruits: Map<FruitType, Int>,
    val clearedObstacles: Map<ObstacleType, Int>,
    val goldenWavesTriggered: Int,
    val cells: List<TileCell>
)

data class DeviceTelemetrySummary(
    val firstOpenTimestampMs: Long = 0L,
    val sessionCount: Int = 0,
    val totalSessionDurationSec: Long = 0L,
    val levelStarts: Map<Int, Int> = emptyMap(),
    val levelCompletes: Map<Int, Int> = emptyMap(),
    val levelFailures: Map<Int, Int> = emptyMap(),
    val avgFpsEstimate: Float = 0f,
    val nonFatalErrorCount: Int = 0
)

@Keep
@IgnoreExtraProperties
data class AdminMetricSnapshotDoc(
    @DocumentId val id: String = "",
    val metricKey: String = "overview",
    val totalFirstOpens: Long? = null,
    val dailyNewPlayers: Long? = null,
    val dailyActivePlayers: Long? = null,
    val monthlyActivePlayers: Long? = null,
    val levelsStarted: Long? = null,
    val levelsCompleted: Long? = null,
    val levelsFailed: Long? = null,
    val avgSessionDurationSec: Long? = null,
    val day1RetentionPct: Double? = null,
    val day7RetentionPct: Double? = null,
    val topFailureLevels: List<Int>? = null,
    val countrySummaryNote: String? = null,
    val crashFreeSessionsPct: Double? = null,
    val sourceNote: String? = null,
    val updatedByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

sealed interface UsernameValidation {
    data class Valid(val normalized: String) : UsernameValidation
    data class Invalid(val reason: String) : UsernameValidation
}

object UsernameValidator {
    private val allowedCharsRegex = Regex("^[A-Za-z0-9 _\\-]{3,18}$")
    private val blockedTerms = setOf(
        "fuck", "shit", "bitch", "asshole", "bastard", "cunt", "dick", "cock",
        "pussy", "slut", "whore", "nigger", "nigga", "faggot", "retard", "rape",
        "nazi", "porn", "sex", "kill", "suicide", "admin", "clastad", "peachquest",
        "moderator", "official", "support", "staff"
    )

    fun validate(rawInput: String): UsernameValidation {
        val trimmed = rawInput.trim().replace(Regex("\\s+"), " ")
        if (trimmed.length < 3) {
            return UsernameValidation.Invalid("Please enter at least 3 characters.")
        }
        if (trimmed.length > 18) {
            return UsernameValidation.Invalid("Display username must be 18 characters or fewer.")
        }
        if (!allowedCharsRegex.matches(trimmed)) {
            return UsernameValidation.Invalid("Use only letters, numbers, spaces, '-' or '_'.")
        }
        val compact = trimmed.lowercase().replace(Regex("[ _\\-]"), "")
        val tokens = trimmed.lowercase().split(' ', '-', '_')
        val hitsBlocked = blockedTerms.any { term ->
            term in tokens || (term.length >= 4 && compact.contains(term))
        }
        if (hitsBlocked) {
            return UsernameValidation.Invalid("Please choose a friendly, appropriate display name.")
        }
        return UsernameValidation.Valid(trimmed)
    }
}
