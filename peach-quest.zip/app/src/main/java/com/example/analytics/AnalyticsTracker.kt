package com.example.analytics

import android.content.Context
import android.os.Bundle
import com.example.model.Chapter
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * Wraps Firebase Analytics with explicit player consent controls and zero PII.
 * Never logs usernames, email addresses, or precise location.
 */
class AnalyticsTracker(context: Context) {

    private val firebaseAnalytics: FirebaseAnalytics? = try {
        FirebaseAnalytics.getInstance(context.applicationContext)
    } catch (_: Throwable) {
        null
    }

    @Volatile
    private var consentEnabled: Boolean = false

    fun updateConsent(enabled: Boolean) {
        consentEnabled = enabled
        try {
            firebaseAnalytics?.setAnalyticsCollectionEnabled(enabled)
        } catch (_: Throwable) {
        }
    }

    fun isSdkConnected(): Boolean = firebaseAnalytics != null

    fun logAppSessionStart(isFirstOpen: Boolean) {
        if (!consentEnabled) return
        try {
            val bundle = Bundle().apply {
                putLong("is_first_open", if (isFirstOpen) 1L else 0L)
            }
            firebaseAnalytics?.logEvent(FirebaseAnalytics.Event.APP_OPEN, bundle)
        } catch (_: Throwable) {
        }
    }

    fun logLevelStart(levelNumber: Int, chapter: Chapter) {
        if (!consentEnabled) return
        try {
            val bundle = Bundle().apply {
                putString(FirebaseAnalytics.Param.LEVEL_NAME, "level_$levelNumber")
                putLong(FirebaseAnalytics.Param.LEVEL, levelNumber.toLong())
                putString("chapter_name", chapter.title)
            }
            firebaseAnalytics?.logEvent(FirebaseAnalytics.Event.LEVEL_START, bundle)
        } catch (_: Throwable) {
        }
    }

    fun logLevelEnd(levelNumber: Int, success: Boolean, stars: Int, score: Int, movesRemaining: Int) {
        if (!consentEnabled) return
        try {
            val bundle = Bundle().apply {
                putString(FirebaseAnalytics.Param.LEVEL_NAME, "level_$levelNumber")
                putLong(FirebaseAnalytics.Param.LEVEL, levelNumber.toLong())
                putLong(FirebaseAnalytics.Param.SUCCESS, if (success) 1L else 0L)
                putLong("stars_earned", stars.toLong())
                putLong(FirebaseAnalytics.Param.SCORE, score.toLong())
                putLong("moves_remaining", movesRemaining.toLong())
            }
            firebaseAnalytics?.logEvent(FirebaseAnalytics.Event.LEVEL_END, bundle)
        } catch (_: Throwable) {
        }
    }

    fun logTutorialCompleted() {
        if (!consentEnabled) return
        try {
            firebaseAnalytics?.logEvent(FirebaseAnalytics.Event.TUTORIAL_COMPLETE, null)
        } catch (_: Throwable) {
        }
    }
}
