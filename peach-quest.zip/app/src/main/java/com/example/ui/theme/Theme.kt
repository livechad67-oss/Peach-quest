package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PeachQuestColorScheme = lightColorScheme(
    primary = PeachOrange,
    onPrimary = Color.White,
    primaryContainer = SoftPeach,
    onPrimaryContainer = BerryInk,
    secondary = FreshMint,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD8FAEA),
    onSecondaryContainer = BerryInk,
    tertiary = StreamBlue,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFDFF4FF),
    onTertiaryContainer = BerryInk,
    background = CreamyWhite,
    onBackground = BerryInk,
    surface = CreamSurface,
    onSurface = BerryInk,
    surfaceVariant = Color(0xFFFFF2E7),
    onSurfaceVariant = CocoaMuted,
    outline = SoftRoseBorder,
    error = Color(0xFFD92B4B),
    onError = Color.White
)

val PeachQuestShapes = Shapes(
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(40.dp)
)

@Composable
fun PeachQuestTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PeachQuestColorScheme,
        typography = PeachQuestTypography,
        shapes = PeachQuestShapes,
        content = content
    )
}
