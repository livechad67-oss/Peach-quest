package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Park
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.levels.LevelRepository
import com.example.levels.OrchardCatalog
import com.example.model.AppSettings
import com.example.model.Chapter
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.LevelDefinition
import com.example.model.ObjectiveKind
import com.example.model.ObstacleType
import com.example.model.PlayerProgress
import com.example.ui.components.AquaRoundIconButton
import com.example.ui.components.FruitIconCanvas
import com.example.ui.components.GameStripedBanner
import com.example.ui.components.GameWoodenFrameModal
import com.example.ui.components.GlossyGreenPlayButton
import com.example.ui.components.PeachBlossomGoalIcon
import com.example.ui.components.PeachCard
import com.example.ui.components.PeachPortraitFrame
import com.example.ui.components.PeachPrimaryButton
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.CreamParchment
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.CreamParchmentLight
import com.example.ui.theme.FreshMint
import com.example.ui.theme.GoldenBevel
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.LavenderDeep
import com.example.ui.theme.MeadowDeepGreen
import com.example.ui.theme.MeadowGreen
import com.example.ui.theme.PeachBannerShadow
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.SoftPeach
import com.example.ui.theme.SunWarm
import com.example.ui.theme.WaterSurfaceDark
import com.example.ui.theme.WaterSurfaceLight
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LevelMapScreen(
    progress: PlayerProgress,
    settings: AppSettings,
    graphicsQuality: GraphicsQuality,
    canClaimDaily: Boolean,
    onClaimDailyReward: () -> Unit,
    onOpenGarden: () -> Unit,
    onOpenVault: () -> Unit,
    onSelectLevel: (Int) -> Unit,
    onBack: () -> Unit
) {
    var previewLevel by remember { mutableStateOf<LevelDefinition?>(null) }
    var showDailyDialog by remember { mutableStateOf(false) }

    BackHandler {
        when {
            previewLevel != null -> previewLevel = null
            showDailyDialog -> showDailyDialog = false
            else -> onBack()
        }
    }

    val levelsByWorld = remember {
        Chapter.entries.map { chapter ->
            chapter to LevelRepository.allLevels.filter { it.chapter == chapter }
        }
    }

    val pulse = if (settings.animationsEnabled) {
        val inf = rememberInfiniteTransition(label = "map_pulse")
        val p by inf.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "p"
        )
        p
    } else 0.5f

    // Deep Turquoise Ocean & Emerald Islands Background (Screenshot 7)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF15769E), Color(0xFF1D96B2), Color(0xFF13688E))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 620.dp)
                .align(Alignment.Center)
        ) {
            // Top Striped Peach HUD Banner
            GameStripedBanner {
                AquaRoundIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back to Home",
                    onClick = onBack,
                    size = 46.dp,
                    testTag = "level_map_back"
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Peach Adventure Map",
                        style = MaterialTheme.typography.titleLarge,
                        color = CreamParchmentLight,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "${progress.completedCount} of 30 Gardens Cleared",
                        style = MaterialTheme.typography.labelMedium,
                        color = CreamParchment
                    )
                }
                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.dp, GoldenBevel),
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Star, contentDescription = null, tint = GoldenStar, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${progress.totalStars}/90",
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Action Pills (Daily Gift, Profile & 24, Garden)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = if (canClaimDaily) Color(0xFFFFE57F) else CreamParchment,
                    border = BorderStroke(2.dp, if (canClaimDaily) GoldenStar else CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    onClick = { showDailyDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("daily_rewards_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 9.dp, horizontal = 8.dp)
                    ) {
                        Icon(
                            Icons.Rounded.CardGiftcard,
                            contentDescription = null,
                            tint = if (canClaimDaily) PeachOrangeDeep else BlossomPink,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (canClaimDaily) "Daily Gift!" else "Day ${progress.dailyStreak}",
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.dp, CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    onClick = onOpenVault,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("fruit_vault_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 9.dp, horizontal = 8.dp)
                    ) {
                        Icon(Icons.Rounded.EmojiEvents, contentDescription = null, tint = PeachOrangeDeep, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Profile & 24",
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.dp, CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    onClick = onOpenGarden,
                    modifier = Modifier
                        .weight(0.85f)
                        .testTag("garden_progress_card")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 9.dp, horizontal = 8.dp)
                    ) {
                        Icon(Icons.Rounded.Park, contentDescription = null, tint = MeadowDeepGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Garden",
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4 Illustrated Worlds with Turquoise River Channels & Island Pedestals
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp)
                    .testTag("world_map_list")
            ) {
                items(levelsByWorld) { (chapter, levels) ->
                    WorldAdventureCard(
                        chapter = chapter,
                        levels = levels,
                        progress = progress,
                        animationsEnabled = settings.animationsEnabled,
                        pulse = pulse,
                        onLevelTap = { tappedLevel ->
                            previewLevel = tappedLevel
                        }
                    )
                }
                item { Spacer(modifier = Modifier.height(18.dp)) }
            }
        }

        // Screenshot 2 Style Striped Peach Level Preview Modal
        AnimatedVisibility(
            visible = previewLevel != null,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.90f, animationSpec = tween(220)),
            exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.92f, animationSpec = tween(150))
        ) {
            previewLevel?.let { lvl ->
                LevelPreviewModal(
                    level = lvl,
                    bestStars = progress.levelResults[lvl.levelNumber]?.stars ?: 0,
                    handSlide = pulse,
                    onPlay = {
                        previewLevel = null
                        onSelectLevel(lvl.levelNumber)
                    },
                    onClose = { previewLevel = null }
                )
            }
        }

        // Daily Meadow Gifts Modal
        if (showDailyDialog) {
            val currentDay = (progress.dailyStreak % 7) + if (canClaimDaily) 1 else 0
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x991A0D07))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                GameWoodenFrameModal(
                    title = "7-Day Meadow Gifts",
                    onClose = { showDailyDialog = false },
                    modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth()
                ) {
                    Text(
                        text = "Current Streak: ${progress.dailyStreak} day${if (progress.dailyStreak == 1) "" else "s"}",
                        style = MaterialTheme.typography.titleMedium,
                        color = BerryInk,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        OrchardCatalog.dailyRewards.forEach { item ->
                            val claimed = item.dayNumber <= progress.dailyStreak
                            val isToday = canClaimDaily && item.dayNumber == currentDay
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = when {
                                    isToday -> Color(0xFFFFE57F)
                                    claimed -> Color(0xFFD4F5DD)
                                    else -> CreamParchmentLight
                                },
                                border = BorderStroke(1.5.dp, if (isToday) GoldenStar else CreamParchmentBevel),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${item.title}: ${item.rewardSummary}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isToday) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        color = BerryInk
                                    )
                                    Text(
                                        text = when {
                                            isToday -> "TODAY"
                                            claimed -> "✓"
                                            else -> "+${item.bonusPoints}"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (isToday) PeachOrangeDeep else CocoaMuted,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    if (canClaimDaily) {
                        GlossyGreenPlayButton(
                            onClick = {
                                onClaimDailyReward()
                                showDailyDialog = false
                            },
                            label = "Claim Gift!",
                            minHeight = 56.dp,
                            testTag = "claim_daily_confirm",
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        PeachPrimaryButton(
                            onClick = { showDailyDialog = false },
                            containerColor = PeachOrangeDeep,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorldAdventureCard(
    chapter: Chapter,
    levels: List<LevelDefinition>,
    progress: PlayerProgress,
    animationsEnabled: Boolean,
    pulse: Float,
    onLevelTap: (LevelDefinition) -> Unit
) {
    val nodeSpacing = 96.dp
    val topPadding = 22.dp
    val canvasHeight = nodeSpacing * levels.size + 24.dp

    val xFractions = remember(levels.size) {
        levels.indices.map { idx ->
            when (idx % 4) {
                0 -> 0.25f
                1 -> 0.52f
                2 -> 0.76f
                else -> 0.48f
            }
        }
    }

    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(WaterSurfaceLight, WaterSurfaceDark)))
            .border(3.dp, CreamParchmentBevel, shape)
            .testTag("world_card_${chapter.number}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // World Chapter Header Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(chapter.accentColor, PeachOrangeDeep)))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "World ${chapter.number}: ${chapter.title}",
                            style = MaterialTheme.typography.titleLarge,
                            color = CreamParchmentLight,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = chapter.subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CreamParchment
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(99.dp),
                        color = CreamParchment,
                        border = BorderStroke(2.dp, GoldenBevel)
                    ) {
                        val clearedInWorld = levels.count { (progress.levelResults[it.levelNumber]?.stars ?: 0) > 0 }
                        Text(
                            text = "$clearedInWorld/${levels.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Illustrated Turquoise River, Emerald Islands, Wooden Docks & Pedestal Nodes
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(canvasHeight)
            ) {
                val widthDp = maxWidth
                val nodeSize = 62.dp

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val stepPx = nodeSpacing.toPx()
                    val topPx = topPadding.toPx() + nodeSize.toPx() / 2f

                    // Left & Right sandy beaches + emerald island hills (Screenshot 7 look)
                    val leftIsland = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(w * 0.24f, 0f)
                        cubicTo(w * 0.34f, h * 0.22f, w * 0.14f, h * 0.45f, w * 0.28f, h * 0.68f)
                        cubicTo(w * 0.36f, h * 0.84f, w * 0.18f, h * 0.94f, w * 0.24f, h)
                        lineTo(0f, h)
                        close()
                    }
                    drawPath(leftIsland, Color(0xFFE7C77D)) // Sandy shoreline
                    val leftGrass = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(w * 0.19f, 0f)
                        cubicTo(w * 0.28f, h * 0.22f, w * 0.09f, h * 0.45f, w * 0.22f, h * 0.68f)
                        cubicTo(w * 0.29f, h * 0.84f, w * 0.12f, h * 0.94f, w * 0.18f, h)
                        lineTo(0f, h)
                        close()
                    }
                    drawPath(leftGrass, MeadowGreen)

                    val rightIsland = Path().apply {
                        moveTo(w, 0f)
                        lineTo(w * 0.78f, 0f)
                        cubicTo(w * 0.68f, h * 0.25f, w * 0.86f, h * 0.52f, w * 0.72f, h * 0.78f)
                        cubicTo(w * 0.66f, h * 0.90f, w * 0.80f, h * 0.96f, w * 0.76f, h)
                        lineTo(w, h)
                        close()
                    }
                    drawPath(rightIsland, Color(0xFFE7C77D))
                    val rightGrass = Path().apply {
                        moveTo(w, 0f)
                        lineTo(w * 0.83f, 0f)
                        cubicTo(w * 0.74f, h * 0.25f, w * 0.91f, h * 0.52f, w * 0.78f, h * 0.78f)
                        cubicTo(w * 0.73f, h * 0.90f, w * 0.86f, h * 0.96f, w * 0.82f, h)
                        lineTo(w, h)
                        close()
                    }
                    drawPath(rightGrass, MeadowDeepGreen)

                    // Scenic peach trees, wooden piers & island cottages along the banks
                    levels.forEachIndexed { idx, _ ->
                        val ny = topPx + idx * stepPx
                        if (idx % 2 == 0) {
                            // Left bank tree + peach
                            drawMapTree(Offset(w * 0.09f, ny - 10f), 20f)
                        } else {
                            // Right bank cottage or wooden dock
                            drawMapCottage(Offset(w * 0.90f, ny - 6f), 18f)
                        }
                    }

                    // Sparkling water ripples
                    for (r in 0 until 7) {
                        val ry = (r + 0.5f) * (h / 7f)
                        val rx = w * (0.36f + (r % 3) * 0.14f)
                        drawLine(
                            color = Color.White.copy(alpha = 0.25f),
                            start = Offset(rx - 18f, ry),
                            end = Offset(rx + 18f, ry),
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )
                    }

                    // Dotted cream path along the river connecting every level pedestal
                    val points = levels.indices.map { i ->
                        Offset(w * xFractions[i], topPx + i * stepPx)
                    }
                    if (points.size >= 2) {
                        val path = Path().apply {
                            moveTo(points[0].x, points[0].y)
                            for (i in 0 until points.lastIndex) {
                                val p0 = points[i]
                                val p1 = points[i + 1]
                                val midY = (p0.y + p1.y) / 2f
                                cubicTo(p0.x, midY, p1.x, midY, p1.x, p1.y)
                            }
                        }
                        drawPath(
                            path = path,
                            color = Color(0xFF0A437A).copy(alpha = 0.35f),
                            style = Stroke(width = 16f, cap = StrokeCap.Round)
                        )
                        drawPath(
                            path = path,
                            color = CreamParchmentLight.copy(alpha = 0.88f),
                            style = Stroke(
                                width = 6.5f,
                                cap = StrokeCap.Round,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 16f))
                            )
                        )
                    }
                }

                // Level Pedestal Nodes + Hovering Mascot Portrait on Current Level
                levels.forEachIndexed { i, lvl ->
                    val unlocked = lvl.levelNumber <= progress.highestUnlockedLevel
                    val isCurrent = lvl.levelNumber == progress.highestUnlockedLevel
                    val stars = progress.levelResults[lvl.levelNumber]?.stars ?: 0
                    val completed = stars > 0
                    val centerX = widthDp * xFractions[i]
                    val nodeY = topPadding + nodeSpacing * i

                    Box(
                        modifier = Modifier
                            .offset(x = centerX - 48.dp, y = nodeY)
                            .width(96.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable(enabled = unlocked) { onLevelTap(lvl) }
                            .padding(vertical = 2.dp)
                            .testTag("level_tile_${lvl.levelNumber}"),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(nodeSize)
                            ) {
                                // Pedestal Shape / Crown / Lavender Stepping Stone
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val cx = this.size.width / 2f
                                    val cy = this.size.height / 2f
                                    val rad = this.size.minDimension * 0.43f

                                    if (isCurrent) {
                                        drawCircle(
                                            color = SunWarm.copy(alpha = 0.42f + 0.25f * pulse),
                                            radius = rad * 1.28f,
                                            center = Offset(cx, cy)
                                        )
                                    }

                                    when {
                                        completed -> {
                                            // Golden Crown Pedestal (Screenshot 2 & 7!)
                                            val crown = Path().apply {
                                                moveTo(cx - rad * 0.72f, cy + rad * 0.52f)
                                                lineTo(cx - rad * 0.92f, cy - rad * 0.48f)
                                                lineTo(cx - rad * 0.36f, cy - rad * 0.12f)
                                                lineTo(cx, cy - rad * 0.78f)
                                                lineTo(cx + rad * 0.36f, cy - rad * 0.12f)
                                                lineTo(cx + rad * 0.92f, cy - rad * 0.48f)
                                                lineTo(cx + rad * 0.72f, cy + rad * 0.52f)
                                                close()
                                            }
                                            drawPath(
                                                crown,
                                                Brush.verticalGradient(listOf(Color(0xFFFFEA78), GoldenStar, Color(0xFFD47D08)))
                                            )
                                            drawPath(crown, BerryInk.copy(alpha = 0.75f), style = Stroke(width = 4f))
                                        }
                                        isCurrent -> {
                                            // Active Magenta-Peach Glowing Medallion
                                            drawCircle(
                                                brush = Brush.verticalGradient(listOf(Color(0xFFFF6CA8), BlossomPink, PeachOrangeDeep)),
                                                radius = rad,
                                                center = Offset(cx, cy)
                                            )
                                            drawCircle(Color(0xFFFFE57F), rad, Offset(cx, cy), style = Stroke(width = 5f))
                                        }
                                        unlocked -> {
                                            drawCircle(
                                                brush = Brush.verticalGradient(listOf(PeachOrange, PeachOrangeDeep)),
                                                radius = rad,
                                                center = Offset(cx, cy)
                                            )
                                            drawCircle(CreamParchmentLight, rad, Offset(cx, cy), style = Stroke(width = 4f))
                                        }
                                        else -> {
                                            // Locked Lavender Stepping Stone (Screenshot 7)
                                            drawCircle(
                                                brush = Brush.verticalGradient(listOf(SoftLavender, LavenderDeep)),
                                                radius = rad * 0.92f,
                                                center = Offset(cx, cy)
                                            )
                                            drawCircle(Color(0xFF473775), rad * 0.92f, Offset(cx, cy), style = Stroke(width = 3.5f))
                                        }
                                    }
                                }

                                if (unlocked) {
                                    Text(
                                        text = "${lvl.levelNumber}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (completed) BerryInk else Color.White
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.Lock,
                                        contentDescription = "Locked level ${lvl.levelNumber}",
                                        tint = Color.White.copy(alpha = 0.85f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))
                            Row {
                                for (s in 1..3) {
                                    Icon(
                                        imageVector = Icons.Rounded.Star,
                                        contentDescription = null,
                                        tint = if (s <= stars) GoldenStar else Color(0xFF174F73).copy(alpha = 0.65f),
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }

                        // Hovering Mascot Portrait right beside Current Active Level
                        if (isCurrent) {
                            PeachPortraitFrame(
                                size = 40.dp,
                                animationsEnabled = animationsEnabled,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 6.dp, y = (-6).dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LevelPreviewModal(
    level: LevelDefinition,
    bestStars: Int,
    handSlide: Float,
    onPlay: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x991A0D07))
            .padding(22.dp)
            .testTag("level_preview_dialog"),
        contentAlignment = Alignment.Center
    ) {
        GameWoodenFrameModal(
            title = "Level ${level.levelNumber}",
            onClose = onClose,
            closeTestTag = "level_preview_close",
            modifier = Modifier
                .widthIn(max = 390.dp)
                .fillMaxWidth()
        ) {
            // Stylized Island Treasure Trail Mini-Map (Screenshot 2 vibe!)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(2.dp, CreamParchmentBevel, RoundedCornerShape(20.dp))
                    .background(Brush.verticalGradient(listOf(WaterSurfaceLight, WaterSurfaceDark)))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    // Top & Bottom emerald islands
                    val topLand = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(w, 0f)
                        lineTo(w, h * 0.28f)
                        quadraticTo(w * 0.72f, h * 0.42f, w * 0.46f, h * 0.26f)
                        quadraticTo(w * 0.22f, h * 0.40f, 0f, h * 0.24f)
                        close()
                    }
                    drawPath(topLand, Color(0xFFE7C77D))
                    drawPath(topLand, MeadowGreen.copy(alpha = 0.88f))

                    val bottomLand = Path().apply {
                        moveTo(0f, h)
                        lineTo(0f, h * 0.72f)
                        quadraticTo(w * 0.30f, h * 0.58f, w * 0.62f, h * 0.74f)
                        quadraticTo(w * 0.84f, h * 0.62f, w, h * 0.72f)
                        lineTo(w, h)
                        close()
                    }
                    drawPath(bottomLand, Color(0xFFE7C77D))
                    drawPath(bottomLand, MeadowDeepGreen.copy(alpha = 0.88f))

                    // Dotted voyage path across crystal river
                    val trail = Path().apply {
                        moveTo(w * 0.10f, h * 0.56f)
                        cubicTo(w * 0.36f, h * 0.40f, w * 0.62f, h * 0.58f, w * 0.84f, h * 0.48f)
                    }
                    drawPath(
                        trail,
                        CreamParchmentLight,
                        style = Stroke(width = 5f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 12f)))
                    )

                    // Golden Treasure Chest at right destination
                    val cx = w * 0.85f
                    val cy = h * 0.46f
                    drawRoundRect(Color(0xFF9C4B1C), Offset(cx - 18f, cy - 12f), Size(36f, 26f), CornerRadius(6f, 6f))
                    drawRoundRect(GoldenStar, Offset(cx - 18f, cy - 12f), Size(36f, 26f), CornerRadius(6f, 6f), style = Stroke(width = 4f))
                    drawCircle(BlossomPink, 5f, Offset(cx, cy))
                }

                // World & Title pill
                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = CreamParchment.copy(alpha = 0.94f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = level.title,
                        style = MaterialTheme.typography.labelLarge,
                        color = BerryInk,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                // Best Stars Badge
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp)
                ) {
                    for (s in 1..3) {
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = null,
                            tint = if (s <= bestStars) GoldenStar else Color(0xFF28485C),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Objectives & Moves Summary
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = PeachOrangeDeep
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${level.maxMoves} Moves",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
                level.objectives.forEach { obj ->
                    Surface(
                        shape = RoundedCornerShape(99.dp),
                        color = CreamParchmentLight,
                        border = BorderStroke(1.5.dp, CreamParchmentBevel)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            when (obj.kind) {
                                ObjectiveKind.COLLECT_FRUIT -> obj.fruitType?.let {
                                    FruitIconCanvas(fruit = it, size = 18.dp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                ObjectiveKind.CLEAR_OBSTACLE -> {
                                    PeachBlossomGoalIcon(size = 18.dp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                ObjectiveKind.TRIGGER_GOLDEN_WAVE -> {
                                    FruitIconCanvas(fruit = FruitType.GOLDEN_PINEAPPLE, size = 18.dp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                ObjectiveKind.SCORE -> {
                                    Icon(Icons.Rounded.Star, contentDescription = null, tint = GoldenStar, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                            }
                            Text(
                                text = "${obj.targetAmount}",
                                style = MaterialTheme.typography.labelLarge,
                                color = BerryInk,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Glossy Green Play Button + subtle animated pointer hint for early levels
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                GlossyGreenPlayButton(
                    onClick = onPlay,
                    minHeight = 64.dp,
                    testTag = "level_preview_play_button",
                    modifier = Modifier.fillMaxWidth(0.84f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = "Start Level ${level.levelNumber}",
                        tint = Color.White,
                        modifier = Modifier.size(44.dp)
                    )
                }

                if (level.levelNumber <= 2) {
                    Icon(
                        imageVector = Icons.Rounded.TouchApp,
                        contentDescription = null,
                        tint = CreamParchmentLight,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .offset(x = (-16).dp, y = (6 - 6 * handSlide).dp)
                            .size(34.dp)
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawMapTree(center: Offset, r: Float) {
    drawRoundRect(Color(0xFF7B4824), Offset(center.x - r * 0.2f, center.y), Size(r * 0.4f, r * 0.9f), CornerRadius(4f, 4f))
    drawCircle(Color(0xFF287518), r * 0.95f, center)
    drawCircle(Color(0xFF4BB52C), r * 0.72f, Offset(center.x - r * 0.16f, center.y - r * 0.18f))
    drawCircle(PeachOrange, r * 0.22f, Offset(center.x + r * 0.28f, center.y + r * 0.12f))
}

private fun DrawScope.drawMapCottage(center: Offset, r: Float) {
    drawRoundRect(Color(0xFF9C5427), Offset(center.x - r * 0.7f, center.y - r * 0.2f), Size(r * 1.4f, r * 1.0f), CornerRadius(4f, 4f))
    val roof = Path().apply {
        moveTo(center.x - r * 0.9f, center.y - r * 0.15f)
        lineTo(center.x, center.y - r * 0.95f)
        lineTo(center.x + r * 0.9f, center.y - r * 0.15f)
        close()
    }
    drawPath(roof, PeachOrangeDeep)
    drawRoundRect(Color(0xFF54280D), Offset(center.x - r * 0.2f, center.y + r * 0.22f), Size(r * 0.4f, r * 0.58f), CornerRadius(3f, 3f))
}
