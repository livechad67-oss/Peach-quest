package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.AppSettings
import com.example.model.DeviceTelemetrySummary
import com.example.model.GraphicsQuality
import com.example.ui.OwnerAuthState
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachCard
import com.example.ui.components.PeachPrimaryButton
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.FreshMint
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgTop
import com.example.ui.theme.SoftRoseBorder
import com.example.ui.theme.StreamBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OwnerDashboardScreen(
    ownerAuth: OwnerAuthState,
    analyticsSdkConnected: Boolean,
    analyticsConsentEnabled: Boolean,
    deviceTelemetry: DeviceTelemetrySummary,
    settings: AppSettings,
    graphicsQuality: GraphicsQuality,
    onSignInOwner: () -> Unit,
    onVerifyFirestore: () -> Unit,
    onSignOutOwner: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current

    fun openUrl(url: String) {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        }
    }

    OrchardBackdrop(
        topColor = com.example.ui.theme.SkyDeep,
        bottomColor = com.example.ui.theme.MeadowDeepGreen,
        graphicsQuality = graphicsQuality,
        animationsEnabled = settings.animationsEnabled
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 640.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            com.example.ui.components.GameStripedBanner {
                com.example.ui.components.AquaRoundIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    onClick = onBack,
                    size = 46.dp,
                    testTag = "owner_dashboard_back"
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "CLASTAD Owner Console",
                        style = MaterialTheme.typography.titleLarge,
                        color = com.example.ui.theme.CreamParchmentLight,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Private Developer Analytics & Console Links",
                        style = MaterialTheme.typography.labelMedium,
                        color = com.example.ui.theme.CreamParchment
                    )
                }
            }
            Column(
                modifier = Modifier.padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {

            when {
                // 1. Unauthenticated -> Server-enforced Google Sign-In Gate
                ownerAuth.userId == null -> {
                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = null,
                                tint = StreamBlue,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Authorized Owner Access Only",
                                style = MaterialTheme.typography.titleLarge,
                                color = BerryInk,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Regular players never sign in. This private console is enforced by Firebase Authentication and Cloud Firestore Security Rules for the authorized CLASTAD owner account.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CocoaMuted,
                                textAlign = TextAlign.Center
                            )

                            ownerAuth.errorMessage?.let { err ->
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = err,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = BlossomPink,
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))
                            PeachPrimaryButton(
                                onClick = onSignInOwner,
                                enabled = !ownerAuth.isBusy,
                                containerColor = StreamBlue,
                                testTag = "owner_signin_button",
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (ownerAuth.isBusy) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Icon(Icons.Rounded.AdminPanelSettings, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sign in with Authorized Google Account")
                            }
                        }
                    }
                }

                // 2. Signed in with non-allowlisted account -> Access Denied
                !ownerAuth.isAllowlistedAdmin -> {
                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .padding(24.dp)
                                .testTag("owner_access_denied")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = null,
                                tint = BlossomPink,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Access Denied",
                                style = MaterialTheme.typography.headlineMedium,
                                color = BlossomPink
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Account ${ownerAuth.email ?: "(unknown)"} is not authorized for CLASTAD Owner Console access. Cloud Firestore rules also reject all reads and writes for non-owner accounts.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CocoaMuted,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            OutlinedButton(
                                onClick = onSignOutOwner,
                                shape = RoundedCornerShape(22.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("owner_signout_button")
                            ) {
                                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = BerryInk)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sign Out", color = BerryInk)
                            }
                        }
                    }
                }

                // 3. Verified Owner Console
                else -> {
                    val overview = ownerAuth.remoteMetrics.firstOrNull { it.metricKey == "overview" }
                        ?: ownerAuth.remoteMetrics.firstOrNull()

                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .padding(18.dp)
                                .testTag("owner_dashboard_content")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = FreshMint)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Verified Owner Session",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = BerryInk,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = ownerAuth.email ?: "",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = CocoaMuted
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            MetricRow("Firebase Analytics SDK", if (analyticsSdkConnected) "Connected" else "Unavailable")
                            MetricRow("This Device Analytics Consent", if (analyticsConsentEnabled) "Opted In" else "Opted Out")
                            MetricRow(
                                "Firestore Owner Rules (/adminMetrics)",
                                if (ownerAuth.firestoreVerified) "Verified (Read/Write OK)" else "Not Verified Yet"
                            )

                            ownerAuth.infoMessage?.let { msg ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(msg, style = MaterialTheme.typography.bodyMedium, color = FreshMint)
                            }
                            ownerAuth.errorMessage?.let { err ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(err, style = MaterialTheme.typography.bodyMedium, color = BlossomPink)
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = onVerifyFirestore,
                                    enabled = !ownerAuth.isBusy,
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshMint),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Verify Firestore")
                                }
                                OutlinedButton(
                                    onClick = onSignOutOwner,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("owner_signout_button")
                                ) {
                                    Text("Sign Out", color = BerryInk)
                                }
                            }
                        }
                    }

                    // Cross-User Aggregated Reporting (Firestore /adminMetrics or honest console prompt)
                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Aggregated App Analytics (Cross-User)",
                                style = MaterialTheme.typography.titleLarge,
                                color = BerryInk
                            )
                            Text(
                                text = overview?.sourceNote
                                    ?: "Cross-user totals require a backend BigQuery/GA4 export to /adminMetrics/overview. Unavailable metrics are shown honestly below — open Firebase Console for live global charts.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CocoaMuted
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            val unavailable = "Unavailable in-app (open Firebase)"
                            MetricRow("First Opens (Analytics)", overview?.totalFirstOpens?.toString() ?: unavailable)
                            MetricRow("Daily New Players", overview?.dailyNewPlayers?.toString() ?: unavailable)
                            MetricRow("Daily Active Users (DAU)", overview?.dailyActivePlayers?.toString() ?: unavailable)
                            MetricRow("Monthly Active Users (MAU)", overview?.monthlyActivePlayers?.toString() ?: unavailable)
                            MetricRow("Day 1 Retention", overview?.day1RetentionPct?.let { "$it%" } ?: unavailable)
                            MetricRow("Day 7 Retention", overview?.day7RetentionPct?.let { "$it%" } ?: unavailable)
                            MetricRow("Country / Region Breakdown", overview?.countrySummaryNote ?: unavailable)
                            MetricRow("Crash-Free Sessions (Crashlytics)", overview?.crashFreeSessionsPct?.let { "$it%" } ?: unavailable)

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { openUrl("https://console.firebase.google.com/") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Firebase Analytics")
                                }
                                OutlinedButton(
                                    onClick = { openUrl("https://console.firebase.google.com/") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Crashlytics")
                                }
                            }
                        }
                    }

                    // Official Store Distribution Reporting (strictly separate from Analytics First Opens / Active Users)
                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Official Store Downloads & Installs",
                                style = MaterialTheme.typography.titleLarge,
                                color = BerryInk
                            )
                            Text(
                                text = "Official Android & iOS store download figures are separate from Analytics First Opens / Active Users and are only reported in official store consoles (never fabricated client-side).",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CocoaMuted
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            MetricRow("Google Play Store Downloads", "View in Google Play Console")
                            MetricRow("App Store Downloads (if iOS)", "View in App Store Connect")
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { openUrl("https://play.google.com/console") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Google Play")
                                }
                                OutlinedButton(
                                    onClick = { openUrl("https://appstoreconnect.apple.com") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("App Store")
                                }
                            }
                        }
                    }

                    // Strictly Labeled Local Device Diagnostics
                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .padding(18.dp)
                                .testTag("owner_local_diagnostics_card")
                        ) {
                            Surface(
                                shape = RoundedCornerShape(99.dp),
                                color = StreamBlue.copy(alpha = 0.14f)
                            ) {
                                Text(
                                    text = "THIS DEVICE ONLY • LOCAL DIAGNOSTICS",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StreamBlue,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            val firstOpenStr = if (deviceTelemetry.firstOpenTimestampMs > 0L) {
                                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                                    .format(Date(deviceTelemetry.firstOpenTimestampMs))
                            } else "Not recorded"
                            val avgSec = if (deviceTelemetry.sessionCount > 0) {
                                deviceTelemetry.totalSessionDurationSec / deviceTelemetry.sessionCount
                            } else 0L
                            val totalStarts = deviceTelemetry.levelStarts.values.sum()
                            val totalWins = deviceTelemetry.levelCompletes.values.sum()
                            val totalFails = deviceTelemetry.levelFailures.values.sum()

                            MetricRow("First Open (This Device)", firstOpenStr)
                            MetricRow("Sessions Recorded", "${deviceTelemetry.sessionCount}")
                            MetricRow("Avg Session Duration", "${avgSec}s")
                            MetricRow("Levels Started / Won / Failed", "$totalStarts / $totalWins / $totalFails")
                            MetricRow(
                                "Estimated Frame Rate",
                                if (deviceTelemetry.avgFpsEstimate > 0f) {
                                    "${deviceTelemetry.avgFpsEstimate.toInt()} FPS"
                                } else "Play a level to sample"
                            )
                            MetricRow("Local Non-Fatal Recoveries", "${deviceTelemetry.nonFatalErrorCount}")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
        }
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = CocoaMuted,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                color = BerryInk,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.End
            )
        }
        HorizontalDivider(color = SoftRoseBorder.copy(alpha = 0.55f))
    }
}
