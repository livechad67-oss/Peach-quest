package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.levels.OrchardCatalog
import com.example.model.AppSettings
import com.example.model.BoosterType
import com.example.model.FruitSkin
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.PlayerProgress
import com.example.ui.components.AquaRoundIconButton
import com.example.ui.components.FruitIconCanvas
import com.example.ui.components.GameStripedBanner
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachCard
import com.example.ui.components.PeachPortraitFrame
import com.example.ui.theme.BerryInk
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.CreamParchment
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.CreamParchmentLight
import com.example.ui.theme.FreshMint
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.GreenGlossMid
import com.example.ui.theme.MeadowDeepGreen
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SkyDeep
import com.example.ui.theme.SoftPeach

@Composable
fun FruitVaultScreen(
    progress: PlayerProgress,
    settings: AppSettings,
    graphicsQuality: GraphicsQuality,
    canClaimDaily: Boolean = false,
    onClaimDailyReward: () -> Unit = {},
    onSelectSkin: (FruitSkin) -> Unit,
    onTabChanged: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val activeSkin = remember(progress.selectedFruitSkin) {
        FruitSkin.fromId(progress.selectedFruitSkin)
    }
    val displayUser = progress.playerUsername.ifBlank { "Friend" }

    OrchardBackdrop(
        topColor = SkyDeep,
        bottomColor = MeadowDeepGreen,
        graphicsQuality = graphicsQuality,
        animationsEnabled = settings.animationsEnabled
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 640.dp)
                .align(Alignment.Center)
        ) {
            GameStripedBanner {
                AquaRoundIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    onClick = onBack,
                    size = 46.dp,
                    testTag = "vault_back"
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$displayUser's Profile",
                        style = MaterialTheme.typography.titleLarge,
                        color = CreamParchmentLight,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Rewards, boosters, 24 fruits & badges",
                        style = MaterialTheme.typography.labelMedium,
                        color = CreamParchment
                    )
                }
                PeachPortraitFrame(size = 48.dp, animationsEnabled = settings.animationsEnabled)
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                // Profile Summary, Daily Gift & Booster Stash
                PeachCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Star, contentDescription = null, tint = GoldenStar, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${progress.totalStars}/90 Stars",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = BerryInk,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "• ${progress.completedCount}/30",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CocoaMuted,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Button(
                                onClick = onClaimDailyReward,
                                enabled = canClaimDaily,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GreenGlossMid,
                                    disabledContainerColor = SoftPeach,
                                    disabledContentColor = CocoaMuted
                                ),
                                shape = RoundedCornerShape(99.dp),
                                modifier = Modifier.testTag("claim_daily_button")
                            ) {
                                Icon(Icons.Rounded.CardGiftcard, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (canClaimDaily) "Daily Gift!" else "Day ${progress.dailyStreak}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BoosterType.entries.forEach { b ->
                                val count = progress.boosterInventory[b] ?: 0
                                val bIcon = when (b) {
                                    BoosterType.RAINBOW -> Icons.Rounded.AutoAwesome
                                    BoosterType.BOMB -> Icons.Rounded.LocalFireDepartment
                                    BoosterType.LIGHTNING -> Icons.Rounded.Bolt
                                    BoosterType.MAGIC_PEACH -> Icons.Rounded.Star
                                }
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFF42367A),
                                    border = BorderStroke(1.5.dp, Color(0xFF6B5AB0)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center,
                                        modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp)
                                    ) {
                                        Icon(bIcon, contentDescription = b.title, tint = CreamParchmentLight, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "$count",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.dp, CreamParchmentBevel),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color.Transparent,
                        contentColor = PeachOrangeDeep
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0; onTabChanged() },
                            text = { Text("24 Fruits", fontWeight = FontWeight.ExtraBold) },
                            modifier = Modifier.testTag("vault_tab_fruits")
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1; onTabChanged() },
                            text = { Text("Styles", fontWeight = FontWeight.ExtraBold) },
                            modifier = Modifier.testTag("vault_tab_skins")
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2; onTabChanged() },
                            text = { Text("Badges", fontWeight = FontWeight.ExtraBold) },
                            modifier = Modifier.testTag("vault_tab_achievements")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (selectedTab) {
                    0 -> {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 104.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("fruit_gallery_grid")
                        ) {
                            items(FruitType.entries) { fruit ->
                                PeachCard(cornerRadius = 22.dp) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 12.dp, horizontal = 8.dp)
                                    ) {
                                        FruitIconCanvas(
                                            fruit = fruit,
                                            size = 48.dp,
                                            skin = activeSkin,
                                            showSymbol = settings.colorblindSymbols
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = fruit.displayName,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = BerryInk,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(FruitSkin.entries) { skin ->
                                val unlocked = skin.id in progress.unlockedFruitSkins
                                val equipped = progress.selectedFruitSkin == skin.id
                                PeachCard(
                                    onClick = { onSelectSkin(skin) },
                                    backgroundColor = if (equipped) Color(0xFFFFE57F) else CreamParchment,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("skin_card_${skin.id}")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        FruitIconCanvas(fruit = FruitType.PEACH, size = 50.dp, skin = skin)
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(skin.title, style = MaterialTheme.typography.titleLarge, color = BerryInk, fontWeight = FontWeight.ExtraBold)
                                            Text(skin.description, style = MaterialTheme.typography.bodyMedium, color = CocoaMuted)
                                            if (!unlocked) {
                                                Text(
                                                    text = "Unlocks at ${skin.requiredStars} ★",
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = PeachOrangeDeep,
                                                    fontWeight = FontWeight.ExtraBold
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(
                                            imageVector = if (unlocked || equipped) Icons.Rounded.CheckCircle else Icons.Rounded.Lock,
                                            contentDescription = null,
                                            tint = when {
                                                equipped -> PeachOrangeDeep
                                                unlocked -> FreshMint
                                                else -> CocoaMuted
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("achievements_list")
                        ) {
                            items(OrchardCatalog.achievements) { ach ->
                                val unlocked = ach.id in progress.unlockedAchievements
                                PeachCard(
                                    backgroundColor = if (unlocked) CreamParchment else Color(0xFFE7D7C2),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(CircleShape)
                                                .background(if (unlocked) GoldenStar.copy(alpha = 0.25f) else Color(0xFFD0BEAB)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (unlocked) Icons.Rounded.EmojiEvents else Icons.Rounded.Lock,
                                                contentDescription = null,
                                                tint = if (unlocked) GoldenStar else CocoaMuted
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(ach.title, style = MaterialTheme.typography.titleMedium, color = BerryInk, fontWeight = FontWeight.ExtraBold)
                                            Text(ach.description, style = MaterialTheme.typography.bodyMedium, color = CocoaMuted)
                                            Text(
                                                text = if (unlocked) "Unlocked • ${ach.rewardText}" else "Reward: ${ach.rewardText}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = if (unlocked) FreshMint else CocoaMuted,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
