package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PEACH QUEST — Deep, Rich, Realistic Cartoon Mobile Game Palette
val PeachOrange = Color(0xFFFF7A33)
val PeachOrangeDeep = Color(0xFFD94A14)
val PeachBannerTop = Color(0xFFFF8847)
val PeachBannerBottom = Color(0xFFE6531A)
val PeachBannerStripe = Color(0xFFDF561E)
val PeachBannerShadow = Color(0xFF8C2A09)
val PeachBubble = Color(0xFFFF9B52)
val SoftPeach = Color(0xFFFFDFC2)
val PeachGlow = Color(0xFFFFB27A)

// Deep Glossy Emerald Green (Play buttons & lush foliage)
val FreshMint = Color(0xFF39C91A)
val FreshMintDark = Color(0xFF1A870A)
val GreenGlossTop = Color(0xFF82F037)
val GreenGlossMid = Color(0xFF42C71A)
val GreenGlossBottom = Color(0xFF1E8D0D)
val MeadowGreen = Color(0xFF6AB832)
val MeadowDeepGreen = Color(0xFF3E7E1C)

// Deep Sky & Crystal Water River
val SkyMist = Color(0xFF8AD8FF)
val SkyHorizon = Color(0xFF3FA8EE)
val SkyDeep = Color(0xFF1C7FD4)
val StreamBlue = Color(0xFF2196F3)
val StreamDeep = Color(0xFF0E5BB8)
val WaterSurfaceLight = Color(0xFF2DA4FA)
val WaterSurfaceDark = Color(0xFF136ED4)
val AquaButtonTop = Color(0xFF44D7DB)
val AquaButtonBottom = Color(0xFF148A96)

// Accents
val BlossomPink = Color(0xFFE84376)
val StrawberryPink = BlossomPink
val StrawberryDeep = Color(0xFFB5224F)

val SunWarm = Color(0xFFFFD84D)
val PastelYellow = SunWarm
val GoldenStar = Color(0xFFF5A60C)
val GoldenBevel = Color(0xFFE0A343)

val SoftLavender = Color(0xFFB498FF)
val LavenderDeep = Color(0xFF6F4AC4)

// Cream Parchment Panels & Deep Chocolate Ink
val CreamParchment = Color(0xFFFFF0C6)
val CreamParchmentLight = Color(0xFFFFF8E1)
val CreamParchmentBevel = Color(0xFFE8B465)
val CreamyWhite = Color(0xFFFFF5DF)
val CreamSurface = Color(0xFFFFFAF0)
val CoralOrange = PeachOrange
val CoralDark = PeachOrangeDeep

val BerryInk = Color(0xFF2E160B)
val CocoaMuted = Color(0xFF6D4534)
val SoftRoseBorder = Color(0xFFE0A954)
val PortraitFrameBg = Color(0xFF692920)

val LobbyBgTop = Color(0xFF38A2EA)
val LobbyBgMid = Color(0xFF8AD7FF)
val LobbyBgBottom = Color(0xFF6FBE35)

// Shaped Purple-Beveled Board & Cobblestone Soil
val BoardPurple = Color(0xFF7B5AC9)
val BoardPurpleLight = Color(0xFF9E80EB)
val BoardPurpleDark = Color(0xFF4B2E94)
val BoardFrame = BoardPurple
val BoardInnerBg = Color(0xFF5D4234)
val BoardCellLight = Color(0xFFC4A07A)
val BoardCellWarm = Color(0xFFB18B64)
val BoardCellGrout = Color(0xFF6B4C35)

// Obstacles
val IceBlue = Color(0xFF8BE0FF)
val IceBorder = Color(0xFF2196E8)
val VineGreen = Color(0xFF1E8442)
val CrateWood = Color(0xFFE3752B)
val CrateWoodLight = Color(0xFFF79D4D)
val CrateWoodDark = Color(0xFF8F380E)
