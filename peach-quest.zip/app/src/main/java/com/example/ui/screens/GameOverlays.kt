package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.BoosterType
import com.example.model.FruitType
import com.example.model.LevelObjective
import com.example.ui.GameUiState
import com.example.ui.MechanicTip
import com.example.ui.components.FruitIconCanvas
import com.example.ui.components.GameWoodenFrameModal
import com.example.ui.components.GlossyGreenPlayButton
import com.example.ui.components.PeachMascotCharacter
import com.example.ui.components.drawFourPointStar
import com.example.ui.components.drawFruitShape
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.CreamParchmentLight
import com.example.ui.theme.FreshMint
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.PastelYellow
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.StreamBlue
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun MechanicTipDialog(
    tip: MechanicTip,
    onDismiss: () -> Unit
) {
    val icon = when (tip.boosterType) {
        BoosterType.LIGHTNING -> Icons.Rounded.Bolt
        BoosterType.BOMB -> Icons.Rounded.LocalFireDepartment
        BoosterType.RAINBOW -> Icons.Rounded.AutoAwesome
        BoosterType.MAGIC_PEACH -> Icons.Rounded.Star
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x991A0D07))
            .padding(24.dp)
            .testTag("mechanic_tip_dialog"),
        contentAlignment = Alignment.Center
    ) {
        GameWoodenFrameModal(
            title = tip.title,
            onClose = onDismiss,
            modifier = Modifier.widthIn(max = 390.dp).fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(66.dp)
                    .clip(CircleShape)
                    .background(tip.boosterType.accentColor.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tip.boosterType.accentColor,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = tip.description,
                style = MaterialTheme.typography.bodyLarge,
                color = BerryInk,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(18.dp))
            GlossyGreenPlayButton(
                onClick = onDismiss,
                minHeight = 56.dp,
                testTag = "mechanic_tip_dismiss",
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Got it!",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
fun PauseOverlayDialog(
    levelNumber: Int,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onExitToHome: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x991A0D07))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        GameWoodenFrameModal(
            title = "Paused",
            onClose = onResume,
            modifier = Modifier.widthIn(max = 380.dp).fillMaxWidth()
        ) {
            Text(
                text = "Level $levelNumber progress is saved safely on your device.",
                style = MaterialTheme.typography.bodyMedium,
                color = CocoaMuted,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            GlossyGreenPlayButton(
                onClick = onResume,
                minHeight = 58.dp,
                testTag = "pause_resume_button",
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Resume",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onRestart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachOrangeDeep,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(99.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Restart Level", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(
                onClick = onExitToHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pause_home_button")
            ) {
                Text("Save & Return Home", color = BerryInk, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun VictoryCelebrationOverlay(
    game: GameUiState,
    animationsEnabled: Boolean,
    onNextLevel: (Int) -> Unit,
    onReplay: () -> Unit,
    onOpenGarden: () -> Unit,
    onHome: () -> Unit
) {
    var countStarted by remember { mutableStateOf(false) }
    LaunchedEffect(game.score) { countStarted = true }
    val animatedScore by animateIntAsState(
        targetValue = if (countStarted) game.score else 0,
        animationSpec = tween(durationMillis = if (animationsEnabled) 850 else 100),
        label = "victory_score"
    )

    val confettiPhase = if (animationsEnabled) {
        val inf = rememberInfiniteTransition(label = "confetti")
        val p by inf.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
            label = "c_fall"
        )
        p
    } else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x991A0D07))
            .padding(20.dp)
            .testTag("victory_overlay"),
        contentAlignment = Alignment.Center
    ) {
        if (animationsEnabled) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val colors = listOf(PeachOrange, FreshMint, StreamBlue, BlossomPink, PastelYellow, SoftLavender)
                for (i in 0 until 24) {
                    val x = size.width * ((i * 0.13f + 0.04f) % 0.94f)
                    val y = size.height * ((i * 0.17f + confettiPhase) % 1.08f)
                    val sway = sin((confettiPhase * 2 * PI + i).toDouble()).toFloat() * 14f
                    drawCircle(colors[i % colors.size].copy(alpha = 0.85f), 8f, Offset(x + sway, y))
                }
                drawFruitShape(FruitType.PEACH, Offset(size.width * 0.14f, size.height * 0.18f), 26f)
                drawFruitShape(FruitType.STRAWBERRY, Offset(size.width * 0.86f, size.height * 0.2f), 24f)
                drawFourPointStar(Offset(size.width * 0.2f, size.height * 0.82f), 18f, PastelYellow)
                drawFourPointStar(Offset(size.width * 0.82f, size.height * 0.8f), 18f, GoldenStar)
            }
        }

        GameWoodenFrameModal(
            title = if (game.level.levelNumber == 30) "Kingdom Complete!" else "Sweet Victory!",
            modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth()
        ) {
            PeachMascotCharacter(size = 76.dp, animationsEnabled = animationsEnabled)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Level ${game.level.levelNumber} • ${game.level.title}",
                style = MaterialTheme.typography.titleMedium,
                color = CocoaMuted,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (s in 1..3) {
                    Icon(
                        imageVector = Icons.Rounded.Star,
                        contentDescription = null,
                        tint = if (s <= game.earnedStars) GoldenStar else Color(0xFFD0BEAB),
                        modifier = Modifier.size(46.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = CreamParchmentLight,
                border = BorderStroke(2.dp, CreamParchmentBevel),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 10.dp)
                ) {
                    Text("Final Score", style = MaterialTheme.typography.labelLarge, color = CocoaMuted, fontWeight = FontWeight.Bold)
                    Text(
                        text = "$animatedScore",
                        style = MaterialTheme.typography.displayMedium,
                        color = BerryInk,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (game.level.levelNumber < 30) {
                GlossyGreenPlayButton(
                    onClick = { onNextLevel(game.level.levelNumber + 1) },
                    minHeight = 58.dp,
                    testTag = "victory_next_level",
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Next Level (${game.level.levelNumber + 1})",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            } else {
                GlossyGreenPlayButton(
                    onClick = onOpenGarden,
                    minHeight = 58.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Visit Blossom Valley Garden",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onReplay,
                    colors = ButtonDefaults.buttonColors(containerColor = PeachOrangeDeep, contentColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Replay", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onHome,
                    colors = ButtonDefaults.buttonColors(containerColor = CreamParchmentBevel, contentColor = BerryInk),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Home", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun RetryOverlay(
    game: GameUiState,
    objectiveProgress: (LevelObjective) -> Pair<Int, Int>,
    onRetry: () -> Unit,
    onMap: () -> Unit,
    onHome: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x991A0D07))
            .padding(22.dp)
            .testTag("retry_overlay"),
        contentAlignment = Alignment.Center
    ) {
        GameWoodenFrameModal(
            title = "Almost There!",
            modifier = Modifier.widthIn(max = 400.dp).fillMaxWidth()
        ) {
            FruitIconCanvas(fruit = FruitType.PEACH, size = 56.dp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "You scored ${game.score} points. Try again to complete the goals!",
                style = MaterialTheme.typography.bodyMedium,
                color = CocoaMuted,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                game.level.objectives.forEach { obj ->
                    val (cur, target) = objectiveProgress(obj)
                    Text(
                        text = "• ${obj.label}: $cur / $target",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (cur >= target) FreshMint else BerryInk,
                        fontWeight = if (cur >= target) FontWeight.ExtraBold else FontWeight.SemiBold
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            GlossyGreenPlayButton(
                onClick = onRetry,
                minHeight = 58.dp,
                testTag = "retry_level_button",
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Try Again",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onMap,
                    colors = ButtonDefaults.buttonColors(containerColor = PeachOrangeDeep, contentColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Garden Map", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onHome,
                    colors = ButtonDefaults.buttonColors(containerColor = CreamParchmentBevel, contentColor = BerryInk),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Home", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
