package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.ui.components.FruitIconCanvas
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachCard
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgTop
import com.example.ui.theme.PeachBubble
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.SunWarm

@Composable
fun LoadingScreen(
    progress: Float,
    statusText: String,
    errorText: String?,
    animationsEnabled: Boolean,
    onRetry: () -> Unit,
    onResetFresh: () -> Unit
) {
    val logoFloat = if (animationsEnabled) {
        val inf = rememberInfiniteTransition(label = "peach_quest_loading")
        val y by inf.animateFloat(
            initialValue = -5f,
            targetValue = 5f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1900, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "float"
        )
        y
    } else 0f

    val logoScale by animateFloatAsState(
        targetValue = 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "logo_scale"
    )
    val smoothProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 180),
        label = "load_bar"
    )

    OrchardBackdrop(
        topColor = com.example.ui.theme.SkyDeep,
        bottomColor = com.example.ui.theme.MeadowDeepGreen,
        graphicsQuality = GraphicsQuality.HIGH,
        animationsEnabled = animationsEnabled,
        showFloatingFruits = true
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 520.dp)
                    .align(Alignment.Center)
                    .padding(horizontal = 28.dp)
            ) {
                Spacer(modifier = Modifier.weight(1f))

                // Radiant sunlit halo + Official Peach Quest Logo
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.graphicsLayer {
                        scaleX = logoScale
                        scaleY = logoScale
                        translationY = logoFloat
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .size(258.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        com.example.ui.theme.CreamParchmentLight.copy(alpha = 0.90f),
                                        SunWarm.copy(alpha = 0.42f),
                                        PeachBubble.copy(alpha = 0.22f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Image(
                        painter = painterResource(id = R.drawable.peach_quest_logo),
                        contentDescription = "Peach Quest Logo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(226.dp)
                            .testTag("loading_logo")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = com.example.ui.theme.CreamParchment.copy(alpha = 0.92f),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, com.example.ui.theme.CreamParchmentBevel)
                ) {
                    Text(
                        text = "A Magical Fruit Garden",
                        style = MaterialTheme.typography.titleMedium,
                        color = BerryInk,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                if (errorText != null) {
                    PeachCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Text(
                                text = "Garden Hiccup",
                                style = MaterialTheme.typography.titleLarge,
                                color = BerryInk
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = errorText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CocoaMuted,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onRetry,
                                    colors = ButtonDefaults.buttonColors(containerColor = PeachOrange)
                                ) {
                                    Text("Try Again")
                                }
                                OutlinedButton(onClick = onResetFresh) {
                                    Text("Start Fresh")
                                }
                            }
                        }
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(99.dp),
                            color = com.example.ui.theme.CreamParchment,
                            border = androidx.compose.foundation.BorderStroke(2.dp, com.example.ui.theme.CreamParchmentBevel),
                            shadowElevation = 5.dp,
                            modifier = Modifier
                                .fillMaxWidth(0.78f)
                                .height(22.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize().padding(3.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(smoothProgress.coerceAtLeast(0.08f))
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(
                                                    com.example.ui.theme.GreenGlossTop,
                                                    com.example.ui.theme.GreenGlossMid,
                                                    GoldenStar,
                                                    PeachOrange
                                                )
                                            )
                                        )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(99.dp),
                            color = com.example.ui.theme.CreamParchment.copy(alpha = 0.90f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                FruitIconCanvas(fruit = FruitType.PEACH, size = 20.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BerryInk,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = com.example.ui.theme.CreamParchment,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, com.example.ui.theme.CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .padding(bottom = 18.dp)
                        .testTag("loading_clastad_credit")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.clastad_logo),
                            contentDescription = "CLASTAD",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(id = R.string.developer_credit),
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}
