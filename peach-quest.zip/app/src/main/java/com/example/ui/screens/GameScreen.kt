package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.model.AppSettings
import com.example.model.BoosterType
import com.example.model.FruitSkin
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.LevelObjective
import com.example.model.ObjectiveKind
import com.example.model.ObstacleType
import com.example.model.PlayerProgress
import com.example.model.SpecialKind
import com.example.ui.GamePhase
import com.example.ui.GameUiState
import com.example.ui.components.AquaRoundIconButton
import com.example.ui.components.FruitIconCanvas
import com.example.ui.components.GameStripedBanner
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachBlossomGoalIcon
import com.example.ui.components.PeachPortraitFrame
import com.example.ui.components.drawFourPointStar
import com.example.ui.components.drawFruitShape
import com.example.ui.components.drawObstacleOverlay
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.BoardCellGrout
import com.example.ui.theme.BoardCellLight
import com.example.ui.theme.BoardCellWarm
import com.example.ui.theme.BoardPurple
import com.example.ui.theme.BoardPurpleDark
import com.example.ui.theme.BoardPurpleLight
import com.example.ui.theme.CrateWood
import com.example.ui.theme.CreamParchment
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.CreamParchmentLight
import com.example.ui.theme.FreshMint
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.MeadowDeepGreen
import com.example.ui.theme.PastelYellow
import com.example.ui.theme.PeachBannerShadow
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SkyDeep
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.SoftPeach
import com.example.ui.theme.StreamBlue
import com.example.ui.theme.WaterSurfaceDark
import com.example.ui.theme.WaterSurfaceLight
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GameScreen(
    game: GameUiState,
    progress: PlayerProgress,
    settings: AppSettings,
    graphicsQuality: GraphicsQuality,
    objectiveProgress: (LevelObjective) -> Pair<Int, Int>,
    onDismissMechanicTip: () -> Unit,
    onDismissTutorial: () -> Unit,
    onSelectBooster: (BoosterType) -> Unit,
    onTileTapped: (Int, Int) -> Unit,
    onTileSwiped: (Int, Int, Int, Int) -> Unit,
    onHintClick: () -> Unit,
    onPauseClick: () -> Unit,
    onResumeClick: () -> Unit,
    onRestartLevel: () -> Unit,
    onNextLevel: (Int) -> Unit,
    onExitToHome: () -> Unit,
    onOpenLevelMap: () -> Unit,
    onOpenGarden: () -> Unit
) {
    BackHandler {
        when {
            game.mechanicTip != null -> onDismissMechanicTip()
            game.phase == GamePhase.VICTORY || game.phase == GamePhase.FAILED -> onOpenLevelMap()
            game.phase == GamePhase.PAUSED -> onExitToHome()
            else -> onPauseClick()
        }
    }

    val activeSkin = remember(progress.selectedFruitSkin) {
        FruitSkin.fromId(progress.selectedFruitSkin)
    }

    val pulseInf = rememberInfiniteTransition(label = "board_water_pulse")
    val pulse by pulseInf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_v"
    )
    val waterFlow by pulseInf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "water_flow"
    )
    val handSlide by pulseInf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tut_hand"
    )

    val clearAnim = remember { Animatable(0f) }
    LaunchedEffect(game.phase, game.activeClearIndices) {
        if (game.phase == GamePhase.CLEARING) {
            clearAnim.snapTo(0f)
            clearAnim.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = if (settings.animationsEnabled) 220 else 60, easing = FastOutSlowInEasing)
            )
        } else {
            clearAnim.snapTo(0f)
        }
    }

    val fallAnim = remember { Animatable(1f) }
    LaunchedEffect(game.phase, game.fallDistances) {
        if (game.phase == GamePhase.FALLING && game.fallDistances.isNotEmpty()) {
            fallAnim.snapTo(0f)
            fallAnim.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = if (settings.animationsEnabled) 215 else 60, easing = FastOutSlowInEasing)
            )
        } else {
            fallAnim.snapTo(1f)
        }
    }

    val swapAnim = remember { Animatable(1f) }
    LaunchedEffect(game.phase, game.swappingPair) {
        if ((game.phase == GamePhase.ANIMATING_SWAP || game.phase == GamePhase.REVERSING_SWAP) && game.swappingPair != null) {
            swapAnim.snapTo(0f)
            swapAnim.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = if (settings.animationsEnabled) 125 else 45, easing = FastOutSlowInEasing)
            )
        } else {
            swapAnim.snapTo(1f)
        }
    }

    val boardScale by animateFloatAsState(
        targetValue = if (game.comboCount >= 2 && settings.animationsEnabled) 1.018f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "board_combo_pulse"
    )

    OrchardBackdrop(
        topColor = SkyDeep,
        bottomColor = MeadowDeepGreen,
        graphicsQuality = graphicsQuality,
        animationsEnabled = settings.animationsEnabled,
        showOverhangingBranch = true,
        showCornerFlowers = true
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 620.dp)
                .align(Alignment.Center)
        ) {
            // Top Striped Peach HUD Banner (Screenshots 1, 3, 4, 5, 8)
            GameStripedBanner {
                PeachPortraitFrame(
                    size = 62.dp,
                    animationsEnabled = settings.animationsEnabled
                )

                Spacer(modifier = Modifier.width(10.dp))

                // Center Beveled Cream Parchment Objectives Pill
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.5.dp, CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            game.level.objectives.forEach { obj ->
                                val (cur, target) = objectiveProgress(obj)
                                val done = cur >= target
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(if (done) Color(0xFFD0F7DF) else CreamParchmentLight)
                                        .padding(horizontal = 7.dp, vertical = 3.dp)
                                ) {
                                    when (obj.kind) {
                                        ObjectiveKind.COLLECT_FRUIT -> obj.fruitType?.let {
                                            FruitIconCanvas(fruit = it, size = 21.dp, skin = activeSkin)
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        ObjectiveKind.CLEAR_OBSTACLE -> {
                                            PeachBlossomGoalIcon(size = 21.dp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        ObjectiveKind.TRIGGER_GOLDEN_WAVE -> {
                                            FruitIconCanvas(fruit = FruitType.GOLDEN_PINEAPPLE, size = 21.dp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        ObjectiveKind.SCORE -> {
                                            Icon(Icons.Rounded.Star, contentDescription = null, tint = GoldenStar, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                        }
                                    }
                                    Text(
                                        text = "$cur/$target",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (done) FreshMint else BerryInk,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    if (done) {
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = FreshMint, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(5.dp))
                        val starMax = game.level.starThresholds.third.coerceAtLeast(1)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "L${game.level.levelNumber}",
                                style = MaterialTheme.typography.labelSmall,
                                color = PeachOrangeDeep,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            LinearProgressIndicator(
                                progress = { (game.score.toFloat() / starMax).coerceIn(0.02f, 1f) },
                                color = GoldenStar,
                                trackColor = SoftPeach,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(99.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${game.score}",
                                style = MaterialTheme.typography.labelSmall,
                                color = BerryInk,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Right Swap Arrows + Big Bold Cream Moves Counter (Screenshots 1, 3, 4, 5, 8)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (game.movesRemaining <= 4) BlossomPink.copy(alpha = 0.85f)
                            else PeachBannerShadow.copy(alpha = 0.25f)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("moves_badge")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SwapHoriz,
                        contentDescription = "Moves Left",
                        tint = PeachBannerShadow,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "${game.movesRemaining}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CreamParchmentLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Tutorial / Status Tip Banner
            AnimatedVisibility(
                visible = game.tutorialCelebration != null || game.tutorialActive || game.statusBanner != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                val isCelebration = game.tutorialCelebration != null
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = when {
                        isCelebration -> FreshMint
                        game.tutorialActive -> PeachOrangeDeep
                        else -> CreamParchment
                    },
                    border = BorderStroke(2.dp, if (isCelebration || game.tutorialActive) CreamParchmentLight else CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 2.dp)
                        .testTag(if (game.tutorialActive) "tutorial_banner" else "game_status_banner")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = game.tutorialCelebration
                                ?: if (game.tutorialActive) "Swipe matching fruits to spread water & clear goals!"
                                else (game.statusBanner ?: ""),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isCelebration || game.tutorialActive) Color.White else BerryInk,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.weight(1f)
                        )
                        if (game.tutorialActive && !isCelebration) {
                            TextButton(
                                onClick = onDismissTutorial,
                                modifier = Modifier.testTag("tutorial_skip_button")
                            ) {
                                Text("Skip", color = CreamParchmentLight, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }

            // Responsive Shaped Match-3 Board with Purple 3D Frame, Water & Cobblestone Soil
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                BoxWithConstraints(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    val rows = game.board.rows.coerceAtLeast(1)
                    val cols = game.board.cols.coerceAtLeast(1)
                    val cellDp = minOf(
                        (maxWidth - 22.dp) / cols,
                        (maxHeight - 22.dp) / rows
                    )
                    val boardWidthDp = cellDp * cols + 16.dp
                    val boardHeightDp = cellDp * rows + 16.dp
                    val density = LocalDensity.current

                    Box(
                        modifier = Modifier
                            .size(width = boardWidthDp, height = boardHeightDp)
                            .graphicsLayer {
                                scaleX = boardScale
                                scaleY = boardScale
                            }
                            .padding(8.dp)
                            .testTag("match3_board")
                            .pointerInput(game.board.rows, game.board.cols, game.phase, game.board.cells) {
                                if (game.phase != GamePhase.IDLE) return@pointerInput
                                val cellW = size.width.toFloat() / cols
                                val cellH = size.height.toFloat() / rows
                                val dragThreshold = minOf(cellW, cellH) * 0.30f

                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    val startRow = (down.position.y / cellH).toInt().coerceIn(0, rows - 1)
                                    val startCol = (down.position.x / cellW).toInt().coerceIn(0, cols - 1)
                                    if (game.board.cells.isNotEmpty() && game.board.get(startRow, startCol).isVoid) {
                                        return@awaitEachGesture
                                    }
                                    var totalDx = 0f
                                    var totalDy = 0f
                                    var swiped = false

                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val change = event.changes.firstOrNull() ?: break
                                        if (!change.pressed) {
                                            if (!swiped) onTileTapped(startRow, startCol)
                                            break
                                        }
                                        val delta = change.positionChange()
                                        totalDx += delta.x
                                        totalDy += delta.y
                                        if (!swiped && (abs(totalDx) >= dragThreshold || abs(totalDy) >= dragThreshold)) {
                                            swiped = true
                                            change.consume()
                                            if (abs(totalDx) > abs(totalDy)) {
                                                onTileSwiped(startRow, startCol, 0, if (totalDx > 0) 1 else -1)
                                            } else {
                                                onTileSwiped(startRow, startCol, if (totalDy > 0) 1 else -1, 0)
                                            }
                                            break
                                        }
                                    }
                                }
                            }
                    ) {
                        val activeHint = game.tutorialHint ?: game.hint
                        val clearT = clearAnim.value
                        val fallT = fallAnim.value
                        val swapT = swapAnim.value

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val cellW = size.width / cols
                            val cellH = size.height / rows
                            val cellSize = minOf(cellW, cellH)
                            val rimPad = cellSize * 0.14f
                            val cr = cellSize * 0.24f

                            // 1) Continuous Deep Royal Purple 3D Shaped Frame around all active non-void cells
                            for (r in 0 until rows) {
                                for (c in 0 until cols) {
                                    val cell = game.board.cells.getOrNull(r * cols + c)
                                    if (cell?.isVoid == true) continue
                                    val x = c * cellW - rimPad
                                    val y = r * cellH - rimPad
                                    val w = cellW + rimPad * 2f
                                    val h = cellH + rimPad * 2f
                                    // Drop shadow under shaped frame
                                    drawRoundRect(
                                        color = Color(0xFF1F1240).copy(alpha = 0.42f),
                                        topLeft = Offset(x + 2f, y + 6f),
                                        size = Size(w, h),
                                        cornerRadius = CornerRadius(cr, cr)
                                    )
                                    drawRoundRect(
                                        color = BoardPurpleDark,
                                        topLeft = Offset(x, y + 2f),
                                        size = Size(w, h),
                                        cornerRadius = CornerRadius(cr, cr)
                                    )
                                }
                            }
                            for (r in 0 until rows) {
                                for (c in 0 until cols) {
                                    val cell = game.board.cells.getOrNull(r * cols + c)
                                    if (cell?.isVoid == true) continue
                                    val x = c * cellW - rimPad * 0.72f
                                    val y = r * cellH - rimPad * 0.72f
                                    val w = cellW + rimPad * 1.44f
                                    val h = cellH + rimPad * 1.44f
                                    drawRoundRect(
                                        brush = Brush.verticalGradient(listOf(BoardPurpleLight, BoardPurple)),
                                        topLeft = Offset(x, y),
                                        size = Size(w, h),
                                        cornerRadius = CornerRadius(cr * 0.9f, cr * 0.9f)
                                    )
                                }
                            }
                            // Dark indigo inner recess for clean contrast between tiles
                            for (r in 0 until rows) {
                                for (c in 0 until cols) {
                                    val cell = game.board.cells.getOrNull(r * cols + c)
                                    if (cell?.isVoid == true) continue
                                    drawRoundRect(
                                        color = Color(0xFF34226E),
                                        topLeft = Offset(c * cellW, r * cellH),
                                        size = Size(cellW, cellH),
                                        cornerRadius = CornerRadius(cellSize * 0.14f, cellSize * 0.14f)
                                    )
                                }
                            }

                            // 2) Active Cell Floors: Animated Sparkling Blue Water vs Cobblestone Sandstone Soil
                            for (r in 0 until rows) {
                                for (c in 0 until cols) {
                                    val cell = game.board.cells.getOrNull(r * cols + c) ?: continue
                                    if (cell.isVoid) continue
                                    val isInChannel = cell.isWatered || (r to c) in game.waterChannelCells
                                    val inset = if (isInChannel) cellSize * 0.01f else cellSize * 0.03f
                                    val topLeft = Offset(c * cellW + inset, r * cellH + inset)
                                    val tileSize = Size(cellW - inset * 2, cellH - inset * 2)
                                    val tileCorner = CornerRadius(cellSize * 0.18f, cellSize * 0.18f)

                                    if (isInChannel) {
                                        drawRoundRect(
                                            brush = Brush.linearGradient(
                                                colors = listOf(WaterSurfaceLight, WaterSurfaceDark, Color(0xFF1D7FE6)),
                                                start = topLeft,
                                                end = Offset(topLeft.x + tileSize.width, topLeft.y + tileSize.height)
                                            ),
                                            topLeft = topLeft,
                                            size = tileSize,
                                            cornerRadius = tileCorner
                                        )
                                        // Animated sparkling water caustics
                                        val cx = c * cellW + cellW / 2f
                                        val cy = r * cellH + cellH / 2f
                                        if (settings.animationsEnabled && graphicsQuality != GraphicsQuality.LOW_RAM) {
                                            val waveShift = sin((waterFlow * 2 * PI + r + c).toDouble()).toFloat() * cellSize * 0.12f
                                            drawCircle(
                                                color = Color(0xFF8BE2FF).copy(alpha = 0.28f),
                                                radius = cellSize * 0.22f,
                                                center = Offset(cx + waveShift, cy - cellSize * 0.08f)
                                            )
                                            drawCircle(
                                                color = Color.White.copy(alpha = 0.42f * (0.5f + 0.5f * pulse)),
                                                radius = cellSize * 0.055f,
                                                center = Offset(cx - cellSize * 0.18f, cy + cellSize * 0.14f)
                                            )
                                        }
                                    } else {
                                        val bg = if ((r + c) % 2 == 0) BoardCellLight else BoardCellWarm
                                        drawRoundRect(
                                            color = bg,
                                            topLeft = topLeft,
                                            size = tileSize,
                                            cornerRadius = tileCorner
                                        )
                                        // Subtle cobblestone texture lines & bevel border
                                        drawRoundRect(
                                            color = BoardCellGrout.copy(alpha = 0.48f),
                                            topLeft = topLeft,
                                            size = tileSize,
                                            cornerRadius = tileCorner,
                                            style = Stroke(width = cellSize * 0.03f)
                                        )
                                        drawLine(
                                            color = BoardCellGrout.copy(alpha = 0.22f),
                                            start = Offset(topLeft.x + cellSize * 0.18f, topLeft.y + cellSize * 0.42f),
                                            end = Offset(topLeft.x + cellSize * 0.52f, topLeft.y + cellSize * 0.24f),
                                            strokeWidth = cellSize * 0.024f,
                                            cap = StrokeCap.Round
                                        )
                                        drawLine(
                                            color = BoardCellGrout.copy(alpha = 0.20f),
                                            start = Offset(topLeft.x + cellSize * 0.52f, topLeft.y + cellSize * 0.72f),
                                            end = Offset(topLeft.x + cellSize * 0.80f, topLeft.y + cellSize * 0.54f),
                                            strokeWidth = cellSize * 0.024f,
                                            cap = StrokeCap.Round
                                        )
                                    }
                                }
                            }

                            // 3) Glowing Link Beams connecting Matched / Water Channel Cells
                            if (game.phase == GamePhase.CLEARING && game.activeClearIndices.size >= 2) {
                                val clearCenters = game.activeClearIndices.mapNotNull { idx ->
                                    val cCell = game.board.cells.getOrNull(idx) ?: return@mapNotNull null
                                    if (cCell.isVoid) null
                                    else Offset(cCell.col * cellW + cellW / 2f, cCell.row * cellH + cellH / 2f)
                                }
                                for (i in 0 until clearCenters.lastIndex) {
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.78f * (1f - clearT * 0.6f)),
                                        start = clearCenters[i],
                                        end = clearCenters[i + 1],
                                        strokeWidth = cellSize * 0.16f,
                                        cap = StrokeCap.Round
                                    )
                                }
                            } else if (game.selectedCell != null) {
                                val sel = game.selectedCell
                                val selCenter = Offset(sel.second * cellW + cellW / 2f, sel.first * cellH + cellH / 2f)
                                game.waterChannelCells.forEach { (nr, nc) ->
                                    if (nr to nc != sel) {
                                        val nCenter = Offset(nc * cellW + cellW / 2f, nr * cellH + cellH / 2f)
                                        drawLine(
                                            color = Color.White.copy(alpha = 0.48f),
                                            start = selCenter,
                                            end = nCenter,
                                            strokeWidth = cellSize * 0.14f,
                                            cap = StrokeCap.Round
                                        )
                                    }
                                }
                            }

                            // 4) Fruits, Obstacles, White Selection Glow, Fall/Swap Motion & Sliced Fruit Bursts
                            game.board.cells.forEachIndexed { idx, cell ->
                                if (cell.isVoid) return@forEachIndexed

                                var drawCol = cell.col.toFloat()
                                var drawRow = cell.row.toFloat()

                                val sp = game.swappingPair
                                if (sp != null && (game.phase == GamePhase.ANIMATING_SWAP || game.phase == GamePhase.REVERSING_SWAP)) {
                                    val (fromCoord, toCoord) = sp
                                    if ((cell.row to cell.col) == toCoord) {
                                        drawRow = fromCoord.first + (toCoord.first - fromCoord.first) * swapT
                                        drawCol = fromCoord.second + (toCoord.second - fromCoord.second) * swapT
                                    } else if ((cell.row to cell.col) == fromCoord) {
                                        drawRow = toCoord.first + (fromCoord.first - toCoord.first) * swapT
                                        drawCol = toCoord.second + (fromCoord.second - toCoord.second) * swapT
                                    }
                                }

                                val fallRows = game.fallDistances[cell.id] ?: 0
                                if (game.phase == GamePhase.FALLING && fallRows > 0) {
                                    drawRow -= fallRows * (1f - fallT)
                                }

                                val tileLeft = drawCol * cellW
                                val tileTop = drawRow * cellH
                                var center = Offset(tileLeft + cellW / 2f, tileTop + cellH / 2f)

                                val isSelected = game.selectedCell == (cell.row to cell.col)
                                val isHinted = activeHint != null &&
                                    ((activeHint.r1 == cell.row && activeHint.c1 == cell.col) ||
                                        (activeHint.r2 == cell.row && activeHint.c2 == cell.col))
                                val isClearing = idx in game.activeClearIndices
                                val isWave = idx in game.activeWaveIndices

                                if (isSelected) {
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            listOf(Color.White.copy(alpha = 0.85f), Color.Transparent),
                                            center = center,
                                            radius = cellSize * 0.58f
                                        ),
                                        radius = cellSize * 0.58f,
                                        center = center
                                    )
                                } else if (isHinted) {
                                    drawRoundRect(
                                        color = if (game.tutorialActive) Color.White else GoldenStar,
                                        topLeft = Offset(cell.col * cellW + cellSize * 0.04f, cell.row * cellH + cellSize * 0.04f),
                                        size = Size(cellW - cellSize * 0.08f, cellH - cellSize * 0.08f),
                                        cornerRadius = CornerRadius(cellSize * 0.22f, cellSize * 0.22f),
                                        style = Stroke(width = cellSize * (0.06f + 0.04f * pulse))
                                    )
                                }

                                val fruit = cell.fruit
                                if (fruit != null) {
                                    if (isClearing) {
                                        val liftY = -cellSize * 0.16f * sin(clearT * PI).toFloat()
                                        center = Offset(center.x, center.y + liftY)
                                        // Luminous white match aura (Screenshots 1 & 3!)
                                        drawCircle(
                                            brush = Brush.radialGradient(
                                                listOf(
                                                    Color.White.copy(alpha = 0.88f * (1f - clearT * 0.45f)),
                                                    (if (isWave) GoldenStar else fruit.primaryColor).copy(alpha = 0.45f * (1f - clearT * 0.4f)),
                                                    Color.Transparent
                                                ),
                                                center = center,
                                                radius = cellSize * 0.66f
                                            ),
                                            radius = cellSize * 0.66f,
                                            center = center
                                        )
                                    }

                                    val bounceScale = if (isClearing) {
                                        if (clearT < 0.42f) 1f + 0.28f * (clearT / 0.42f)
                                        else 1.28f * (1f - (clearT - 0.42f) / 0.58f).coerceAtLeast(0.05f)
                                    } else if (isSelected) {
                                        1.12f
                                    } else if (isHinted) {
                                        1f + 0.08f * pulse
                                    } else {
                                        1f
                                    }

                                    val fruitAlpha = if (isClearing) (1f - clearT * 0.82f).coerceIn(0.12f, 1f) else 1f
                                    drawFruitShape(
                                        fruit = fruit,
                                        center = center,
                                        radius = cellSize * 0.39f * bounceScale,
                                        skin = activeSkin,
                                        special = cell.special,
                                        showSymbol = settings.colorblindSymbols,
                                        alpha = fruitAlpha,
                                        pulse = pulse
                                    )
                                }

                                if (cell.obstacle != ObstacleType.NONE) {
                                    drawObstacleOverlay(
                                        obstacle = cell.obstacle,
                                        hp = cell.obstacleHp,
                                        topLeft = Offset(cell.col * cellW, cell.row * cellH),
                                        cellSize = cellSize
                                    )
                                }

                                if (isClearing) {
                                    val baseColor = if (isWave) GoldenStar else (fruit?.primaryColor ?: BlossomPink)
                                    val bubbleColors = listOf(baseColor, StreamBlue, PastelYellow, SoftLavender, Color.White)
                                    val burstDist = cellSize * (0.20f + 0.44f * clearT)
                                    val particleAlpha = (1f - clearT * 0.72f).coerceIn(0f, 1f)

                                    // Sliced fruit wedge halves & juice droplets (Screenshots 4 & 11)
                                    if (fruit != null) {
                                        val wedgeRad = cellSize * 0.22f
                                        drawArc(
                                            color = fruit.primaryColor.copy(alpha = particleAlpha),
                                            startAngle = -35f - clearT * 45f,
                                            sweepAngle = 155f,
                                            useCenter = true,
                                            topLeft = Offset(center.x - wedgeRad - cellSize * 0.24f * clearT, center.y - wedgeRad),
                                            size = Size(wedgeRad * 2f, wedgeRad * 2f)
                                        )
                                        drawArc(
                                            color = fruit.secondaryColor.copy(alpha = particleAlpha),
                                            startAngle = 145f + clearT * 45f,
                                            sweepAngle = 155f,
                                            useCenter = true,
                                            topLeft = Offset(center.x - wedgeRad + cellSize * 0.24f * clearT, center.y - wedgeRad),
                                            size = Size(wedgeRad * 2f, wedgeRad * 2f)
                                        )
                                    }

                                    // Wooden splinters if obstacle was Crate
                                    if (cell.obstacle == ObstacleType.CRATE) {
                                        for (k in 0 until 4) {
                                            val ang = k * (PI / 2.0) + 0.4
                                            val sx = center.x + (cos(ang) * burstDist * 1.15f).toFloat()
                                            val sy = center.y + (sin(ang) * burstDist * 1.15f).toFloat()
                                            drawRoundRect(
                                                color = CrateWood.copy(alpha = particleAlpha),
                                                topLeft = Offset(sx - 6f, sy - 3f),
                                                size = Size(12f, 6f),
                                                cornerRadius = CornerRadius(2f, 2f)
                                            )
                                        }
                                    }

                                    for (s in 0 until 7) {
                                        val ang = s * (2.0 * PI / 7.0) + clearT * 0.6
                                        val px = center.x + (cos(ang) * burstDist).toFloat()
                                        val py = center.y + (sin(ang) * burstDist).toFloat()
                                        val pColor = bubbleColors[s % bubbleColors.size].copy(alpha = particleAlpha)
                                        if (s % 2 == 0) {
                                            drawCircle(pColor, cellSize * (0.095f * (1f - clearT * 0.4f)), Offset(px, py))
                                        } else {
                                            drawFourPointStar(Offset(px, py), cellSize * 0.11f, pColor)
                                        }
                                    }

                                    if (isWave) {
                                        val fxColor = when {
                                            SpecialKind.LIGHTNING_ROW in game.activeSpecialKinds ||
                                                SpecialKind.LIGHTNING_COL in game.activeSpecialKinds -> Color(0xFF42E8FF)
                                            SpecialKind.BOMB in game.activeSpecialKinds -> BlossomPink
                                            SpecialKind.RAINBOW in game.activeSpecialKinds -> SoftLavender
                                            else -> GoldenStar
                                        }
                                        drawCircle(
                                            color = fxColor.copy(alpha = 0.66f * (1f - clearT)),
                                            radius = cellSize * (0.28f + 0.48f * clearT),
                                            center = center,
                                            style = Stroke(width = cellSize * 0.085f)
                                        )
                                        if (SpecialKind.LIGHTNING_ROW in game.activeSpecialKinds) {
                                            drawLine(
                                                color = Color(0xFF8BEFFF).copy(alpha = 0.80f * (1f - clearT)),
                                                start = Offset(0f, center.y),
                                                end = Offset(size.width, center.y),
                                                strokeWidth = cellSize * 0.14f,
                                                cap = StrokeCap.Round
                                            )
                                        }
                                        if (SpecialKind.LIGHTNING_COL in game.activeSpecialKinds) {
                                            drawLine(
                                                color = Color(0xFF8BEFFF).copy(alpha = 0.80f * (1f - clearT)),
                                                start = Offset(center.x, 0f),
                                                end = Offset(center.x, size.height),
                                                strokeWidth = cellSize * 0.14f,
                                                cap = StrokeCap.Round
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Floating combo & score callouts
                        game.callouts.forEach { callout ->
                            val cellPx = with(density) { (boardWidthDp / cols).toPx() }
                            val xOff = (callout.col * cellPx).coerceAtLeast(8f).roundToInt()
                            val yOff = (callout.row * cellPx - cellPx * 0.4f).coerceAtLeast(6f).roundToInt()
                            Surface(
                                shape = RoundedCornerShape(99.dp),
                                color = if (callout.isGolden) GoldenStar else PeachOrangeDeep,
                                border = BorderStroke(2.dp, CreamParchmentLight),
                                shadowElevation = 6.dp,
                                modifier = Modifier.offset { IntOffset(xOff, yOff) }
                            ) {
                                Text(
                                    text = callout.text,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }

                        // Animated pointing hand for Interactive Tutorial
                        if (game.tutorialActive && game.tutorialHint != null && game.phase == GamePhase.IDLE) {
                            val th = game.tutorialHint
                            val cellPx = with(density) { (boardWidthDp / cols).toPx() }
                            val startX = th.c1 * cellPx + cellPx * 0.42f
                            val startY = th.r1 * cellPx + cellPx * 0.52f
                            val endX = th.c2 * cellPx + cellPx * 0.42f
                            val endY = th.r2 * cellPx + cellPx * 0.52f
                            val handX = (startX + (endX - startX) * handSlide).roundToInt()
                            val handY = (startY + (endY - startY) * handSlide).roundToInt()

                            Surface(
                                shape = CircleShape,
                                color = CreamParchmentLight,
                                border = BorderStroke(2.dp, PeachOrangeDeep),
                                shadowElevation = 6.dp,
                                modifier = Modifier
                                    .offset { IntOffset(handX, handY) }
                                    .size(44.dp)
                                    .testTag("tutorial_hand")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.TouchApp,
                                        contentDescription = "Swipe here",
                                        tint = PeachOrangeDeep,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Bottom Row: Aqua Pause Button (Screenshot 4/5/11 corner icon) + Cream Beveled Booster Tray
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AquaRoundIconButton(
                    icon = Icons.Rounded.Pause,
                    contentDescription = "Pause",
                    onClick = onPauseClick,
                    size = 52.dp,
                    testTag = "pause_button"
                )

                // Beveled Cream Parchment Booster Tray with Dark Indigo Inner Wells (Screenshot 5 dock!)
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.5.dp, CreamParchmentBevel),
                    shadowElevation = 6.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BoosterType.entries.forEach { booster ->
                            val count = progress.boosterInventory[booster] ?: 0
                            val selected = game.activeBooster == booster
                            val bIcon = when (booster) {
                                BoosterType.RAINBOW -> Icons.Rounded.AutoAwesome
                                BoosterType.BOMB -> Icons.Rounded.LocalFireDepartment
                                BoosterType.LIGHTNING -> Icons.Rounded.Bolt
                                BoosterType.MAGIC_PEACH -> Icons.Rounded.Star
                            }

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (selected) booster.accentColor else Color(0xFF42367A),
                                border = BorderStroke(
                                    1.5.dp,
                                    if (selected) CreamParchmentLight else Color(0xFF6B5AB0)
                                ),
                                shadowElevation = if (selected) 5.dp else 1.dp,
                                onClick = { onSelectBooster(booster) },
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("booster_${booster.id}")
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 5.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = bIcon,
                                            contentDescription = booster.title,
                                            tint = if (selected) Color.White else CreamParchmentLight,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = "$count",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                    }
                                    Text(
                                        text = booster.title,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CreamParchment.copy(alpha = 0.90f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PeachOrangeDeep,
                            border = BorderStroke(1.5.dp, CreamParchmentLight),
                            onClick = onHintClick,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("hint_button")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Lightbulb,
                                    contentDescription = "Hint",
                                    tint = GoldenStar,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Hint",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }
            }
        }

        if (game.mechanicTip != null && game.phase == GamePhase.IDLE) {
            MechanicTipDialog(
                tip = game.mechanicTip,
                onDismiss = onDismissMechanicTip
            )
        }

        when (game.phase) {
            GamePhase.PAUSED -> PauseOverlayDialog(
                levelNumber = game.level.levelNumber,
                onResume = onResumeClick,
                onRestart = onRestartLevel,
                onExitToHome = onExitToHome
            )
            GamePhase.VICTORY -> VictoryCelebrationOverlay(
                game = game,
                animationsEnabled = settings.animationsEnabled,
                onNextLevel = onNextLevel,
                onReplay = onRestartLevel,
                onOpenGarden = onOpenGarden,
                onHome = onExitToHome
            )
            GamePhase.FAILED -> RetryOverlay(
                game = game,
                objectiveProgress = objectiveProgress,
                onRetry = onRestartLevel,
                onMap = onOpenLevelMap,
                onHome = onExitToHome
            )
            else -> Unit
        }
    }
}
