package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppSettings
import com.example.model.GraphicsQuality
import com.example.model.UsernameValidation
import com.example.ui.LegalDocType
import com.example.ui.components.GameWoodenFrameModal
import com.example.ui.components.GlossyGreenPlayButton
import com.example.ui.components.OrchardBackdrop
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.GreenGlossMid
import com.example.ui.theme.MeadowDeepGreen
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SkyDeep
import com.example.ui.theme.StreamDeep

/**
 * Friendly Settings Popup strictly presenting ONLY the 7 requested items:
 * 1. Music on/off
 * 2. Sound effects on/off
 * 3. Change username
 * 4. Privacy information
 * 5. Terms of use
 * 6. Reset local progress
 * 7. Return to game
 */
@Composable
fun SettingsScreen(
    playerUsername: String,
    settings: AppSettings,
    effectiveGraphicsQuality: GraphicsQuality,
    onToggleMusic: (Boolean) -> Unit,
    onToggleSfx: (Boolean) -> Unit,
    onUpdateUsername: (String) -> UsernameValidation,
    onOpenLegalDoc: (LegalDocType) -> Unit,
    onResetProgress: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var showResetConfirm by remember { mutableStateOf(false) }
    var showEditUsername by remember { mutableStateOf(false) }
    var draftUsername by remember(playerUsername) { mutableStateOf(playerUsername) }
    var usernameError by remember { mutableStateOf<String?>(null) }

    OrchardBackdrop(
        topColor = SkyDeep,
        bottomColor = MeadowDeepGreen,
        graphicsQuality = effectiveGraphicsQuality,
        animationsEnabled = settings.animationsEnabled
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x771A0D07))
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            GameWoodenFrameModal(
                title = "Settings",
                onClose = onBack,
                modifier = Modifier
                    .widthIn(max = 460.dp)
                    .fillMaxWidth()
                    .testTag("settings_popup_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // 1. Music on/off
                    PopupSwitchItem(
                        title = "Music",
                        icon = Icons.Rounded.MusicNote,
                        checked = settings.isMusicOn,
                        tag = "switch_music",
                        onCheckedChange = onToggleMusic
                    )

                    HorizontalDivider(color = CreamParchmentBevel.copy(alpha = 0.7f))

                    // 2. Sound effects on/off
                    PopupSwitchItem(
                        title = "Sound Effects",
                        icon = Icons.AutoMirrored.Rounded.VolumeUp,
                        checked = settings.isSfxOn,
                        tag = "switch_sfx",
                        onCheckedChange = onToggleSfx
                    )

                    HorizontalDivider(color = CreamParchmentBevel.copy(alpha = 0.7f))

                    // 3. Change username
                    PopupActionItem(
                        label = "Change Username (${playerUsername.ifBlank { "Friend" }})",
                        icon = Icons.Rounded.Edit,
                        iconTint = PeachOrangeDeep,
                        testTag = "edit_username_button",
                        onClick = {
                            draftUsername = playerUsername
                            usernameError = null
                            showEditUsername = true
                        }
                    )

                    HorizontalDivider(color = CreamParchmentBevel.copy(alpha = 0.7f))

                    // 4. Privacy information
                    PopupActionItem(
                        label = "Privacy Information",
                        icon = Icons.Rounded.Policy,
                        iconTint = StreamDeep,
                        testTag = "privacy_info_button",
                        onClick = { onOpenLegalDoc(LegalDocType.PRIVACY) }
                    )

                    HorizontalDivider(color = CreamParchmentBevel.copy(alpha = 0.7f))

                    // 5. Terms of use
                    PopupActionItem(
                        label = "Terms of Use",
                        icon = Icons.Rounded.Description,
                        iconTint = StreamDeep,
                        testTag = "terms_of_use_button",
                        onClick = { onOpenLegalDoc(LegalDocType.TERMS) }
                    )

                    HorizontalDivider(color = CreamParchmentBevel.copy(alpha = 0.7f))

                    // 6. Reset local progress
                    PopupActionItem(
                        label = "Reset Local Progress",
                        icon = Icons.Rounded.DeleteForever,
                        iconTint = BlossomPink,
                        textColor = BlossomPink,
                        testTag = "reset_progress_button",
                        onClick = { showResetConfirm = true }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 7. Return to game
                    GlossyGreenPlayButton(
                        onClick = onBack,
                        minHeight = 56.dp,
                        testTag = "settings_return_button",
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Return to Game",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }

    if (showEditUsername) {
        AlertDialog(
            onDismissRequest = { showEditUsername = false },
            title = { Text("Change Username") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Choose a friendly 3–18 character name.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CocoaMuted
                    )
                    OutlinedTextField(
                        value = draftUsername,
                        onValueChange = {
                            if (it.length <= 18) {
                                draftUsername = it
                                usernameError = null
                            }
                        },
                        singleLine = true,
                        label = { Text("Username") },
                        isError = usernameError != null,
                        supportingText = {
                            usernameError?.let { Text(it, color = BlossomPink) }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_username_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        when (val res = onUpdateUsername(draftUsername)) {
                            is UsernameValidation.Valid -> showEditUsername = false
                            is UsernameValidation.Invalid -> usernameError = res.reason
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PeachOrangeDeep),
                    modifier = Modifier.testTag("save_username_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditUsername = false }) { Text("Cancel") }
            }
        )
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset Local Progress?") },
            text = {
                Text("Reset your level progress & stars, or wipe all local data including your username?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onResetProgress(false)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BlossomPink)
                ) {
                    Text("Reset Levels")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            showResetConfirm = false
                            onResetProgress(true)
                        }
                    ) {
                        Text("Wipe All", color = BlossomPink)
                    }
                    TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") }
                }
            }
        )
    }
}

@Composable
private fun PopupSwitchItem(
    title: String,
    icon: ImageVector,
    checked: Boolean,
    tag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = PeachOrangeDeep)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = BerryInk,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = GreenGlossMid,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = CreamParchmentBevel
            ),
            modifier = Modifier.testTag(tag)
        )
    }
}

@Composable
private fun PopupActionItem(
    label: String,
    icon: ImageVector,
    iconTint: Color,
    textColor: Color = BerryInk,
    testTag: String,
    onClick: () -> Unit
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(icon, contentDescription = null, tint = iconTint)
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                color = textColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
