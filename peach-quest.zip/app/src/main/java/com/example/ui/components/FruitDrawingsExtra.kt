package com.example.ui.components

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate

internal fun DrawScope.drawBlackberry(center: Offset, r: Float, alpha: Float) {
    val drupes = listOf(
        -0.28f to -0.35f, 0f to -0.38f, 0.28f to -0.35f,
        -0.38f to 0f, -0.12f to 0f, 0.14f to 0f, 0.38f to 0f,
        -0.24f to 0.35f, 0f to 0.38f, 0.24f to 0.35f,
        0f to 0.65f
    )
    drupes.forEach { (dx, dy) ->
        val oc = Offset(center.x + r * dx, center.y + r * dy)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFF7D62B8).copy(alpha = alpha), Color(0xFF3B285E).copy(alpha = alpha)),
                center = Offset(oc.x - r * 0.06f, oc.y - r * 0.06f),
                radius = r * 0.32f
            ),
            radius = r * 0.22f,
            center = oc
        )
    }
    drawLeaf(Offset(center.x - r * 0.1f, center.y - r * 0.66f), r * 0.72f, alpha)
}

internal fun DrawScope.drawRaspberry(center: Offset, r: Float, alpha: Float) {
    val drupes = listOf(
        -0.28f to -0.25f, 0f to -0.3f, 0.28f to -0.25f,
        -0.34f to 0.08f, 0f to 0.06f, 0.34f to 0.08f,
        -0.2f to 0.42f, 0.2f to 0.42f, 0f to 0.65f
    )
    drupes.forEach { (dx, dy) ->
        val oc = Offset(center.x + r * dx, center.y + r * dy)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFFFF8AA8).copy(alpha = alpha), Color(0xFFD6285A).copy(alpha = alpha)),
                center = Offset(oc.x - r * 0.06f, oc.y - r * 0.06f),
                radius = r * 0.34f
            ),
            radius = r * 0.24f,
            center = oc
        )
    }
    drawLeaf(Offset(center.x - r * 0.05f, center.y - r * 0.62f), r * 0.75f, alpha)
}

internal fun DrawScope.drawCherry(center: Offset, r: Float, alpha: Float) {
    val stemTop = Offset(center.x + r * 0.05f, center.y - r * 0.85f)
    val leftC = Offset(center.x - r * 0.38f, center.y + r * 0.34f)
    val rightC = Offset(center.x + r * 0.38f, center.y + r * 0.4f)
    drawLine(Color(0xFF4CAF6A).copy(alpha = alpha), stemTop, Offset(leftC.x, leftC.y - r * 0.35f), strokeWidth = r * 0.09f, cap = StrokeCap.Round)
    drawLine(Color(0xFF4CAF6A).copy(alpha = alpha), stemTop, Offset(rightC.x, rightC.y - r * 0.35f), strokeWidth = r * 0.09f, cap = StrokeCap.Round)
    drawLeaf(stemTop, r * 0.68f, alpha)
    listOf(leftC, rightC).forEach { c ->
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFFFF6B81).copy(alpha = alpha), Color(0xFFD90429).copy(alpha = alpha)),
                center = Offset(c.x - r * 0.14f, c.y - r * 0.14f),
                radius = r * 0.65f
            ),
            radius = r * 0.44f,
            center = c
        )
        drawCircle(Color.White.copy(alpha = 0.55f * alpha), r * 0.1f, Offset(c.x - r * 0.15f, c.y - r * 0.15f))
    }
}

internal fun DrawScope.drawPear(center: Offset, r: Float, alpha: Float) {
    val path = Path().apply {
        moveTo(center.x, center.y - r * 0.78f)
        cubicTo(center.x + r * 0.44f, center.y - r * 0.78f, center.x + r * 0.38f, center.y - r * 0.15f, center.x + r * 0.68f, center.y + r * 0.18f)
        cubicTo(center.x + r * 0.92f, center.y + r * 0.62f, center.x + r * 0.45f, center.y + r * 0.96f, center.x, center.y + r * 0.94f)
        cubicTo(center.x - r * 0.45f, center.y + r * 0.96f, center.x - r * 0.92f, center.y + r * 0.62f, center.x - r * 0.68f, center.y + r * 0.18f)
        cubicTo(center.x - r * 0.38f, center.y - r * 0.15f, center.x - r * 0.44f, center.y - r * 0.78f, center.x, center.y - r * 0.78f)
        close()
    }
    drawPath(
        path,
        brush = Brush.radialGradient(
            listOf(Color(0xFFE7F58E).copy(alpha = alpha), Color(0xFFAACC00).copy(alpha = alpha)),
            center = Offset(center.x - r * 0.2f, center.y),
            radius = r * 1.3f
        )
    )
    drawLine(Color(0xFF7F4F24).copy(alpha = alpha), Offset(center.x, center.y - r * 0.76f), Offset(center.x + r * 0.06f, center.y - r * 0.98f), strokeWidth = r * 0.09f, cap = StrokeCap.Round)
    drawLeaf(Offset(center.x, center.y - r * 0.8f), r * 0.65f, alpha)
}

internal fun DrawScope.drawPineapple(center: Offset, r: Float, alpha: Float) {
    val crown = Path().apply {
        moveTo(center.x - r * 0.38f, center.y - r * 0.44f)
        lineTo(center.x - r * 0.46f, center.y - r * 0.88f)
        lineTo(center.x - r * 0.15f, center.y - r * 0.64f)
        lineTo(center.x, center.y - r * 0.98f)
        lineTo(center.x + r * 0.15f, center.y - r * 0.64f)
        lineTo(center.x + r * 0.46f, center.y - r * 0.88f)
        lineTo(center.x + r * 0.38f, center.y - r * 0.44f)
        close()
    }
    drawPath(crown, Color(0xFF38C98A).copy(alpha = alpha))
    drawRoundRect(
        brush = Brush.verticalGradient(listOf(Color(0xFFFFD166).copy(alpha = alpha), Color(0xFFF4A21D).copy(alpha = alpha))),
        topLeft = Offset(center.x - r * 0.56f, center.y - r * 0.44f),
        size = Size(r * 1.12f, r * 1.3f),
        cornerRadius = CornerRadius(r * 0.48f, r * 0.48f)
    )
    // Diamond criss-cross accents
    drawLine(Color(0xFFC97A00).copy(alpha = 0.45f * alpha), Offset(center.x - r * 0.34f, center.y - r * 0.15f), Offset(center.x + r * 0.34f, center.y + r * 0.55f), strokeWidth = r * 0.06f)
    drawLine(Color(0xFFC97A00).copy(alpha = 0.45f * alpha), Offset(center.x + r * 0.34f, center.y - r * 0.15f), Offset(center.x - r * 0.34f, center.y + r * 0.55f), strokeWidth = r * 0.06f)
}

internal fun DrawScope.drawMango(center: Offset, r: Float, alpha: Float) {
    rotate(degrees = -22f, pivot = center) {
        drawOval(
            brush = Brush.linearGradient(
                listOf(Color(0xFFFF4D38).copy(alpha = alpha), Color(0xFFFF9F1C).copy(alpha = alpha), Color(0xFFFFE066).copy(alpha = alpha)),
                start = Offset(center.x - r * 0.7f, center.y - r * 0.7f),
                end = Offset(center.x + r * 0.7f, center.y + r * 0.7f)
            ),
            topLeft = Offset(center.x - r * 0.65f, center.y - r * 0.88f),
            size = Size(r * 1.3f, r * 1.76f)
        )
    }
    drawLeaf(Offset(center.x + r * 0.15f, center.y - r * 0.7f), r * 0.75f, alpha)
    drawCircle(Color.White.copy(alpha = 0.45f * alpha), r * 0.14f, Offset(center.x - r * 0.24f, center.y - r * 0.25f))
}

internal fun DrawScope.drawBanana(center: Offset, r: Float, alpha: Float) {
    val path = Path().apply {
        moveTo(center.x - r * 0.78f, center.y + r * 0.38f)
        quadraticTo(center.x + r * 0.1f, center.y + r * 1.05f, center.x + r * 0.76f, center.y - r * 0.62f)
        quadraticTo(center.x + r * 0.26f, center.y + r * 0.42f, center.x - r * 0.78f, center.y + r * 0.38f)
        close()
    }
    drawPath(
        path,
        brush = Brush.linearGradient(listOf(Color(0xFFFFF59D).copy(alpha = alpha), Color(0xFFFFD60A).copy(alpha = alpha)))
    )
    drawPath(path, Color(0xFFD9A300).copy(alpha = 0.55f * alpha), style = Stroke(r * 0.06f))
    drawCircle(Color(0xFF7F4F24).copy(alpha = alpha), r * 0.09f, Offset(center.x + r * 0.76f, center.y - r * 0.64f))
}

internal fun DrawScope.drawKiwi(center: Offset, r: Float, alpha: Float) {
    drawCircle(Color(0xFF8D5B3A).copy(alpha = alpha), r * 0.88f, center)
    drawCircle(Color(0xFF70A935).copy(alpha = alpha), r * 0.74f, center)
    drawCircle(Color(0xFFDCEFA8).copy(alpha = alpha), r * 0.28f, center)
    for (i in 0 until 8) {
        val ang = i * Math.PI / 4.0
        val sx = center.x + (kotlin.math.cos(ang) * r * 0.48f).toFloat()
        val sy = center.y + (kotlin.math.sin(ang) * r * 0.48f).toFloat()
        drawCircle(Color(0xFF2E1A21).copy(alpha = alpha), r * 0.048f, Offset(sx, sy))
    }
}

internal fun DrawScope.drawCoconut(center: Offset, r: Float, alpha: Float) {
    drawCircle(Color(0xFF7F5539).copy(alpha = alpha), r * 0.88f, center)
    drawCircle(Color(0xFFFDF8F2).copy(alpha = alpha), r * 0.66f, center)
    drawCircle(Color(0xFFE6ECEF).copy(alpha = alpha), r * 0.34f, center)
    drawCircle(Color.White.copy(alpha = 0.6f * alpha), r * 0.14f, Offset(center.x - r * 0.24f, center.y - r * 0.24f))
}

internal fun DrawScope.drawDragonFruit(center: Offset, r: Float, alpha: Float) {
    // Green spiky fins around bright magenta body
    drawCircle(Color(0xFF38C98A).copy(alpha = alpha), r * 0.92f, center)
    drawOval(
        brush = Brush.radialGradient(listOf(Color(0xFFFF7EB3).copy(alpha = alpha), Color(0xFFE82C74).copy(alpha = alpha))),
        topLeft = Offset(center.x - r * 0.74f, center.y - r * 0.84f),
        size = Size(r * 1.48f, r * 1.68f)
    )
    drawOval(Color(0xFFFFF8FA).copy(alpha = alpha), Offset(center.x - r * 0.48f, center.y - r * 0.56f), Size(r * 0.96f, r * 1.12f))
    listOf(-0.2f to -0.2f, 0.2f to -0.15f, 0f to 0.1f, -0.18f to 0.28f, 0.18f to 0.28f).forEach { (dx, dy) ->
        drawCircle(Color(0xFF2E1A21).copy(alpha = alpha), r * 0.048f, Offset(center.x + r * dx, center.y + r * dy))
    }
}

internal fun DrawScope.drawPlum(center: Offset, r: Float, alpha: Float) {
    drawOval(
        brush = Brush.radialGradient(
            listOf(Color(0xFFB16CE8).copy(alpha = alpha), Color(0xFF6A2E7A).copy(alpha = alpha), Color(0xFF3C124A).copy(alpha = alpha)),
            center = Offset(center.x - r * 0.25f, center.y - r * 0.2f),
            radius = r * 1.25f
        ),
        topLeft = Offset(center.x - r * 0.78f, center.y - r * 0.82f),
        size = Size(r * 1.56f, r * 1.68f)
    )
    drawLeaf(Offset(center.x, center.y - r * 0.76f), r * 0.7f, alpha)
    drawCircle(Color.White.copy(alpha = 0.48f * alpha), r * 0.16f, Offset(center.x - r * 0.28f, center.y - r * 0.28f))
}

internal fun DrawScope.drawPomegranate(center: Offset, r: Float, alpha: Float) {
    // Calyx crown
    val crown = Path().apply {
        moveTo(center.x - r * 0.24f, center.y - r * 0.7f)
        lineTo(center.x - r * 0.3f, center.y - r * 0.98f)
        lineTo(center.x, center.y - r * 0.82f)
        lineTo(center.x + r * 0.3f, center.y - r * 0.98f)
        lineTo(center.x + r * 0.24f, center.y - r * 0.7f)
        close()
    }
    drawPath(crown, Color(0xFFB5173B).copy(alpha = alpha))
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFF06584).copy(alpha = alpha), Color(0xFFB5173B).copy(alpha = alpha)),
            center = Offset(center.x - r * 0.25f, center.y - r * 0.2f),
            radius = r * 1.25f
        ),
        radius = r * 0.84f,
        center = Offset(center.x, center.y + r * 0.08f)
    )
    listOf(-0.22f to 0f, 0.14f to -0.1f, 0f to 0.25f, 0.25f to 0.22f).forEach { (dx, dy) ->
        drawCircle(Color(0xFFFFD6DF).copy(alpha = 0.75f * alpha), r * 0.08f, Offset(center.x + r * dx, center.y + r * dy))
    }
}

internal fun DrawScope.drawPapaya(center: Offset, r: Float, alpha: Float) {
    drawOval(
        brush = Brush.verticalGradient(listOf(Color(0xFF84C341).copy(alpha = alpha), Color(0xFFFFB26B).copy(alpha = alpha))),
        topLeft = Offset(center.x - r * 0.68f, center.y - r * 0.9f),
        size = Size(r * 1.36f, r * 1.8f)
    )
    drawOval(
        Color(0xFFFF6E40).copy(alpha = alpha),
        topLeft = Offset(center.x - r * 0.46f, center.y - r * 0.64f),
        size = Size(r * 0.92f, r * 1.28f)
    )
    listOf(-0.1f to -0.2f, 0.1f to -0.15f, -0.08f to 0.06f, 0.1f to 0.14f, 0f to 0.3f).forEach { (dx, dy) ->
        drawCircle(Color(0xFF2E1A21).copy(alpha = alpha), r * 0.065f, Offset(center.x + r * dx, center.y + r * dy))
    }
}

internal fun DrawScope.drawAvocado(center: Offset, r: Float, alpha: Float) {
    drawOval(Color(0xFF4F772D).copy(alpha = alpha), Offset(center.x - r * 0.7f, center.y - r * 0.88f), Size(r * 1.4f, r * 1.78f))
    drawOval(Color(0xFFC5E88A).copy(alpha = alpha), Offset(center.x - r * 0.54f, center.y - r * 0.68f), Size(r * 1.08f, r * 1.42f))
    drawCircle(
        brush = Brush.radialGradient(listOf(Color(0xFFA66E4E).copy(alpha = alpha), Color(0xFF6F3E24).copy(alpha = alpha))),
        radius = r * 0.34f,
        center = Offset(center.x, center.y + r * 0.22f)
    )
}

internal fun DrawScope.drawPassionFruit(center: Offset, r: Float, alpha: Float) {
    drawCircle(Color(0xFF6920A8).copy(alpha = alpha), r * 0.86f, center)
    drawCircle(Color(0xFFFFD13B).copy(alpha = alpha), r * 0.64f, center)
    listOf(-0.22f to -0.18f, 0.22f to -0.14f, 0f to 0.08f, -0.2f to 0.24f, 0.22f to 0.22f).forEach { (dx, dy) ->
        drawCircle(Color(0xFF3E1C0A).copy(alpha = alpha), r * 0.06f, Offset(center.x + r * dx, center.y + r * dy))
    }
}
