package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.GraphicsQuality
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachMascotCharacter
import com.example.ui.components.drawButterfly
import com.example.ui.components.drawFourPointStar
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgTop
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.SunWarm
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GardenRevealScreen(
    username: String,
    animationsEnabled: Boolean,
    graphicsQuality: GraphicsQuality,
    onFinish: () -> Unit
) {
    BackHandler(onBack = onFinish)

    val revealProgress = remember { Animatable(0f) }
    LaunchedEffect(animationsEnabled) {
        revealProgress.snapTo(0f)
        revealProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = if (animationsEnabled) 1200 else 300,
                easing = FastOutSlowInEasing
            )
        )
    }

    val p = revealProgress.value
    val cameraZoom = 1f + 0.10f * p
    val displayUser = username.ifBlank { "Friend" }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = cameraZoom
                    scaleY = cameraZoom
                }
        ) {
            OrchardBackdrop(
                topColor = com.example.ui.theme.SkyDeep,
                bottomColor = com.example.ui.theme.MeadowDeepGreen,
                graphicsQuality = graphicsQuality,
                animationsEnabled = animationsEnabled,
                showFloatingFruits = true
            ) {}
        }

        // Animated Garden Gates opening left/right + butterflies + sparkles
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val gateTop = h * 0.16f
            val gateHeight = h * 0.72f
            val doorWidth = w * 0.44f
            val slideOut = w * 0.46f * p

            val woodBrush = Brush.verticalGradient(
                listOf(Color(0xFFD98F54), Color(0xFFA8612C))
            )

            // Left Garden Gate Door
            val leftX = w * 0.06f - slideOut
            drawRoundRect(
                brush = woodBrush,
                topLeft = Offset(leftX, gateTop),
                size = Size(doorWidth, gateHeight),
                cornerRadius = CornerRadius(32f, 32f)
            )
            drawRoundRect(
                color = GoldenStar,
                topLeft = Offset(leftX + 10f, gateTop + 10f),
                size = Size(doorWidth - 20f, gateHeight - 20f),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 6f)
            )

            // Right Garden Gate Door
            val rightX = w * 0.50f + slideOut
            drawRoundRect(
                brush = woodBrush,
                topLeft = Offset(rightX, gateTop),
                size = Size(doorWidth, gateHeight),
                cornerRadius = CornerRadius(32f, 32f)
            )
            drawRoundRect(
                color = GoldenStar,
                topLeft = Offset(rightX + 10f, gateTop + 10f),
                size = Size(doorWidth - 20f, gateHeight - 20f),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 6f)
            )

            // Butterflies flying out as gate opens
            val flap = 0.55f + 0.45f * absSin(p * 8f)
            val b1 = Offset(w * (0.48f - 0.30f * p), h * (0.50f - 0.24f * p))
            val b2 = Offset(w * (0.52f + 0.32f * p), h * (0.52f - 0.28f * p))
            val b3 = Offset(w * (0.50f + 0.14f * cos(p * PI).toFloat()), h * (0.64f - 0.38f * p))
            drawButterfly(b1, 24f, flap, PeachOrange, SunWarm)
            drawButterfly(b2, 22f, flap, BlossomPink, SoftLavender)
            drawButterfly(b3, 18f, flap, GoldenStar, PeachOrangeDeep)

            // Floating celebration sparkles
            for (i in 0 until 12) {
                val angle = i * (2.0 * PI / 12.0) + p * 1.4
                val dist = size.minDimension * (0.14f + 0.34f * p)
                val sx = w / 2f + (cos(angle) * dist).toFloat()
                val sy = h * 0.46f + (sin(angle) * dist).toFloat()
                drawFourPointStar(
                    center = Offset(sx, sy),
                    outerRadius = 11f * (1f - p * 0.25f),
                    color = if (i % 2 == 0) SunWarm else Color.White.copy(alpha = 0.9f)
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 24.dp)
                .graphicsLayer {
                    alpha = (p * 1.6f).coerceIn(0.25f, 1f)
                    scaleX = 0.88f + 0.12f * p
                    scaleY = 0.88f + 0.12f * p
                }
        ) {
            PeachMascotCharacter(size = 118.dp, animationsEnabled = animationsEnabled)
            Spacer(modifier = Modifier.height(14.dp))
            Surface(
                shape = RoundedCornerShape(30.dp),
                color = com.example.ui.theme.CreamParchment,
                border = androidx.compose.foundation.BorderStroke(2.5.dp, com.example.ui.theme.GoldenBevel),
                shadowElevation = 10.dp
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 26.dp, vertical = 20.dp)
                ) {
                    Text(
                        text = "Welcome to Peach Quest,\n$displayUser!",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PeachOrangeDeep,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("garden_reveal_title")
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "The magical fruit garden is open!",
                        style = MaterialTheme.typography.bodyLarge,
                        color = BerryInk,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Tap anywhere to enter",
                        style = MaterialTheme.typography.labelLarge,
                        color = CocoaMuted
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClickLabel = "Enter Peach Quest garden",
                    onClick = onFinish
                )
                .testTag("garden_reveal_screen")
        )
    }
}

private fun absSin(radians: Float): Float {
    val s = sin(radians.toDouble()).toFloat()
    return if (s < 0f) -s else s
}
