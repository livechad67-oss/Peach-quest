package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.legal.LegalContent
import com.example.ui.LegalDocType
import com.example.ui.components.PeachCard
import com.example.ui.theme.BerryInk
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgTop

@Composable
fun LegalDocumentScreen(
    docType: LegalDocType,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val bodyText = when (docType) {
        LegalDocType.PRIVACY -> LegalContent.privacyPolicyText
        LegalDocType.TERMS -> LegalContent.termsOfServiceText
        LegalDocType.CONDUCT -> LegalContent.conductPolicyText
        LegalDocType.CREDITS -> LegalContent.creditsText
    }

    com.example.ui.components.OrchardBackdrop(
        topColor = com.example.ui.theme.SkyDeep,
        bottomColor = com.example.ui.theme.MeadowDeepGreen
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 620.dp)
                .align(Alignment.Center)
        ) {
            com.example.ui.components.GameStripedBanner {
                com.example.ui.components.AquaRoundIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    onClick = onBack,
                    size = 46.dp,
                    testTag = "legal_doc_back"
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = docType.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = com.example.ui.theme.CreamParchmentLight,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                PeachCard(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp)
                    ) {
                        Text(
                            text = bodyText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = BerryInk,
                            modifier = Modifier.testTag("legal_doc_body")
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}
