package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.GraphicsQuality
import com.example.model.UsernameValidation
import com.example.model.UsernameValidator
import com.example.ui.LegalDocType
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachCard
import com.example.ui.components.PeachMascotCharacter
import com.example.ui.components.PeachPrimaryButton
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.CreamSurface
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgTop
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.SoftPeach
import com.example.ui.theme.SoftRoseBorder
import com.example.ui.theme.StreamBlue

@Composable
fun UsernameScreen(
    initialUsername: String,
    initialLegalAccepted: Boolean,
    initialAnalyticsConsent: Boolean,
    errorText: String?,
    animationsEnabled: Boolean,
    graphicsQuality: GraphicsQuality,
    onClearError: () -> Unit,
    onOpenDoc: (LegalDocType) -> Unit,
    onSubmit: (String, Boolean, Boolean) -> UsernameValidation
) {
    var username by rememberSaveable { mutableStateOf(initialUsername) }
    var legalAccepted by rememberSaveable { mutableStateOf(initialLegalAccepted) }

    val liveValidation = if (username.isNotBlank()) UsernameValidator.validate(username) else null
    val canSubmit = username.trim().length >= 3 && legalAccepted

    OrchardBackdrop(
        topColor = com.example.ui.theme.SkyDeep,
        bottomColor = com.example.ui.theme.MeadowDeepGreen,
        graphicsQuality = graphicsQuality,
        animationsEnabled = animationsEnabled,
        showFloatingFruits = true
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 520.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Spacer(modifier = Modifier.weight(0.35f))

            PeachMascotCharacter(
                size = 116.dp,
                animationsEnabled = animationsEnabled,
                modifier = Modifier.testTag("username_mascot")
            )

            Spacer(modifier = Modifier.height(6.dp))

            PeachCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "What should we call you?",
                        style = MaterialTheme.typography.headlineMedium,
                        color = BerryInk,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("username_prompt_title")
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pick a fun garden nickname to start your adventure!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CocoaMuted,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            if (it.length <= 18) {
                                username = it
                                onClearError()
                            }
                        },
                        singleLine = true,
                        placeholder = { Text("Enter your username") },
                        leadingIcon = {
                            Icon(Icons.Rounded.Face, contentDescription = null, tint = PeachOrange)
                        },
                        supportingText = {
                            val msg = when {
                                errorText != null -> errorText
                                liveValidation is UsernameValidation.Invalid -> liveValidation.reason
                                else -> "3–18 letters or numbers • Saved on this device"
                            }
                            Text(
                                text = msg,
                                color = if (errorText != null || liveValidation is UsernameValidation.Invalid) {
                                    BlossomPink
                                } else {
                                    CocoaMuted
                                }
                            )
                        },
                        isError = errorText != null || liveValidation is UsernameValidation.Invalid,
                        shape = RoundedCornerShape(28.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PeachOrange,
                            unfocusedBorderColor = SoftRoseBorder,
                            focusedContainerColor = CreamSurface,
                            unfocusedContainerColor = SoftPeach.copy(alpha = 0.28f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("username_input")
                    )

                    if (errorText != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = BlossomPink.copy(alpha = 0.14f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_error_banner")
                        ) {
                            Text(
                                text = errorText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = BlossomPink,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = SoftPeach.copy(alpha = 0.42f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = legalAccepted,
                                    onCheckedChange = {
                                        legalAccepted = it
                                        onClearError()
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = PeachOrange,
                                        uncheckedColor = StreamBlue
                                    ),
                                    modifier = Modifier.testTag("onboarding_legal_checkbox")
                                )
                                Text(
                                    text = "I accept the Privacy Information & Terms of Use.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = BerryInk,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(start = 10.dp)
                            ) {
                                TextButton(onClick = { onOpenDoc(LegalDocType.PRIVACY) }) {
                                    Text("Privacy", color = StreamBlue, fontWeight = FontWeight.Bold)
                                }
                                TextButton(onClick = { onOpenDoc(LegalDocType.TERMS) }) {
                                    Text("Terms", color = StreamBlue, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    com.example.ui.components.GlossyGreenPlayButton(
                        onClick = { onSubmit(username, legalAccepted, initialAnalyticsConsent) },
                        enabled = canSubmit,
                        minHeight = 64.dp,
                        testTag = "onboarding_continue_button",
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LET'S PLAY!",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.65f))
        }
    }
}
