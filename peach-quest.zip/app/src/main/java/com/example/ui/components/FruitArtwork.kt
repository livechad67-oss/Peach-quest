package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.FruitSkin
import com.example.model.FruitType
import com.example.model.ObstacleType
import com.example.ui.theme.CrateWood
import com.example.ui.theme.CrateWoodDark
import com.example.ui.theme.IceBlue
import com.example.ui.theme.IceBorder
import com.example.ui.theme.VineGreen
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FruitIconCanvas(
    fruit: FruitType,
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    skin: FruitSkin = FruitSkin.CLASSIC,
    special: com.example.model.SpecialKind = com.example.model.SpecialKind.NONE,
    showSymbol: Boolean = false
) {
    Canvas(modifier = modifier.size(size)) {
        val r = this.size.minDimension * 0.43f
        drawFruitShape(
            fruit = fruit,
            center = Offset(this.size.width / 2f, this.size.height / 2f),
            radius = r,
            skin = skin,
            special = special,
            showSymbol = showSymbol,
            alpha = 1f,
            pulse = 0f
        )
    }
}

fun DrawScope.drawFruitShape(
    fruit: FruitType,
    center: Offset,
    radius: Float,
    skin: FruitSkin = FruitSkin.CLASSIC,
    special: com.example.model.SpecialKind = com.example.model.SpecialKind.NONE,
    showSymbol: Boolean = false,
    alpha: Float = 1f,
    pulse: Float = 0f
) {
    // Soft grounded contact shadow under fruit
    drawCircle(
        color = Color(0xFF1F0D05).copy(alpha = 0.24f * alpha),
        radius = radius * 0.94f,
        center = Offset(center.x + radius * 0.04f, center.y + radius * 0.14f)
    )

    if (skin == FruitSkin.ROYAL_CROWN && fruit != FruitType.GOLDEN_PINEAPPLE) {
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFFFFD84D).copy(alpha = 0.55f * alpha), Color.Transparent),
                center = center,
                radius = radius * 1.24f
            ),
            radius = radius * 1.24f,
            center = center
        )
    }

    if (special != com.example.model.SpecialKind.NONE) {
        drawSpecialUnderlay(special, center, radius, alpha, pulse)
    }

    when (fruit) {
        FruitType.PEACH -> drawPeach(center, radius, alpha)
        FruitType.STRAWBERRY -> drawStrawberry(center, radius, alpha)
        FruitType.RED_APPLE -> drawApple(center, radius, alpha, isGreen = false)
        FruitType.GREEN_APPLE -> drawApple(center, radius, alpha, isGreen = true)
        FruitType.ORANGE -> drawOrange(center, radius, alpha)
        FruitType.LEMON -> drawLemon(center, radius, alpha)
        FruitType.WATERMELON -> drawWatermelon(center, radius, alpha)
        FruitType.GRAPES -> drawGrapes(center, radius, alpha)
        FruitType.BLUEBERRY -> drawBlueberry(center, radius, alpha)
        FruitType.BLACKBERRY -> drawBlackberry(center, radius, alpha)
        FruitType.CHERRY -> drawCherry(center, radius, alpha)
        FruitType.PEAR -> drawPear(center, radius, alpha)
        FruitType.PINEAPPLE -> drawPineapple(center, radius, alpha)
        FruitType.MANGO -> drawMango(center, radius, alpha)
        FruitType.BANANA -> drawBanana(center, radius, alpha)
        FruitType.KIWI -> drawKiwi(center, radius, alpha)
        FruitType.COCONUT -> drawCoconut(center, radius, alpha)
        FruitType.DRAGON_FRUIT -> drawDragonFruit(center, radius, alpha)
        FruitType.RASPBERRY -> drawRaspberry(center, radius, alpha)
        FruitType.PLUM -> drawPlum(center, radius, alpha)
        FruitType.POMEGRANATE -> drawPomegranate(center, radius, alpha)
        FruitType.PAPAYA -> drawPapaya(center, radius, alpha)
        FruitType.AVOCADO -> drawAvocado(center, radius, alpha)
        FruitType.PASSION_FRUIT -> drawPassionFruit(center, radius, alpha)
        FruitType.GOLDEN_PINEAPPLE -> drawGoldenPineapple(center, radius, alpha, pulse)
    }

    // Crisp specular shine oval + bottom bounce rim light for tactile 3D candy polish
    drawArc(
        color = Color.White.copy(alpha = 0.56f * alpha),
        startAngle = 204f,
        sweepAngle = 66f,
        useCenter = false,
        topLeft = Offset(center.x - radius * 0.72f, center.y - radius * 0.72f),
        size = Size(radius * 1.44f, radius * 1.44f),
        style = Stroke(width = radius * 0.12f, cap = StrokeCap.Round)
    )
    drawCircle(
        color = Color.White.copy(alpha = 0.52f * alpha),
        radius = radius * 0.085f,
        center = Offset(center.x - radius * 0.04f, center.y - radius * 0.65f)
    )

    if (special != com.example.model.SpecialKind.NONE) {
        drawSpecialBadgeOverlay(special, center, radius, alpha, pulse)
    }

    // Fruit skin overlays
    when (skin) {
        FruitSkin.CLASSIC -> Unit
        FruitSkin.CANDY_GLAZE -> {
            drawCircle(
                color = Color.White.copy(alpha = 0.7f * alpha),
                radius = radius * 0.16f,
                center = Offset(center.x - radius * 0.34f, center.y - radius * 0.34f)
            )
            drawFourPointStar(
                center = Offset(center.x + radius * 0.42f, center.y - radius * 0.36f),
                outerRadius = radius * 0.19f,
                color = Color.White.copy(alpha = 0.88f * alpha)
            )
        }
        FruitSkin.ROYAL_CROWN -> {
            drawCircle(
                color = Color(0xFFFFC300).copy(alpha = 0.62f * alpha),
                radius = radius * 0.96f,
                center = center,
                style = Stroke(width = radius * 0.06f)
            )
            drawFourPointStar(
                center = Offset(center.x + radius * 0.46f, center.y - radius * 0.42f),
                outerRadius = radius * 0.21f,
                color = Color(0xFFFFE66D).copy(alpha = 0.95f * alpha)
            )
        }
    }

    if (showSymbol && fruit != FruitType.GOLDEN_PINEAPPLE) {
        val badgeCenter = Offset(center.x + radius * 0.56f, center.y + radius * 0.56f)
        drawCircle(Color.White.copy(alpha = 0.94f * alpha), radius * 0.28f, badgeCenter)
        drawCircle(fruit.primaryColor.copy(alpha = alpha), radius * 0.21f, badgeCenter)
        val dotCount = (fruit.ordinal % 3) + 1
        for (i in 0 until dotCount) {
            val dx = (i - (dotCount - 1) / 2f) * radius * 0.1f
            drawCircle(Color.White.copy(alpha = alpha), radius * 0.042f, Offset(badgeCenter.x + dx, badgeCenter.y))
        }
    }
}

private fun DrawScope.drawSpecialUnderlay(
    special: com.example.model.SpecialKind,
    center: Offset,
    radius: Float,
    alpha: Float,
    pulse: Float
) {
    when (special) {
        com.example.model.SpecialKind.RAINBOW -> {
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(
                        Color(0xFFFF5277).copy(alpha = 0.9f * alpha),
                        Color(0xFFFFB703).copy(alpha = 0.9f * alpha),
                        Color(0xFF39C682).copy(alpha = 0.9f * alpha),
                        Color(0xFF47B5F7).copy(alpha = 0.9f * alpha),
                        Color(0xFF935BF2).copy(alpha = 0.9f * alpha),
                        Color(0xFFFF5277).copy(alpha = 0.9f * alpha)
                    ),
                    center = center
                ),
                radius = radius * (1.06f + 0.08f * pulse),
                center = center,
                style = Stroke(width = radius * 0.16f)
            )
        }
        com.example.model.SpecialKind.BOMB -> {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFFFF5277).copy(alpha = 0.52f * alpha), Color.Transparent),
                    center = center,
                    radius = radius * 1.26f
                ),
                radius = radius * 1.26f,
                center = center
            )
        }
        com.example.model.SpecialKind.LIGHTNING_ROW,
        com.example.model.SpecialKind.LIGHTNING_COL -> {
            // Glowing cyan directional arrow fins like the special fruits in the reference screenshots
            val isRow = special == com.example.model.SpecialKind.LIGHTNING_ROW
            val reach = radius * (1.18f + 0.10f * pulse)
            val wingSpread = radius * 0.34f
            val cyanGlow = Color(0xFF5CF2FF).copy(alpha = alpha)
            val cyanDeep = Color(0xFF0E90C9).copy(alpha = alpha)

            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF70F5FF).copy(alpha = 0.62f * alpha), Color.Transparent),
                    center = center,
                    radius = radius * 1.28f
                ),
                radius = radius * 1.28f,
                center = center
            )

            if (isRow) {
                val leftArrow = Path().apply {
                    moveTo(center.x - reach, center.y)
                    lineTo(center.x - radius * 0.62f, center.y - wingSpread)
                    lineTo(center.x - radius * 0.62f, center.y + wingSpread)
                    close()
                }
                val rightArrow = Path().apply {
                    moveTo(center.x + reach, center.y)
                    lineTo(center.x + radius * 0.62f, center.y - wingSpread)
                    lineTo(center.x + radius * 0.62f, center.y + wingSpread)
                    close()
                }
                drawPath(leftArrow, cyanGlow)
                drawPath(rightArrow, cyanGlow)
                drawPath(leftArrow, Color.White.copy(alpha = 0.9f * alpha), style = Stroke(width = radius * 0.06f))
                drawPath(rightArrow, Color.White.copy(alpha = 0.9f * alpha), style = Stroke(width = radius * 0.06f))
            } else {
                val upArrow = Path().apply {
                    moveTo(center.x, center.y - reach)
                    lineTo(center.x - wingSpread, center.y - radius * 0.62f)
                    lineTo(center.x + wingSpread, center.y - radius * 0.62f)
                    close()
                }
                val downArrow = Path().apply {
                    moveTo(center.x, center.y + reach)
                    lineTo(center.x - wingSpread, center.y + radius * 0.62f)
                    lineTo(center.x + wingSpread, center.y + radius * 0.62f)
                    close()
                }
                drawPath(upArrow, cyanGlow)
                drawPath(downArrow, cyanGlow)
                drawPath(upArrow, cyanDeep, style = Stroke(width = radius * 0.06f))
                drawPath(downArrow, cyanDeep, style = Stroke(width = radius * 0.06f))
            }
        }
        com.example.model.SpecialKind.MAGIC_PEACH -> {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFFFFD84D).copy(alpha = 0.72f * alpha), Color.Transparent),
                    center = center,
                    radius = radius * (1.28f + 0.12f * pulse)
                ),
                radius = radius * (1.28f + 0.12f * pulse),
                center = center
            )
        }
        com.example.model.SpecialKind.NONE -> Unit
    }
}

private fun DrawScope.drawSpecialBadgeOverlay(
    special: com.example.model.SpecialKind,
    center: Offset,
    radius: Float,
    alpha: Float,
    pulse: Float
) {
    when (special) {
        com.example.model.SpecialKind.LIGHTNING_ROW,
        com.example.model.SpecialKind.LIGHTNING_COL -> {
            drawCircle(
                color = Color.White.copy(alpha = (0.72f + 0.18f * pulse) * alpha),
                radius = radius * 0.92f,
                center = center,
                style = Stroke(width = radius * 0.09f)
            )
        }
        com.example.model.SpecialKind.BOMB -> {
            val fuseCenter = Offset(center.x + radius * 0.52f, center.y - radius * 0.52f)
            drawCircle(Color(0xFF2B211E).copy(alpha = alpha), radius * 0.26f, fuseCenter)
            drawFourPointStar(fuseCenter, radius * (0.26f + 0.06f * pulse), Color(0xFFFFD166).copy(alpha = alpha))
        }
        com.example.model.SpecialKind.RAINBOW -> {
            drawFourPointStar(
                center = center,
                outerRadius = radius * (0.42f + 0.06f * pulse),
                color = Color.White.copy(alpha = 0.94f * alpha)
            )
        }
        com.example.model.SpecialKind.MAGIC_PEACH -> {
            drawFourPointStar(
                center = Offset(center.x, center.y - radius * 0.52f),
                outerRadius = radius * 0.30f,
                color = Color(0xFFFFD84D).copy(alpha = alpha)
            )
        }
        com.example.model.SpecialKind.NONE -> Unit
    }
}

private fun DrawScope.drawPeach(center: Offset, r: Float, alpha: Float) {
    val bodyBrush = Brush.radialGradient(
        colors = listOf(
            Color(0xFFFFD8B1).copy(alpha = alpha),
            Color(0xFFFF9A76).copy(alpha = alpha),
            Color(0xFFFF5E73).copy(alpha = alpha)
        ),
        center = Offset(center.x - r * 0.25f, center.y - r * 0.25f),
        radius = r * 1.4f
    )
    val path = Path().apply {
        moveTo(center.x, center.y - r * 0.56f)
        cubicTo(center.x + r * 0.74f, center.y - r * 0.96f, center.x + r * 1.08f, center.y + r * 0.16f, center.x, center.y + r * 0.94f)
        cubicTo(center.x - r * 1.08f, center.y + r * 0.16f, center.x - r * 0.74f, center.y - r * 0.96f, center.x, center.y - r * 0.56f)
        close()
    }
    drawPath(path, brush = bodyBrush)
    drawPath(path, Color(0xFFD94A5A).copy(alpha = 0.45f * alpha), style = Stroke(width = r * 0.06f))
    drawCircle(Color(0xFFFF4D6D).copy(alpha = 0.28f * alpha), r * 0.17f, Offset(center.x - r * 0.35f, center.y + r * 0.12f))
    drawCircle(Color(0xFFFF4D6D).copy(alpha = 0.28f * alpha), r * 0.17f, Offset(center.x + r * 0.35f, center.y + r * 0.12f))
    drawCircle(Color.White.copy(alpha = 0.55f * alpha), r * 0.16f, Offset(center.x - r * 0.32f, center.y - r * 0.28f))
    drawLeaf(Offset(center.x, center.y - r * 0.6f), r, alpha)
}

private fun DrawScope.drawStrawberry(center: Offset, r: Float, alpha: Float) {
    val path = Path().apply {
        moveTo(center.x, center.y + r * 0.95f)
        cubicTo(center.x + r * 1.05f, center.y + r * 0.32f, center.x + r * 0.92f, center.y - r * 0.65f, center.x, center.y - r * 0.58f)
        cubicTo(center.x - r * 0.92f, center.y - r * 0.65f, center.x - r * 1.05f, center.y + r * 0.32f, center.x, center.y + r * 0.95f)
        close()
    }
    drawPath(
        path,
        brush = Brush.radialGradient(
            listOf(Color(0xFFFF859D).copy(alpha = alpha), Color(0xFFFF3358).copy(alpha = alpha)),
            center = Offset(center.x - r * 0.25f, center.y - r * 0.2f),
            radius = r * 1.3f
        )
    )
    listOf(-0.32f to -0.14f, 0.3f to -0.14f, 0f to 0.08f, -0.24f to 0.3f, 0.24f to 0.3f, 0f to 0.56f).forEach { (dx, dy) ->
        drawCircle(Color(0xFFFFE885).copy(alpha = 0.95f * alpha), r * 0.06f, Offset(center.x + r * dx, center.y + r * dy))
    }
    val cap = Path().apply {
        moveTo(center.x - r * 0.52f, center.y - r * 0.52f)
        lineTo(center.x - r * 0.18f, center.y - r * 0.72f)
        lineTo(center.x, center.y - r * 0.94f)
        lineTo(center.x + r * 0.18f, center.y - r * 0.72f)
        lineTo(center.x + r * 0.52f, center.y - r * 0.52f)
        quadraticTo(center.x, center.y - r * 0.38f, center.x - r * 0.52f, center.y - r * 0.52f)
        close()
    }
    drawPath(cap, Color(0xFF38C98A).copy(alpha = alpha))
}

private fun DrawScope.drawApple(center: Offset, r: Float, alpha: Float, isGreen: Boolean) {
    val light = if (isGreen) Color(0xFFA7F3C0) else Color(0xFFFF7A8A)
    val dark = if (isGreen) Color(0xFF38B06B) else Color(0xFFD62839)
    val path = Path().apply {
        moveTo(center.x, center.y - r * 0.52f)
        cubicTo(center.x + r * 0.85f, center.y - r * 0.92f, center.x + r * 1.02f, center.y + r * 0.48f, center.x + r * 0.32f, center.y + r * 0.88f)
        quadraticTo(center.x, center.y + r * 0.76f, center.x - r * 0.32f, center.y + r * 0.88f)
        cubicTo(center.x - r * 1.02f, center.y + r * 0.48f, center.x - r * 0.85f, center.y - r * 0.92f, center.x, center.y - r * 0.52f)
        close()
    }
    drawPath(
        path,
        brush = Brush.radialGradient(
            listOf(light.copy(alpha = alpha), dark.copy(alpha = alpha)),
            center = Offset(center.x - r * 0.25f, center.y - r * 0.2f),
            radius = r * 1.35f
        )
    )
    drawLine(Color(0xFF7F4F24).copy(alpha = alpha), Offset(center.x, center.y - r * 0.5f), Offset(center.x + r * 0.08f, center.y - r * 0.9f), strokeWidth = r * 0.1f, cap = StrokeCap.Round)
    drawLeaf(Offset(center.x + r * 0.04f, center.y - r * 0.65f), r * 0.82f, alpha)
    drawCircle(Color.White.copy(alpha = 0.5f * alpha), r * 0.16f, Offset(center.x - r * 0.34f, center.y - r * 0.22f))
}

private fun DrawScope.drawOrange(center: Offset, r: Float, alpha: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFD066).copy(alpha = alpha), Color(0xFFFF8811).copy(alpha = alpha), Color(0xFFE05D00).copy(alpha = alpha)),
            center = Offset(center.x - r * 0.25f, center.y - r * 0.25f),
            radius = r * 1.25f
        ),
        radius = r * 0.88f,
        center = Offset(center.x, center.y + r * 0.06f)
    )
    drawCircle(Color.White.copy(alpha = 0.55f * alpha), r * 0.18f, Offset(center.x - r * 0.32f, center.y - r * 0.24f))
    drawLeaf(Offset(center.x, center.y - r * 0.78f), r * 0.88f, alpha)
}

private fun DrawScope.drawLemon(center: Offset, r: Float, alpha: Float) {
    val lemonPath = Path().apply {
        moveTo(center.x - r * 0.95f, center.y + r * 0.06f)
        cubicTo(center.x - r * 0.5f, center.y - r * 0.78f, center.x + r * 0.5f, center.y - r * 0.78f, center.x + r * 0.95f, center.y + r * 0.06f)
        cubicTo(center.x + r * 0.5f, center.y + r * 0.82f, center.x - r * 0.5f, center.y + r * 0.82f, center.x - r * 0.95f, center.y + r * 0.06f)
        close()
    }
    drawPath(
        lemonPath,
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFF5A8).copy(alpha = alpha), Color(0xFFFFD000).copy(alpha = alpha)),
            center = Offset(center.x - r * 0.2f, center.y - r * 0.2f),
            radius = r * 1.25f
        )
    )
    drawCircle(Color.White.copy(alpha = 0.55f * alpha), r * 0.15f, Offset(center.x - r * 0.28f, center.y - r * 0.2f))
    drawLeaf(Offset(center.x + r * 0.1f, center.y - r * 0.56f), r * 0.78f, alpha)
}

private fun DrawScope.drawWatermelon(center: Offset, r: Float, alpha: Float) {
    val rind = Path().apply {
        moveTo(center.x - r * 0.92f, center.y - r * 0.2f)
        quadraticTo(center.x, center.y + r * 1.12f, center.x + r * 0.92f, center.y - r * 0.2f)
        close()
    }
    drawPath(rind, Color(0xFF2EC4B6).copy(alpha = alpha))
    val pith = Path().apply {
        moveTo(center.x - r * 0.8f, center.y - r * 0.2f)
        quadraticTo(center.x, center.y + r * 0.92f, center.x + r * 0.8f, center.y - r * 0.2f)
        close()
    }
    drawPath(pith, Color(0xFFEDFFF6).copy(alpha = alpha))
    val flesh = Path().apply {
        moveTo(center.x - r * 0.7f, center.y - r * 0.2f)
        quadraticTo(center.x, center.y + r * 0.78f, center.x + r * 0.7f, center.y - r * 0.2f)
        close()
    }
    drawPath(flesh, Color(0xFFFF4D6D).copy(alpha = alpha))
    listOf(-0.28f to 0.04f, 0f to 0.22f, 0.28f to 0.04f).forEach { (dx, dy) ->
        drawCircle(Color(0xFF2E1A21).copy(alpha = alpha), r * 0.06f, Offset(center.x + r * dx, center.y + r * dy))
    }
}

private fun DrawScope.drawGrapes(center: Offset, r: Float, alpha: Float) {
    val orbR = r * 0.32f
    drawLine(Color(0xFF38C98A).copy(alpha = alpha), Offset(center.x, center.y - r * 0.5f), Offset(center.x + r * 0.14f, center.y - r * 0.92f), strokeWidth = r * 0.12f, cap = StrokeCap.Round)
    listOf(-0.34f to -0.22f, 0f to -0.26f, 0.34f to -0.22f, -0.2f to 0.18f, 0.2f to 0.18f, 0f to 0.56f).forEach { (dx, dy) ->
        val oc = Offset(center.x + r * dx, center.y + r * dy)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFFC29EFF).copy(alpha = alpha), Color(0xFF8338EC).copy(alpha = alpha), Color(0xFF5A189A).copy(alpha = alpha)),
                center = Offset(oc.x - orbR * 0.3f, oc.y - orbR * 0.3f),
                radius = orbR * 1.4f
            ),
            radius = orbR,
            center = oc
        )
    }
}

private fun DrawScope.drawBlueberry(center: Offset, r: Float, alpha: Float) {
    val c = Offset(center.x, center.y + r * 0.08f)
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFF8FB8FF).copy(alpha = alpha), Color(0xFF3A86FF).copy(alpha = alpha), Color(0xFF1D4ED8).copy(alpha = alpha)),
            center = Offset(c.x - r * 0.25f, c.y - r * 0.25f),
            radius = r * 1.2f
        ),
        radius = r * 0.84f,
        center = c
    )
    val crown = Path().apply {
        moveTo(c.x - r * 0.3f, c.y - r * 0.68f)
        lineTo(c.x - r * 0.12f, c.y - r * 0.92f)
        lineTo(c.x, c.y - r * 0.74f)
        lineTo(c.x + r * 0.12f, c.y - r * 0.92f)
        lineTo(c.x + r * 0.3f, c.y - r * 0.68f)
        close()
    }
    drawPath(crown, Color(0xFF1E40AF).copy(alpha = alpha))
    drawCircle(Color.White.copy(alpha = 0.55f * alpha), r * 0.17f, Offset(c.x - r * 0.3f, c.y - r * 0.28f))
}

private fun DrawScope.drawGoldenPineapple(center: Offset, r: Float, alpha: Float, pulse: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFE57F).copy(alpha = (0.58f + 0.24f * pulse) * alpha), Color.Transparent),
            center = center,
            radius = r * (1.28f + 0.12f * pulse)
        ),
        radius = r * (1.28f + 0.12f * pulse),
        center = center
    )
    val crown = Path().apply {
        moveTo(center.x - r * 0.42f, center.y - r * 0.44f)
        lineTo(center.x - r * 0.52f, center.y - r * 0.92f)
        lineTo(center.x - r * 0.18f, center.y - r * 0.66f)
        lineTo(center.x, center.y - r * 1.05f)
        lineTo(center.x + r * 0.18f, center.y - r * 0.66f)
        lineTo(center.x + r * 0.52f, center.y - r * 0.92f)
        lineTo(center.x + r * 0.42f, center.y - r * 0.44f)
        close()
    }
    drawPath(crown, Color(0xFF38C98A).copy(alpha = alpha))
    val bodyTopLeft = Offset(center.x - r * 0.62f, center.y - r * 0.46f)
    val bodySize = Size(r * 1.24f, r * 1.38f)
    drawRoundRect(
        brush = Brush.verticalGradient(listOf(Color(0xFFFFEC8B).copy(alpha = alpha), Color(0xFFFFB703).copy(alpha = alpha))),
        topLeft = bodyTopLeft,
        size = bodySize,
        cornerRadius = CornerRadius(r * 0.52f, r * 0.52f)
    )
    drawFourPointStar(Offset(center.x, center.y + r * 0.2f), r * 0.34f, Color.White.copy(alpha = 0.94f * alpha))
}

internal fun DrawScope.drawLeaf(anchor: Offset, r: Float, alpha: Float) {
    val leaf = Path().apply {
        moveTo(anchor.x, anchor.y)
        quadraticTo(anchor.x + r * 0.48f, anchor.y - r * 0.5f, anchor.x + r * 0.64f, anchor.y - r * 0.06f)
        quadraticTo(anchor.x + r * 0.28f, anchor.y + r * 0.1f, anchor.x, anchor.y)
        close()
    }
    drawPath(leaf, Color(0xFF38C98A).copy(alpha = alpha))
}

fun DrawScope.drawFourPointStar(center: Offset, outerRadius: Float, color: Color) {
    val inner = outerRadius * 0.36f
    val path = Path()
    for (i in 0 until 8) {
        val angle = i * PI / 4.0 - PI / 2.0
        val rad = if (i % 2 == 0) outerRadius else inner
        val x = center.x + (cos(angle) * rad).toFloat()
        val y = center.y + (sin(angle) * rad).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color = color)
}

fun DrawScope.drawObstacleOverlay(
    obstacle: ObstacleType,
    hp: Int,
    topLeft: Offset,
    cellSize: Float
) {
    val pad = cellSize * 0.055f
    val boxTopLeft = Offset(topLeft.x + pad, topLeft.y + pad)
    val boxSize = Size(cellSize - pad * 2, cellSize - pad * 2)
    val corner = CornerRadius(cellSize * 0.16f, cellSize * 0.16f)

    when (obstacle) {
        ObstacleType.NONE -> Unit
        ObstacleType.ICE -> {
            val iceAlpha = if (hp >= 2) 0.72f else 0.48f
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = iceAlpha), IceBlue.copy(alpha = iceAlpha))
                ),
                topLeft = boxTopLeft,
                size = boxSize,
                cornerRadius = corner
            )
            drawRoundRect(IceBorder.copy(alpha = 0.94f), boxTopLeft, boxSize, corner, style = Stroke(cellSize * (if (hp >= 2) 0.075f else 0.05f)))
            drawLine(Color.White.copy(alpha = 0.9f), Offset(topLeft.x + cellSize * 0.2f, topLeft.y + cellSize * 0.28f), Offset(topLeft.x + cellSize * 0.38f, topLeft.y + cellSize * 0.18f), strokeWidth = cellSize * 0.055f, cap = StrokeCap.Round)
            if (hp >= 2) {
                drawLine(Color.White.copy(alpha = 0.84f), Offset(topLeft.x + cellSize * 0.62f, topLeft.y + cellSize * 0.8f), Offset(topLeft.x + cellSize * 0.82f, topLeft.y + cellSize * 0.66f), strokeWidth = cellSize * 0.055f, cap = StrokeCap.Round)
            }
        }
        ObstacleType.VINES -> {
            val stroke = cellSize * 0.09f
            drawLine(VineGreen, Offset(topLeft.x + cellSize * 0.14f, topLeft.y + cellSize * 0.2f), Offset(topLeft.x + cellSize * 0.86f, topLeft.y + cellSize * 0.82f), strokeWidth = stroke, cap = StrokeCap.Round)
            drawLine(VineGreen, Offset(topLeft.x + cellSize * 0.86f, topLeft.y + cellSize * 0.22f), Offset(topLeft.x + cellSize * 0.14f, topLeft.y + cellSize * 0.8f), strokeWidth = stroke, cap = StrokeCap.Round)
            drawCircle(Color(0xFF39C91A), cellSize * 0.095f, Offset(topLeft.x + cellSize * 0.25f, topLeft.y + cellSize * 0.28f))
            drawCircle(Color(0xFF39C91A), cellSize * 0.095f, Offset(topLeft.x + cellSize * 0.76f, topLeft.y + cellSize * 0.74f))
        }
        ObstacleType.CRATE -> {
            // Deep 3D wooden crate with inner planks, top highlight, bottom bevel & 4 corner nails (like Screenshots 5 & 11)
            val s = boxSize.width
            val bx = boxTopLeft.x
            val by = boxTopLeft.y

            // Ground shadow
            drawRoundRect(
                color = Color(0x45261005),
                topLeft = Offset(bx, by + s * 0.08f),
                size = boxSize,
                cornerRadius = corner
            )
            // Outer wooden frame gradient
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFF28A3C), CrateWood, CrateWoodDark)
                ),
                topLeft = boxTopLeft,
                size = boxSize,
                cornerRadius = corner
            )
            // Inner recessed plank field
            val innerPad = s * 0.14f
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFC9601E), Color(0xFFB34E12))
                ),
                topLeft = Offset(bx + innerPad, by + innerPad),
                size = Size(s - innerPad * 2f, s - innerPad * 2f),
                cornerRadius = CornerRadius(s * 0.08f, s * 0.08f)
            )
            // Horizontal slat lines
            drawLine(
                color = CrateWoodDark,
                start = Offset(bx + innerPad, by + s * 0.39f),
                end = Offset(bx + s - innerPad, by + s * 0.39f),
                strokeWidth = s * 0.045f
            )
            drawLine(
                color = CrateWoodDark,
                start = Offset(bx + innerPad, by + s * 0.62f),
                end = Offset(bx + s - innerPad, by + s * 0.62f),
                strokeWidth = s * 0.045f
            )
            // Top & bottom border rails
            drawRoundRect(
                color = Color(0xFFF79D4D),
                topLeft = Offset(bx + s * 0.04f, by + s * 0.03f),
                size = Size(s - s * 0.08f, s * 0.15f),
                cornerRadius = CornerRadius(s * 0.06f, s * 0.06f)
            )
            drawRoundRect(
                color = CrateWoodDark,
                topLeft = boxTopLeft,
                size = boxSize,
                cornerRadius = corner,
                style = Stroke(width = s * 0.055f)
            )
            // 4 brass nails in corners
            val nailOffsets = listOf(
                0.10f to 0.10f, 0.90f to 0.10f,
                0.10f to 0.90f, 0.90f to 0.90f
            )
            nailOffsets.forEach { (nx, ny) ->
                val nc = Offset(bx + s * nx, by + s * ny)
                drawCircle(CrateWoodDark, s * 0.045f, nc)
                drawCircle(Color(0xFFFFD8A8), s * 0.025f, nc)
            }
        }
    }
}

@Composable
fun PeachBlossomGoalIcon(
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height * 0.56f
        val r = this.size.minDimension * 0.34f
        drawCircle(
            color = Color(0xFF2E160B).copy(alpha = 0.25f),
            radius = r * 1.05f,
            center = Offset(cx, cy + r * 0.12f)
        )
        // Green leaves underneath blossom
        val leafL = Path().apply {
            moveTo(cx - r * 0.2f, cy + r * 0.4f)
            quadraticTo(cx - r * 1.1f, cy + r * 0.2f, cx - r * 0.9f, cy + r * 0.85f)
            close()
        }
        val leafR = Path().apply {
            moveTo(cx + r * 0.2f, cy + r * 0.4f)
            quadraticTo(cx + r * 1.1f, cy + r * 0.2f, cx + r * 0.9f, cy + r * 0.85f)
            close()
        }
        drawPath(leafL, Color(0xFF33B81B))
        drawPath(leafR, Color(0xFF289912))

        // Layered rose/peach blossom petals
        val outerColor = Brush.radialGradient(
            listOf(Color(0xFFFFC2D9), Color(0xFFFF6699), Color(0xFFD62B66)),
            center = Offset(cx - r * 0.2f, cy - r * 0.25f),
            radius = r * 1.4f
        )
        drawCircle(outerColor, r * 0.95f, Offset(cx, cy))
        drawCircle(
            color = Color(0xFFFFD9E8),
            radius = r * 0.65f,
            center = Offset(cx, cy - r * 0.06f),
            style = Stroke(width = r * 0.12f)
        )
        drawCircle(
            color = Color(0xFFFF7AA8),
            radius = r * 0.40f,
            center = Offset(cx, cy - r * 0.10f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.72f),
            radius = r * 0.14f,
            center = Offset(cx - r * 0.28f, cy - r * 0.32f)
        )
    }
}

