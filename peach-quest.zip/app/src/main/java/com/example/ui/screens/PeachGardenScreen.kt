package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.levels.OrchardCatalog
import com.example.model.AppSettings
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.PlayerProgress
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachCard
import com.example.ui.components.drawFruitShape
import com.example.ui.theme.BerryInk
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.FreshMint
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgTop
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun PeachGardenScreen(
    progress: PlayerProgress,
    settings: AppSettings,
    graphicsQuality: GraphicsQuality,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val completedCount = progress.completedCount

    val sway = if (settings.animationsEnabled && graphicsQuality != GraphicsQuality.LOW_RAM) {
        val inf = rememberInfiniteTransition(label = "garden_sway")
        val v by inf.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(4200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "sway"
        )
        v
    } else 0f

    OrchardBackdrop(
        topColor = com.example.ui.theme.SkyDeep,
        bottomColor = com.example.ui.theme.MeadowDeepGreen,
        graphicsQuality = graphicsQuality,
        animationsEnabled = settings.animationsEnabled
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 600.dp)
                .align(Alignment.Center)
        ) {
            com.example.ui.components.GameStripedBanner {
                com.example.ui.components.AquaRoundIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    onClick = onBack,
                    size = 46.dp,
                    testTag = "garden_back"
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Your Peach Garden",
                        style = MaterialTheme.typography.titleLarge,
                        color = com.example.ui.theme.CreamParchmentLight,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                    )
                    Text(
                        text = "$completedCount of 30 levels completed",
                        style = MaterialTheme.typography.labelMedium,
                        color = com.example.ui.theme.CreamParchment
                    )
                }
            }

            Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {

            PeachCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                cornerRadius = 26.dp
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("peach_garden_canvas")
                ) {
                    drawRect(
                        brush = Brush.verticalGradient(listOf(Color(0xFFCDEEFF), Color(0xFFFFF4DC))),
                        size = Size(size.width, size.height * 0.62f)
                    )
                    drawRect(
                        brush = Brush.verticalGradient(listOf(Color(0xFF9AE09F), Color(0xFF38C98A))),
                        topLeft = Offset(0f, size.height * 0.56f),
                        size = Size(size.width, size.height * 0.44f)
                    )

                    if (completedCount >= 15) {
                        val path = Path().apply {
                            moveTo(size.width * 0.42f, size.height)
                            lineTo(size.width * 0.58f, size.height)
                            lineTo(size.width * 0.52f, size.height * 0.56f)
                            lineTo(size.width * 0.48f, size.height * 0.56f)
                            close()
                        }
                        drawPath(path, Color(0xFFFFE0A3))
                    }

                    // Welcome Gate
                    drawRoundRect(Color(0xFFC47F45), Offset(size.width * 0.1f, size.height * 0.58f), Size(size.width * 0.03f, size.height * 0.24f), CornerRadius(6f, 6f))
                    drawRoundRect(Color(0xFFC47F45), Offset(size.width * 0.22f, size.height * 0.58f), Size(size.width * 0.03f, size.height * 0.24f), CornerRadius(6f, 6f))
                    drawRoundRect(Color(0xFFFF7B54), Offset(size.width * 0.08f, size.height * 0.55f), Size(size.width * 0.19f, size.height * 0.05f), CornerRadius(8f, 8f))

                    if (completedCount >= 5) {
                        listOf(0.26f, 0.78f).forEachIndexed { idx, xPos ->
                            val bob = sin((sway * 2 * PI + idx).toDouble()).toFloat() * 4f
                            drawRoundRect(Color(0xFF8D5B3A), Offset(size.width * xPos - 10f, size.height * 0.45f), Size(20f, size.height * 0.25f), CornerRadius(6f, 6f))
                            drawCircle(Color(0xFF38C98A), size.minDimension * 0.17f, Offset(size.width * xPos + bob, size.height * 0.4f))
                            drawCircle(Color(0xFFFFB5A7), size.minDimension * 0.12f, Offset(size.width * xPos - 14f + bob, size.height * 0.36f))
                            drawFruitShape(FruitType.PEACH, Offset(size.width * xPos + 14f + bob, size.height * 0.42f), 12f)
                        }
                    }

                    if (completedCount >= 10) {
                        listOf(0.16f, 0.34f, 0.66f, 0.85f).forEachIndexed { i, fx ->
                            val fy = size.height * (0.78f + (i % 2) * 0.08f)
                            drawCircle(Color(0xFFFF4D6D), 11f, Offset(size.width * fx, fy))
                            drawCircle(Color(0xFFFFE66D), 5f, Offset(size.width * fx, fy))
                            if (i % 2 == 0) {
                                drawFruitShape(FruitType.STRAWBERRY, Offset(size.width * fx + 20f, fy + 6f), 11f)
                            }
                        }
                    }

                    if (completedCount >= 20) {
                        val bx = size.width * (0.35f + 0.3f * sin((sway * 2 * PI).toDouble()).toFloat())
                        val by = size.height * 0.24f + sin((sway * 4 * PI).toDouble()).toFloat() * 10f
                        drawCircle(Color(0xFFFFE66D), 8f, Offset(bx - 6f, by))
                        drawCircle(Color(0xFFFF7B54), 8f, Offset(bx + 6f, by))
                    }

                    if (completedCount >= 25) {
                        drawCircle(Color(0xFFE3F4FF), 26f, Offset(size.width * 0.5f, size.height * 0.68f))
                        drawCircle(GoldenStar, 10f, Offset(size.width * 0.5f, size.height * 0.66f))
                    }

                    if (completedCount >= 30) {
                        drawFruitShape(FruitType.GOLDEN_PINEAPPLE, Offset(size.width * 0.5f, size.height * 0.35f), 22f, pulse = sway)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(OrchardCatalog.gardenSections) { section ->
                    val unlocked = completedCount >= section.requiredCompletedLevels
                    PeachCard(
                        modifier = Modifier.fillMaxWidth(),
                        backgroundColor = if (unlocked) com.example.ui.theme.CreamParchment else Color(0xFFE7D7C2)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(if (unlocked) Color(0xFFDDF9EC) else Color(0xFFE4D8D0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (unlocked) Icons.Rounded.CheckCircle else Icons.Rounded.Lock,
                                    contentDescription = if (unlocked) "Unlocked" else "Locked",
                                    tint = if (unlocked) FreshMint else CocoaMuted
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = section.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (unlocked) BerryInk else CocoaMuted
                                )
                                Text(
                                    text = section.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CocoaMuted
                                )
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(12.dp)) }
            }
            }
        }
    }
}
