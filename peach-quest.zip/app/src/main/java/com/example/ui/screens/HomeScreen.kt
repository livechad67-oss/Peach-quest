package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.levels.LevelRepository
import com.example.model.AppSettings
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.PlayerProgress
import com.example.ui.components.AquaRoundIconButton
import com.example.ui.components.GlossyGreenPlayButton
import com.example.ui.components.OrchardBackdrop
import com.example.ui.components.PeachCard
import com.example.ui.components.PeachMascotCharacter
import com.example.ui.components.drawFruitShape
import com.example.ui.theme.BerryInk
import com.example.ui.theme.CocoaMuted
import com.example.ui.theme.CreamParchment
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.MeadowDeepGreen
import com.example.ui.theme.PeachBannerShadow
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.SkyDeep
import com.example.ui.theme.SoftPeach
import com.example.ui.theme.WaterSurfaceDark
import com.example.ui.theme.WaterSurfaceLight
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    progress: PlayerProgress,
    settings: AppSettings,
    graphicsQuality: GraphicsQuality,
    onPlayClick: () -> Unit,
    onLevelMapClick: () -> Unit,
    onProfileClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenOwnerConsole: () -> Unit = {}
) {
    val pulseScale = if (settings.animationsEnabled) {
        val inf = rememberInfiniteTransition(label = "peach_play_pulse")
        val v by inf.animateFloat(
            initialValue = 1f,
            targetValue = 1.038f,
            animationSpec = infiniteRepeatable(
                animation = tween(1450, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "play_scale"
        )
        v
    } else 1f

    val fountainShimmer = if (settings.animationsEnabled && graphicsQuality != GraphicsQuality.LOW_RAM) {
        val inf = rememberInfiniteTransition(label = "fountain_stream")
        val f by inf.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(2200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shimmer"
        )
        f
    } else 0.5f

    val activeLevel = progress.activeSnapshot?.levelNumber ?: progress.highestUnlockedLevel
    val activeDef = LevelRepository.getLevel(activeLevel)
    val displayUser = progress.playerUsername.ifBlank { "Friend" }

    OrchardBackdrop(
        topColor = SkyDeep,
        bottomColor = MeadowDeepGreen,
        graphicsQuality = graphicsQuality,
        animationsEnabled = settings.animationsEnabled,
        showFloatingFruits = false,
        showCornerFlowers = false
    ) {
        // Courtyard stone patio, Peach Fountain, lush shrubs & resting fruits (Screenshot 6 style)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Distant lush garden trees framing left & right
            drawCircle(Color(0xFF287424), size.minDimension * 0.25f, Offset(w * 0.02f, h * 0.34f))
            drawCircle(Color(0xFF42A12A), size.minDimension * 0.20f, Offset(w * 0.12f, h * 0.42f))
            drawCircle(Color(0xFF287424), size.minDimension * 0.27f, Offset(w * 0.98f, h * 0.36f))
            drawCircle(Color(0xFF4FB330), size.minDimension * 0.21f, Offset(w * 0.87f, h * 0.44f))

            // Sunlit garden courtyard perspective stone patio
            val patio = Path().apply {
                moveTo(w * 0.24f, h * 0.55f)
                lineTo(w * 0.76f, h * 0.55f)
                lineTo(w * 1.15f, h)
                lineTo(-w * 0.15f, h)
                close()
            }
            drawPath(
                patio,
                Brush.verticalGradient(
                    listOf(Color(0xFFF6E7B9), Color(0xFFDDC88C), Color(0xFFA9B774)),
                    startY = h * 0.55f,
                    endY = h
                )
            )
            // Subtle perspective tile lines on patio
            val tileColor = Color(0xFF8C7D53).copy(alpha = 0.24f)
            listOf(0.62f, 0.70f, 0.79f, 0.90f).forEach { rowY ->
                drawLine(tileColor, Offset(w * 0.05f, h * rowY), Offset(w * 0.95f, h * rowY), strokeWidth = 2.5f)
            }
            listOf(-0.1f, 0.2f, 0.5f, 0.8f, 1.1f).forEach { colBot ->
                drawLine(tileColor, Offset(w * (0.38f + colBot * 0.24f), h * 0.55f), Offset(w * colBot, h), strokeWidth = 2.5f)
            }

            // Marble Peach Fountain on right-midground (like Screenshot 6 fountain)
            val fx = w * 0.76f
            val fy = h * 0.54f
            drawOval(Color(0xFFDFD6BD), Offset(fx - 76f, fy - 10f), Size(152f, 44f))
            drawOval(
                Brush.horizontalGradient(listOf(WaterSurfaceDark, WaterSurfaceLight)),
                Offset(fx - 64f, fy - 4f),
                Size(128f, 30f)
            )
            // Peach sculpture pedestal
            drawRoundRect(Color(0xFFEEE6CE), Offset(fx - 14f, fy - 42f), Size(28f, 44f), androidx.compose.ui.geometry.CornerRadius(10f, 10f))
            drawCircle(PeachOrange, 16f, Offset(fx, fy - 48f))
            // Arcing water stream into pool
            val waterArc = Path().apply {
                moveTo(fx - 8f, fy - 52f)
                quadraticTo(fx - 38f, fy - 70f, fx - 44f, fy + 8f)
            }
            drawPath(
                waterArc,
                WaterSurfaceLight.copy(alpha = 0.82f + 0.14f * sin((fountainShimmer * 2 * PI).toDouble()).toFloat()),
                style = Stroke(width = 7f, cap = StrokeCap.Round)
            )

            // Resting 3D fruits on courtyard floor (like Screenshot 6)
            drawFruitShape(FruitType.BLUEBERRY, Offset(w * 0.30f, h * 0.75f), 17f)
            drawFruitShape(FruitType.GREEN_APPLE, Offset(w * 0.24f, h * 0.76f), 20f)
            drawFruitShape(FruitType.GRAPES, Offset(w * 0.57f, h * 0.75f), 22f)
            drawFruitShape(FruitType.BANANA, Offset(w * 0.65f, h * 0.77f), 21f)
            drawFruitShape(FruitType.STRAWBERRY, Offset(w * 0.39f, h * 0.84f), 22f)
            drawFruitShape(FruitType.PEACH, Offset(w * 0.48f, h * 0.87f), 25f)

            // Deep sapphire-blue & blossom-pink flowers framing lower left and right borders
            val blueFlowerCenters = listOf(0.05f to 0.64f, 0.08f to 0.72f, 0.04f to 0.80f, 0.94f to 0.62f, 0.91f to 0.71f, 0.95f to 0.79f)
            blueFlowerCenters.forEachIndexed { idx, (bx, by) ->
                val c = Offset(w * bx, h * by)
                val petalC = if (idx % 2 == 0) Color(0xFF1F7FE6) else Color(0xFF3DA2FF)
                for (p in 0 until 5) {
                    val ang = p * (2.0 * PI / 5.0)
                    drawCircle(petalC, 15f, Offset(c.x + (cosAngle(ang) * 14f), c.y + (sinAngle(ang) * 14f)))
                }
                drawCircle(Color(0xFFFFD84D), 6f, c)
            }

            // Lush deep emerald leaves along very bottom frame
            drawOval(Color(0xFF1D6B18), Offset(-24f, h * 0.90f), Size(w * 0.34f, h * 0.14f))
            drawOval(Color(0xFF359E22), Offset(w * 0.16f, h * 0.93f), Size(w * 0.28f, h * 0.12f))
            drawOval(Color(0xFF1D6B18), Offset(w * 0.70f, h * 0.90f), Size(w * 0.36f, h * 0.14f))
            drawOval(Color(0xFF3EA827), Offset(w * 0.56f, h * 0.94f), Size(w * 0.26f, h * 0.11f))
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 560.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            // Top bar: Star Badge & Profile Pill (beveled Cream Parchment)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.dp, CreamParchmentBevel),
                    shadowElevation = 5.dp,
                    modifier = Modifier.testTag("stars_badge")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = "Stars Earned",
                            tint = GoldenStar,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${progress.totalStars}",
                            style = MaterialTheme.typography.titleMedium,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = CreamParchment,
                    border = BorderStroke(2.dp, CreamParchmentBevel),
                    shadowElevation = 5.dp,
                    onClick = onProfileClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("profile_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AccountCircle,
                            contentDescription = "Profile",
                            tint = PeachOrangeDeep,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = displayUser,
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.35f))

            // Official Peach Quest Hero Logo
            Image(
                painter = painterResource(id = R.drawable.peach_quest_logo),
                contentDescription = "Peach Quest Logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(196.dp)
                    .testTag("home_logo")
            )

            Spacer(modifier = Modifier.weight(0.25f))

            // Peach Mascot peeking behind Glossy Green PLAY Pill Button (Screenshot 6 silhouette!)
            Box(
                contentAlignment = Alignment.TopCenter,
                modifier = Modifier.fillMaxWidth()
            ) {
                PeachMascotCharacter(
                    size = 84.dp,
                    animationsEnabled = settings.animationsEnabled,
                    modifier = Modifier
                        .offset(x = (-32).dp, y = (-46).dp)
                        .testTag("home_mascot")
                )

                GlossyGreenPlayButton(
                    onClick = onPlayClick,
                    minHeight = 68.dp,
                    testTag = "play_button",
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .graphicsLayer {
                            scaleX = pulseScale
                            scaleY = pulseScale
                        }
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = if (progress.activeSnapshot != null) "RESUME" else "PLAY",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Level $activeLevel • ${activeDef.title}",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.94f),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Beveled Cream Parchment Garden Map Shortcut
            PeachCard(
                onClick = onLevelMapClick,
                borderColor = PeachBannerShadow.copy(alpha = 0.45f),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("level_map_button")
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Map,
                                contentDescription = null,
                                tint = activeDef.chapter.accentColor,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "World ${activeDef.chapter.number}: ${activeDef.chapter.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = BerryInk,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Level $activeLevel • Tap for Garden Map",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CocoaMuted,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(99.dp),
                            color = PeachOrangeDeep
                        ) {
                            Text(
                                text = "${progress.completedCount}/30",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (progress.completedCount / 30f).coerceIn(0.03f, 1f) },
                        color = PeachOrange,
                        trackColor = SoftPeach,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(99.dp))
                    )
                }
            }

            Spacer(modifier = Modifier.weight(0.9f))
            Spacer(modifier = Modifier.height(12.dp))

            // From CLASTAD Signature centered at bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = CreamParchment.copy(alpha = 0.92f),
                    border = BorderStroke(1.5.dp, CreamParchmentBevel),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .combinedClickable(
                            onClick = {},
                            onLongClick = onOpenOwnerConsole
                        )
                        .testTag("clastad_signature")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.clastad_logo),
                            contentDescription = "CLASTAD Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(id = R.string.developer_credit),
                            style = MaterialTheme.typography.labelLarge,
                            color = BerryInk,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        // Bottom-left pinned Aqua Settings Gear (always immediately visible like Screenshot 6/7)
        AquaRoundIconButton(
            icon = Icons.Rounded.Settings,
            contentDescription = "Settings",
            onClick = onSettingsClick,
            size = 54.dp,
            testTag = "settings_button",
            modifier = Modifier
                .align(Alignment.BottomStart)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(start = 16.dp, bottom = 14.dp)
        )
    }
}

private fun cosAngle(radians: Double): Float = kotlin.math.cos(radians).toFloat()
private fun sinAngle(radians: Double): Float = kotlin.math.sin(radians).toFloat()
