package com.example.ui

import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.analytics.AnalyticsTracker
import com.example.audio.HapticCue
import com.example.audio.HapticManager
import com.example.audio.MusicMood
import com.example.audio.SoundCue
import com.example.audio.SoundManager
import com.example.auth.GoogleAuthHelper
import com.example.auth.GoogleSignInOutcome
import com.example.data.AdminDashboardRepository
import com.example.game.BoardState
import com.example.game.MatchEngine
import com.example.game.MoveHint
import com.example.game.StepResolution
import com.example.levels.LevelRepository
import com.example.levels.OrchardCatalog
import com.example.model.AdminMetricSnapshotDoc
import com.example.model.AppSettings
import com.example.model.BoosterType
import com.example.model.DeviceTelemetrySummary
import com.example.model.FruitSkin
import com.example.model.FruitType
import com.example.model.GameNotification
import com.example.model.GraphicsQuality
import com.example.model.LevelDefinition
import com.example.model.LevelObjective
import com.example.model.LevelResult
import com.example.model.ObjectiveKind
import com.example.model.ObstacleType
import com.example.model.PlayerProgress
import com.example.model.SavedBoardSnapshot
import com.example.model.SpecialKind
import com.example.model.UsernameValidation
import com.example.model.UsernameValidator
import com.example.storage.LocalStorageRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

enum class LegalDocType(val title: String) {
    PRIVACY("Privacy Information"),
    TERMS("Terms of Use"),
    CONDUCT("Player Conduct Policy"),
    CREDITS("Credits & Licences")
}

sealed interface AppScreen {
    data object Loading : AppScreen
    data object UsernameOnboarding : AppScreen
    data object GardenReveal : AppScreen
    data object Home : AppScreen
    data object LevelMap : AppScreen
    data object Game : AppScreen
    data object PeachGarden : AppScreen
    data object FruitVault : AppScreen
    data object Settings : AppScreen
    data object OwnerDashboard : AppScreen
    data class LegalDocument(val docType: LegalDocType, val returnTo: AppScreen) : AppScreen
}

enum class GamePhase {
    IDLE,
    ANIMATING_SWAP,
    REVERSING_SWAP,
    CLEARING,
    FALLING,
    SHUFFLING,
    PAUSED,
    VICTORY,
    FAILED
}

data class FloatingCallout(
    val id: Long,
    val text: String,
    val row: Int,
    val col: Int,
    val isGolden: Boolean = false
)

data class MechanicTip(
    val key: String,
    val title: String,
    val description: String,
    val boosterType: BoosterType
)

data class OwnerAuthState(
    val userId: String? = null,
    val displayName: String? = null,
    val email: String? = null,
    val emailVerified: Boolean = false,
    val isAllowlistedAdmin: Boolean = false,
    val isBusy: Boolean = false,
    val firestoreVerified: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null,
    val remoteMetrics: List<AdminMetricSnapshotDoc> = emptyList()
)

data class GameUiState(
    val level: LevelDefinition = LevelRepository.getLevel(1),
    val board: BoardState = BoardState(6, 6, emptyList()),
    val movesRemaining: Int = 18,
    val score: Int = 0,
    val collectedFruits: Map<FruitType, Int> = emptyMap(),
    val clearedObstacles: Map<ObstacleType, Int> = emptyMap(),
    val goldenWavesTriggered: Int = 0,
    val selectedCell: Pair<Int, Int>? = null,
    val waterChannelCells: Set<Pair<Int, Int>> = emptySet(),
    val activeBooster: BoosterType? = null,
    val phase: GamePhase = GamePhase.IDLE,
    val activeClearIndices: Set<Int> = emptySet(),
    val activeWaveIndices: Set<Int> = emptySet(),
    val activeSpecialKinds: Set<SpecialKind> = emptySet(),
    val fallDistances: Map<Long, Int> = emptyMap(),
    val swappingPair: Pair<Pair<Int, Int>, Pair<Int, Int>>? = null,
    val comboCount: Int = 0,
    val maxComboAchieved: Int = 1,
    val callouts: List<FloatingCallout> = emptyList(),
    val hint: MoveHint? = null,
    val statusBanner: String? = null,
    val mechanicTip: MechanicTip? = null,
    val earnedStars: Int = 0,
    val tutorialActive: Boolean = false,
    val tutorialHint: MoveHint? = null,
    val tutorialCelebration: String? = null
)

data class AppUiState(
    val currentScreen: AppScreen = AppScreen.Loading,
    val loadingProgress: Float = 0.08f,
    val loadingStatus: String = "Opening the peach garden...",
    val loadingError: String? = null,
    val isLowRamDevice: Boolean = false,
    val onboardingError: String? = null,
    val ownerAuth: OwnerAuthState = OwnerAuthState(),
    val analyticsSdkConnected: Boolean = false,
    val deviceTelemetry: DeviceTelemetrySummary = DeviceTelemetrySummary(),
    val progress: PlayerProgress = PlayerProgress(),
    val settings: AppSettings = AppSettings(),
    val notifications: List<GameNotification> = emptyList(),
    val rewardBannerMessage: String? = null,
    val game: GameUiState = GameUiState()
) {
    val unreadNotificationsCount: Int get() = notifications.count { it.isUnread }
}

class PeachQuestViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = LocalStorageRepository(application)
    private val adminRepo = AdminDashboardRepository(application)
    val analyticsTracker = AnalyticsTracker(application)
    private val matchEngine = MatchEngine()
    val soundManager = SoundManager(application)
    val hapticManager = HapticManager(application)

    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var activeMoveJob: Job? = null
    private var hintIdleJob: Job? = null
    private var gardenRevealJob: Job? = null
    private var ownerMetricsJob: Job? = null
    private var loadingJob: Job? = null
    private var calloutIdCounter = 1L
    private var notificationIdCounter = 1L
    private var foregroundStartMs: Long = System.currentTimeMillis()
    private var lastFpsSaveMs: Long = 0L

    init {
        GoogleAuthHelper.ensureFirebaseInitialized(application)
        observeOwnerFirebaseAuth()
        initializeApp()
    }

    private fun observeOwnerFirebaseAuth() {
        viewModelScope.launch {
            GoogleAuthHelper.authStateFlow().collectLatest { firebaseUser ->
                handleOwnerAuthChanged(firebaseUser)
            }
        }
    }

    private fun handleOwnerAuthChanged(user: FirebaseUser?) {
        ownerMetricsJob?.cancel()
        if (user == null) {
            _uiState.update { it.copy(ownerAuth = OwnerAuthState()) }
            return
        }

        val verified = user.isEmailVerified
        val allowlisted = adminRepo.isAllowlistedAdmin(user.email, verified)

        _uiState.update {
            it.copy(
                ownerAuth = it.ownerAuth.copy(
                    userId = user.uid,
                    displayName = user.displayName,
                    email = user.email,
                    emailVerified = verified,
                    isAllowlistedAdmin = allowlisted,
                    isBusy = false,
                    errorMessage = if (!allowlisted) {
                        "This Google account (${user.email ?: "unknown"}) is not authorized for the CLASTAD Owner Console."
                    } else null
                )
            )
        }

        if (allowlisted) {
            ownerMetricsJob = viewModelScope.launch {
                runCatching {
                    adminRepo.observeAdminMetrics().collectLatest { docs ->
                        _uiState.update { state ->
                            state.copy(
                                ownerAuth = state.ownerAuth.copy(
                                    remoteMetrics = docs,
                                    firestoreVerified = true
                                )
                            )
                        }
                    }
                }.onFailure { err ->
                    _uiState.update { state ->
                        state.copy(
                            ownerAuth = state.ownerAuth.copy(
                                firestoreVerified = false,
                                errorMessage = err.localizedMessage ?: "Firestore owner metrics access denied."
                            )
                        )
                    }
                }
            }
        }
    }

    fun initializeApp() {
        loadingJob?.cancel()
        loadingJob = viewModelScope.launch {
            try {
                _uiState.update {
                    it.copy(
                        currentScreen = AppScreen.Loading,
                        loadingProgress = 0.08f,
                        loadingStatus = "Opening the peach garden...",
                        loadingError = null
                    )
                }

                val isLowRam = withContext(Dispatchers.Default) { detectLowRamDevice() }
                val (loadedProgress, loadedSettings, loadedTelemetry) = withContext(Dispatchers.IO) {
                    Triple(
                        storage.loadProgress(),
                        storage.loadSettings(),
                        storage.loadDeviceTelemetry()
                    )
                }

                val now = System.currentTimeMillis()
                val isFirstOpen = loadedTelemetry.firstOpenTimestampMs == 0L
                val updatedTelemetry = loadedTelemetry.copy(
                    firstOpenTimestampMs = if (isFirstOpen) now else loadedTelemetry.firstOpenTimestampMs,
                    sessionCount = loadedTelemetry.sessionCount + 1
                )
                foregroundStartMs = now
                withContext(Dispatchers.IO) {
                    storage.saveDeviceTelemetry(updatedTelemetry)
                }

                analyticsTracker.updateConsent(loadedSettings.analyticsConsent)
                analyticsTracker.logAppSessionStart(isFirstOpen)

                soundManager.updateSettings(loadedSettings)
                hapticManager.enabled = loadedSettings.hapticEnabled
                soundManager.setMusicMood(MusicMood.LOBBY)

                val initialNotifications = buildInitialNotifications(loadedProgress)
                _uiState.update {
                    it.copy(
                        isLowRamDevice = isLowRam,
                        progress = loadedProgress,
                        settings = loadedSettings,
                        deviceTelemetry = updatedTelemetry,
                        analyticsSdkConnected = analyticsTracker.isSdkConnected(),
                        notifications = initialNotifications
                    )
                }

                // Smooth 2.0-second loading entrance into either Welcome Onboarding or Home
                val totalMs = if (!loadedSettings.animationsEnabled) 600L else 2000L
                val stepMs = 80L
                var elapsed = 0L
                while (elapsed < totalMs) {
                    delay(stepMs)
                    elapsed += stepMs
                    val frac = (elapsed.toFloat() / totalMs.toFloat()).coerceIn(0.08f, 1f)
                    val status = when {
                        frac < 0.38f -> "Watering the sunny orchard..."
                        frac < 0.72f -> "Waking the butterflies..."
                        else -> "Welcome to Peach Quest!"
                    }
                    _uiState.update {
                        it.copy(
                            loadingProgress = frac,
                            loadingStatus = status
                        )
                    }
                }
                finishLoadingTransition()
            } catch (t: Throwable) {
                recordLocalNonFatal()
                _uiState.update {
                    it.copy(
                        loadingError = "Could not open the garden (${t.localizedMessage ?: "unknown error"})."
                    )
                }
            }
        }
    }

    private fun finishLoadingTransition() {
        val state = _uiState.value
        val nextScreen = if (state.progress.playerUsername.isNotBlank() && state.progress.legalAccepted) {
            AppScreen.Home
        } else {
            AppScreen.UsernameOnboarding
        }
        _uiState.update {
            it.copy(
                loadingProgress = 1f,
                loadingStatus = "Ready!",
                currentScreen = nextScreen
            )
        }
    }

    fun completeUsernameOnboarding(
        rawUsername: String,
        legalAccepted: Boolean,
        analyticsConsent: Boolean
    ): UsernameValidation {
        soundManager.notifyUserInteraction()
        soundManager.playSfx(SoundCue.BUTTON_TAP)
        hapticManager.trigger(HapticCue.TAP)

        val validation = UsernameValidator.validate(rawUsername)
        if (validation is UsernameValidation.Invalid) {
            hapticManager.trigger(HapticCue.ERROR)
            _uiState.update { it.copy(onboardingError = validation.reason) }
            return validation
        }
        if (!legalAccepted) {
            hapticManager.trigger(HapticCue.ERROR)
            _uiState.update {
                it.copy(
                    onboardingError = "Please accept the Privacy Information & Terms of Use to enter the garden."
                )
            }
            return UsernameValidation.Invalid("Legal acceptance required.")
        }

        val normalizedName = (validation as UsernameValidation.Valid).normalized
        val updatedProgress = _uiState.value.progress.copy(
            playerUsername = normalizedName,
            legalAccepted = true
        )
        val updatedSettings = _uiState.value.settings.copy(analyticsConsent = analyticsConsent)
        analyticsTracker.updateConsent(analyticsConsent)
        if (analyticsConsent) {
            analyticsTracker.logAppSessionStart(_uiState.value.deviceTelemetry.sessionCount <= 1)
        }
        soundManager.playSfx(SoundCue.GARDEN_GATE_OPEN)
        hapticManager.trigger(HapticCue.REWARD)

        persistProgress(updatedProgress)
        viewModelScope.launch(Dispatchers.IO) {
            storage.saveSettings(updatedSettings)
        }

        _uiState.update {
            it.copy(
                progress = updatedProgress,
                settings = updatedSettings,
                onboardingError = null,
                currentScreen = AppScreen.GardenReveal
            )
        }
        startGardenRevealTimer()
        return validation
    }

    private fun startGardenRevealTimer() {
        gardenRevealJob?.cancel()
        gardenRevealJob = viewModelScope.launch {
            val waitMs = if (_uiState.value.settings.animationsEnabled) 3200L else 950L
            delay(waitMs)
            finishGardenReveal()
        }
    }

    fun finishGardenReveal() {
        gardenRevealJob?.cancel()
        if (_uiState.value.currentScreen == AppScreen.GardenReveal) {
            _uiState.update { it.copy(currentScreen = AppScreen.Home) }
        }
    }

    fun clearOnboardingError() {
        _uiState.update { it.copy(onboardingError = null) }
    }

    fun updateDisplayUsername(rawUsername: String): UsernameValidation {
        soundManager.notifyUserInteraction()
        val validation = UsernameValidator.validate(rawUsername)
        if (validation is UsernameValidation.Valid) {
            val updated = _uiState.value.progress.copy(playerUsername = validation.normalized)
            persistProgress(updated)
            _uiState.update { it.copy(progress = updated) }
            soundManager.playSfx(SoundCue.TOGGLE_ON)
            hapticManager.trigger(HapticCue.TAP)
        } else {
            soundManager.playSfx(SoundCue.INVALID_SWAP)
            hapticManager.trigger(HapticCue.ERROR)
        }
        return validation
    }

    fun updateAnalyticsConsent(enabled: Boolean) {
        soundManager.notifyUserInteraction()
        analyticsTracker.updateConsent(enabled)
        updateSettings(
            playToggleCue = if (enabled) SoundCue.TOGGLE_ON else SoundCue.TOGGLE_OFF
        ) { it.copy(analyticsConsent = enabled) }
    }

    // ================= PRIVATE OWNER CONSOLE AUTH =================

    fun signInOwner(activity: Activity) {
        soundManager.notifyUserInteraction()
        soundManager.playSfx(SoundCue.BUTTON_TAP)
        hapticManager.trigger(HapticCue.TAP)
        _uiState.update {
            it.copy(
                ownerAuth = it.ownerAuth.copy(isBusy = true, errorMessage = null, infoMessage = null)
            )
        }
        viewModelScope.launch {
            when (val outcome = GoogleAuthHelper.signInWithGoogle(activity)) {
                is GoogleSignInOutcome.Success -> {
                    val u = outcome.user
                    val allowlisted = adminRepo.isAllowlistedAdmin(u.email, u.isEmailVerified)
                    if (allowlisted) {
                        val verify = adminRepo.verifyOwnerConnection(u.uid)
                        _uiState.update {
                            it.copy(
                                ownerAuth = it.ownerAuth.copy(
                                    userId = u.uid,
                                    displayName = u.displayName,
                                    email = u.email,
                                    emailVerified = u.isEmailVerified,
                                    isAllowlistedAdmin = true,
                                    isBusy = false,
                                    firestoreVerified = verify.isSuccess,
                                    infoMessage = if (verify.isSuccess) {
                                        "Owner console verified with Firestore security rules."
                                    } else {
                                        verify.exceptionOrNull()?.localizedMessage ?: "Firestore verification failed."
                                    }
                                )
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                ownerAuth = it.ownerAuth.copy(
                                    userId = u.uid,
                                    displayName = u.displayName,
                                    email = u.email,
                                    emailVerified = u.isEmailVerified,
                                    isAllowlistedAdmin = false,
                                    isBusy = false,
                                    firestoreVerified = false,
                                    errorMessage = "Access denied: ${u.email ?: "this account"} is not in the authorized owner allowlist."
                                )
                            )
                        }
                    }
                }
                GoogleSignInOutcome.Cancelled -> {
                    _uiState.update {
                        it.copy(ownerAuth = it.ownerAuth.copy(isBusy = false, errorMessage = "Sign-in cancelled."))
                    }
                }
                is GoogleSignInOutcome.Failed -> {
                    _uiState.update {
                        it.copy(ownerAuth = it.ownerAuth.copy(isBusy = false, errorMessage = outcome.message))
                    }
                }
            }
        }
    }

    fun verifyOwnerFirestoreAccess() {
        val owner = _uiState.value.ownerAuth
        val uid = owner.userId ?: return
        _uiState.update { it.copy(ownerAuth = it.ownerAuth.copy(isBusy = true, errorMessage = null)) }
        viewModelScope.launch {
            val res = adminRepo.verifyOwnerConnection(uid)
            _uiState.update {
                it.copy(
                    ownerAuth = it.ownerAuth.copy(
                        isBusy = false,
                        firestoreVerified = res.isSuccess,
                        infoMessage = if (res.isSuccess) "Server-side Firestore owner rules verified." else null,
                        errorMessage = res.exceptionOrNull()?.localizedMessage
                    )
                )
            }
        }
    }

    fun signOutOwner(context: Context) {
        soundManager.playSfx(SoundCue.MENU_CLOSE)
        viewModelScope.launch {
            GoogleAuthHelper.signOut(context)
            _uiState.update { it.copy(ownerAuth = OwnerAuthState()) }
        }
    }

    fun recoverWithFreshState() {
        val freshProgress = PlayerProgress()
        val freshSettings = AppSettings()
        soundManager.updateSettings(freshSettings)
        hapticManager.enabled = freshSettings.hapticEnabled
        _uiState.update {
            it.copy(
                loadingError = null,
                progress = freshProgress,
                settings = freshSettings,
                currentScreen = AppScreen.UsernameOnboarding
            )
        }
    }

    private fun detectLowRamDevice(): Boolean {
        return try {
            val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
                am.isLowRamDevice || totalGb <= 2.3 || am.memoryClass <= 192
            } else false
        } catch (_: Throwable) {
            false
        }
    }

    fun effectiveGraphicsQuality(): GraphicsQuality {
        val state = _uiState.value
        val selected = state.settings.graphicsQuality
        if (selected != GraphicsQuality.AUTO) return selected
        return if (state.isLowRamDevice) GraphicsQuality.LOW_RAM else GraphicsQuality.HIGH
    }

    fun onForegroundChanged(foreground: Boolean) {
        soundManager.onForegroundChanged(foreground)
        val now = System.currentTimeMillis()
        if (foreground) {
            foregroundStartMs = now
        } else {
            val elapsedSec = ((now - foregroundStartMs) / 1000L).coerceAtLeast(0L)
            if (elapsedSec > 0L) {
                updateTelemetry { it.copy(totalSessionDurationSec = it.totalSessionDurationSec + elapsedSec) }
            }
            if (_uiState.value.currentScreen == AppScreen.Game) {
                saveActiveBoardSnapshot()
            }
        }
    }

    fun reportEstimatedFps(fps: Float) {
        val now = System.currentTimeMillis()
        if (fps !in 5f..144f || now - lastFpsSaveMs < 5000L) return
        lastFpsSaveMs = now
        updateTelemetry { current ->
            val nextAvg = if (current.avgFpsEstimate <= 0f) fps else current.avgFpsEstimate * 0.7f + fps * 0.3f
            current.copy(avgFpsEstimate = nextAvg)
        }
    }

    private fun recordLocalNonFatal() {
        updateTelemetry { it.copy(nonFatalErrorCount = it.nonFatalErrorCount + 1) }
    }

    private fun updateTelemetry(transform: (DeviceTelemetrySummary) -> DeviceTelemetrySummary) {
        val updated = transform(_uiState.value.deviceTelemetry)
        _uiState.update { it.copy(deviceTelemetry = updated) }
        viewModelScope.launch(Dispatchers.IO) {
            storage.saveDeviceTelemetry(updated)
        }
    }

    // ================= NAVIGATION & LEGAL =================

    fun navigateTo(screen: AppScreen) {
        soundManager.notifyUserInteraction()
        val cue = when (screen) {
            AppScreen.Settings, AppScreen.FruitVault, AppScreen.PeachGarden, AppScreen.OwnerDashboard -> SoundCue.MENU_OPEN
            else -> SoundCue.BUTTON_TAP
        }
        soundManager.playSfx(cue)
        hapticManager.trigger(HapticCue.TAP)

        if (_uiState.value.currentScreen == AppScreen.Game && screen != AppScreen.Game) {
            saveActiveBoardSnapshot()
            hintIdleJob?.cancel()
        }

        val mood = when (screen) {
            AppScreen.Home, AppScreen.LevelMap, AppScreen.PeachGarden, AppScreen.Settings, AppScreen.OwnerDashboard -> MusicMood.LOBBY
            AppScreen.FruitVault -> MusicMood.REWARDS
            AppScreen.Game -> MusicMood.GAMEPLAY
            else -> MusicMood.LOBBY
        }
        soundManager.setMusicMood(mood)
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun openLegalDocument(docType: LegalDocType) {
        soundManager.notifyUserInteraction()
        soundManager.playSfx(SoundCue.MENU_OPEN)
        hapticManager.trigger(HapticCue.TAP)
        val current = _uiState.value.currentScreen
        val returnScreen = if (current is AppScreen.LegalDocument) current.returnTo else current
        _uiState.update {
            it.copy(currentScreen = AppScreen.LegalDocument(docType, returnScreen))
        }
    }

    fun navigateBack() {
        soundManager.playSfx(SoundCue.BACK)
        hapticManager.trigger(HapticCue.TAP)
        when (val current = _uiState.value.currentScreen) {
            is AppScreen.LegalDocument -> _uiState.update { it.copy(currentScreen = current.returnTo) }
            AppScreen.OwnerDashboard -> _uiState.update { it.copy(currentScreen = AppScreen.Home) }
            AppScreen.LevelMap,
            AppScreen.PeachGarden,
            AppScreen.FruitVault,
            AppScreen.Settings -> {
                soundManager.setMusicMood(MusicMood.LOBBY)
                _uiState.update { it.copy(currentScreen = AppScreen.Home) }
            }
            AppScreen.Game -> {
                val gamePhase = _uiState.value.game.phase
                if (gamePhase == GamePhase.VICTORY || gamePhase == GamePhase.FAILED) {
                    soundManager.setMusicMood(MusicMood.LOBBY)
                    _uiState.update { it.copy(currentScreen = AppScreen.LevelMap) }
                } else if (gamePhase == GamePhase.PAUSED) {
                    saveActiveBoardSnapshot()
                    soundManager.setMusicMood(MusicMood.LOBBY)
                    _uiState.update { it.copy(currentScreen = AppScreen.Home) }
                } else {
                    pauseGame()
                }
            }
            AppScreen.GardenReveal -> finishGardenReveal()
            AppScreen.Home,
            AppScreen.Loading,
            AppScreen.UsernameOnboarding -> Unit
        }
    }

    // ================= DAILY REWARDS, SKINS & NOTIFICATIONS =================

    fun canClaimDailyReward(): Boolean {
        val today = (System.currentTimeMillis() / 86_400_000L).toInt()
        return _uiState.value.progress.lastDailyClaimDay < today
    }

    fun claimDailyReward() {
        soundManager.notifyUserInteraction()
        val today = (System.currentTimeMillis() / 86_400_000L).toInt()
        val prev = _uiState.value.progress
        if (prev.lastDailyClaimDay >= today) return

        val nextStreak = if (prev.lastDailyClaimDay == today - 1) {
            (prev.dailyStreak % 7) + 1
        } else 1
        val rewardItem = OrchardCatalog.dailyRewards[(nextStreak - 1).coerceIn(0, 6)]

        val nextInventory = prev.boosterInventory.toMutableMap()
        fun addBooster(b: BoosterType, qty: Int = 1) {
            nextInventory[b] = (nextInventory[b] ?: 0) + qty
        }
        when (nextStreak) {
            1 -> addBooster(BoosterType.RAINBOW)
            2 -> addBooster(BoosterType.BOMB)
            3 -> addBooster(BoosterType.LIGHTNING)
            4 -> addBooster(BoosterType.MAGIC_PEACH)
            5 -> { addBooster(BoosterType.RAINBOW); addBooster(BoosterType.BOMB) }
            6 -> { addBooster(BoosterType.LIGHTNING); addBooster(BoosterType.MAGIC_PEACH) }
            else -> BoosterType.entries.forEach { addBooster(it) }
        }

        val updated = prev.copy(
            dailyStreak = nextStreak,
            lastDailyClaimDay = today,
            boosterInventory = nextInventory
        )
        soundManager.playSfx(SoundCue.REWARD_CLAIM)
        hapticManager.trigger(HapticCue.REWARD)
        persistProgress(updated)

        val note = GameNotification(
            id = notificationIdCounter++,
            title = "Daily Meadow Gift Claimed!",
            message = "${rewardItem.title}: ${rewardItem.rewardSummary}!"
        )
        _uiState.update {
            it.copy(
                progress = updated,
                notifications = (listOf(note) + it.notifications).take(8),
                rewardBannerMessage = "Day $nextStreak claimed: ${rewardItem.rewardSummary}!"
            )
        }
    }

    fun clearRewardBanner() {
        _uiState.update { it.copy(rewardBannerMessage = null) }
    }

    fun selectFruitSkin(skin: FruitSkin) {
        soundManager.notifyUserInteraction()
        val prog = _uiState.value.progress
        if (skin.id !in prog.unlockedFruitSkins) {
            soundManager.playSfx(SoundCue.INVALID_SWAP)
            hapticManager.trigger(HapticCue.ERROR)
            return
        }
        soundManager.playSfx(SoundCue.TOGGLE_ON)
        hapticManager.trigger(HapticCue.TAP)
        val updated = prog.copy(selectedFruitSkin = skin.id)
        persistProgress(updated)
        _uiState.update { it.copy(progress = updated) }
    }

    private fun buildInitialNotifications(progress: PlayerProgress): List<GameNotification> {
        val list = mutableListOf<GameNotification>()
        val today = (System.currentTimeMillis() / 86_400_000L).toInt()
        if (progress.lastDailyClaimDay < today) {
            list += GameNotification(
                id = notificationIdCounter++,
                title = "Daily Garden Gift Ready",
                message = "Claim your daily gift in Profile & Rewards to earn free boosters!"
            )
        }
        return list
    }

    // ================= LEVEL START (NO COUNTDOWN) & TUTORIAL =================

    fun startOrResumeCurrentLevel() {
        soundManager.notifyUserInteraction()
        val snap = _uiState.value.progress.activeSnapshot
        if (snap != null) {
            resumeFromSnapshot(snap)
        } else {
            startLevel(_uiState.value.progress.highestUnlockedLevel)
        }
    }

    fun startLevel(levelNumber: Int, forceTutorial: Boolean = false) {
        soundManager.notifyUserInteraction()
        activeMoveJob?.cancel()
        hintIdleJob?.cancel()
        soundManager.playSfx(SoundCue.BUTTON_TAP)
        hapticManager.trigger(HapticCue.TAP)

        val level = LevelRepository.getLevel(levelNumber)
        soundManager.setChapter(level.chapter)
        soundManager.setMusicMood(MusicMood.GAMEPLAY)
        val board = matchEngine.createPlayableBoard(level)
        val showTutorial = forceTutorial || (levelNumber == 1 && !_uiState.value.progress.tutorialCompleted)
        val tutHint = if (showTutorial) matchEngine.findValidMove(board) else null

        val seen = _uiState.value.progress.seenMechanics
        val mechanicTip = when (levelNumber) {
            3 -> if ("lightning" !in seen) MechanicTip(
                key = "lightning",
                title = "New! Lightning Fruit",
                description = "Match 4 fruits in a row to craft a crackling Lightning Fruit that clears an entire row or column!",
                boosterType = BoosterType.LIGHTNING
            ) else null
            5 -> if ("bomb" !in seen) MechanicTip(
                key = "bomb",
                title = "New! Bomb Fruit",
                description = "Match an L or T shape to craft a Bomb Fruit that blasts a colorful 3×3 burst!",
                boosterType = BoosterType.BOMB
            ) else null
            11 -> if ("rainbow" !in seen) MechanicTip(
                key = "rainbow",
                title = "New! Rainbow Fruit",
                description = "Match 5 fruits in a line to craft a Rainbow Fruit that clears every fruit of one colour!",
                boosterType = BoosterType.RAINBOW
            ) else null
            16 -> if ("magic_peach" !in seen) MechanicTip(
                key = "magic_peach",
                title = "New! Magic Peach Combo",
                description = "Swap any two Special Fruits together to unleash a giant Magic Peach Garden Splash!",
                boosterType = BoosterType.MAGIC_PEACH
            ) else null
            else -> null
        }

        val clearedProgress = _uiState.value.progress.copy(activeSnapshot = null)
        persistProgress(clearedProgress)

        updateTelemetry { t ->
            val nextMap = t.levelStarts.toMutableMap()
            nextMap[levelNumber] = (nextMap[levelNumber] ?: 0) + 1
            t.copy(levelStarts = nextMap)
        }
        analyticsTracker.logLevelStart(levelNumber, level.chapter)

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.Game,
                progress = clearedProgress,
                game = GameUiState(
                    level = level,
                    board = board,
                    movesRemaining = level.maxMoves,
                    score = 0,
                    phase = GamePhase.IDLE,
                    statusBanner = level.tutorialTip,
                    mechanicTip = mechanicTip,
                    tutorialActive = showTutorial,
                    tutorialHint = tutHint
                )
            )
        }
        scheduleHintTimer()
    }

    fun dismissMechanicTip() {
        val tip = _uiState.value.game.mechanicTip ?: return
        soundManager.playSfx(SoundCue.BUTTON_TAP)
        hapticManager.trigger(HapticCue.TAP)
        val updated = _uiState.value.progress.copy(
            seenMechanics = _uiState.value.progress.seenMechanics + tip.key
        )
        persistProgress(updated)
        _uiState.update {
            it.copy(
                progress = updated,
                game = it.game.copy(mechanicTip = null)
            )
        }
    }

    fun dismissTutorial() {
        soundManager.playSfx(SoundCue.MENU_CLOSE)
        val updated = _uiState.value.progress.copy(tutorialCompleted = true)
        persistProgress(updated)
        analyticsTracker.logTutorialCompleted()
        _uiState.update {
            it.copy(
                progress = updated,
                game = it.game.copy(tutorialActive = false, tutorialHint = null, tutorialCelebration = null)
            )
        }
    }

    fun resumeFromSnapshot(snapshot: SavedBoardSnapshot) {
        soundManager.notifyUserInteraction()
        activeMoveJob?.cancel()
        hintIdleJob?.cancel()
        soundManager.playSfx(SoundCue.BUTTON_TAP)
        hapticManager.trigger(HapticCue.TAP)

        val level = LevelRepository.getLevel(snapshot.levelNumber)
        soundManager.setChapter(level.chapter)
        soundManager.setMusicMood(MusicMood.GAMEPLAY)
        matchEngine.ensureNextIdAbove(snapshot.cells)
        val board = BoardState(snapshot.rows, snapshot.cols, snapshot.cells)

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.Game,
                game = GameUiState(
                    level = level,
                    board = board,
                    movesRemaining = snapshot.movesRemaining,
                    score = snapshot.score,
                    collectedFruits = snapshot.collectedFruits,
                    clearedObstacles = snapshot.clearedObstacles,
                    goldenWavesTriggered = snapshot.goldenWavesTriggered,
                    phase = GamePhase.IDLE
                )
            )
        }
        scheduleHintTimer()
    }

    fun pauseGame() {
        if (_uiState.value.game.phase == GamePhase.IDLE) {
            hintIdleJob?.cancel()
            soundManager.playSfx(SoundCue.MENU_OPEN)
            hapticManager.trigger(HapticCue.TAP)
            saveActiveBoardSnapshot()
            _uiState.update { it.copy(game = it.game.copy(phase = GamePhase.PAUSED)) }
        }
    }

    fun resumeGame() {
        if (_uiState.value.game.phase == GamePhase.PAUSED) {
            soundManager.playSfx(SoundCue.MENU_CLOSE)
            hapticManager.trigger(HapticCue.TAP)
            _uiState.update { it.copy(game = it.game.copy(phase = GamePhase.IDLE)) }
            scheduleHintTimer()
        }
    }

    fun exitGameToHome() {
        soundManager.playSfx(SoundCue.BACK)
        hapticManager.trigger(HapticCue.TAP)
        saveActiveBoardSnapshot()
        hintIdleJob?.cancel()
        soundManager.setMusicMood(MusicMood.LOBBY)
        _uiState.update { it.copy(currentScreen = AppScreen.Home) }
    }

    private fun saveActiveBoardSnapshot() {
        val g = _uiState.value.game
        if (g.board.cells.isEmpty()) return
        if (g.phase == GamePhase.VICTORY || g.phase == GamePhase.FAILED) return
        val snap = SavedBoardSnapshot(
            levelNumber = g.level.levelNumber,
            rows = g.board.rows,
            cols = g.board.cols,
            movesRemaining = g.movesRemaining,
            score = g.score,
            collectedFruits = g.collectedFruits,
            clearedObstacles = g.clearedObstacles,
            goldenWavesTriggered = g.goldenWavesTriggered,
            cells = g.board.cells
        )
        val updated = _uiState.value.progress.copy(activeSnapshot = snap)
        _uiState.update { it.copy(progress = updated) }
        persistProgress(updated)
    }

    // ================= BOOSTERS, MATCH INPUT & WATER CHANNEL CASCADE =================

    fun selectBooster(booster: BoosterType) {
        soundManager.notifyUserInteraction()
        val g = _uiState.value.game
        if (g.phase != GamePhase.IDLE) return
        val count = _uiState.value.progress.boosterInventory[booster] ?: 0
        if (count <= 0) {
            soundManager.playSfx(SoundCue.INVALID_SWAP)
            hapticManager.trigger(HapticCue.ERROR)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        activeBooster = null,
                        statusBanner = "Earn more ${booster.title} boosters from Daily Gifts & 3-star wins!"
                    )
                )
            }
            return
        }

        val nextSelected = if (g.activeBooster == booster) null else booster
        soundManager.playSfx(if (nextSelected != null) SoundCue.TOGGLE_ON else SoundCue.TOGGLE_OFF)
        hapticManager.trigger(HapticCue.TAP)
        _uiState.update {
            it.copy(
                game = it.game.copy(
                    activeBooster = nextSelected,
                    selectedCell = null,
                    waterChannelCells = emptySet(),
                    statusBanner = if (nextSelected != null) {
                        "Tap any fruit to unleash ${nextSelected.title}!"
                    } else null
                )
            )
        }
    }

    private fun useActiveBoosterAt(booster: BoosterType, row: Int, col: Int) {
        hintIdleJob?.cancel()
        activeMoveJob?.cancel()
        activeMoveJob = viewModelScope.launch {
            val prevInventory = _uiState.value.progress.boosterInventory.toMutableMap()
            val cur = prevInventory[booster] ?: 0
            if (cur <= 0) {
                _uiState.update { it.copy(game = it.game.copy(activeBooster = null)) }
                return@launch
            }
            prevInventory[booster] = cur - 1
            val updatedProg = _uiState.value.progress.copy(boosterInventory = prevInventory)
            persistProgress(updatedProg)

            val g0 = _uiState.value.game
            _uiState.update {
                it.copy(
                    progress = updatedProg,
                    game = it.game.copy(
                        activeBooster = null,
                        selectedCell = null,
                        waterChannelCells = emptySet(),
                        hint = null,
                        statusBanner = null,
                        phase = GamePhase.CLEARING
                    )
                )
            }

            val res = matchEngine.applyBooster(g0.board, row, col, booster)
            playSpecialCues(res.triggeredSpecialKinds)
            applyResolutionAndCascade(res, startingCombo = 1, focalRow = row, focalCol = col)
        }
    }

    private fun computeWaterChannels(board: BoardState, row: Int, col: Int): Set<Pair<Int, Int>> {
        val channels = linkedSetOf(row to col)
        val dirs = listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)
        for ((dr, dc) in dirs) {
            val nr = row + dr
            val nc = col + dc
            if (matchEngine.canSwap(board, row, col, nr, nc)) {
                channels.add(nr to nc)
            }
        }
        return channels
    }

    fun onTileTapped(row: Int, col: Int) {
        soundManager.notifyUserInteraction()
        val g = _uiState.value.game
        if (g.phase != GamePhase.IDLE) return
        if (!g.board.inBounds(row, col)) return

        val pendingBooster = g.activeBooster
        if (pendingBooster != null) {
            useActiveBoosterAt(pendingBooster, row, col)
            return
        }

        val tappedCell = g.board.get(row, col)
        val selected = g.selectedCell

        if (g.statusBanner != null) {
            _uiState.update { it.copy(game = it.game.copy(statusBanner = null)) }
        }

        if (selected == null) {
            if (tappedCell.isMovable) {
                val channels = computeWaterChannels(g.board, row, col)
                _uiState.update {
                    it.copy(
                        game = it.game.copy(
                            selectedCell = row to col,
                            waterChannelCells = channels,
                            hint = null
                        )
                    )
                }
                soundManager.playSfx(SoundCue.TILE_SELECT)
                soundManager.playSfx(SoundCue.WATER_RIPPLE)
                hapticManager.trigger(HapticCue.TAP)
            }
            return
        }

        if (selected == (row to col)) {
            if (tappedCell.isSpecialFruit && tappedCell.obstacle != ObstacleType.VINES) {
                executeSpecialTap(row, col)
            } else {
                _uiState.update {
                    it.copy(game = it.game.copy(selectedCell = null, waterChannelCells = emptySet()))
                }
                soundManager.playSfx(SoundCue.TILE_SELECT)
            }
            return
        }

        val dr = abs(selected.first - row)
        val dc = abs(selected.second - col)
        if (dr + dc == 1) {
            attemptSwap(selected.first, selected.second, row, col)
        } else {
            if (tappedCell.isMovable) {
                val channels = computeWaterChannels(g.board, row, col)
                _uiState.update {
                    it.copy(
                        game = it.game.copy(
                            selectedCell = row to col,
                            waterChannelCells = channels,
                            hint = null
                        )
                    )
                }
                soundManager.playSfx(SoundCue.TILE_SELECT)
                soundManager.playSfx(SoundCue.WATER_RIPPLE)
                hapticManager.trigger(HapticCue.TAP)
            } else {
                _uiState.update {
                    it.copy(game = it.game.copy(selectedCell = null, waterChannelCells = emptySet()))
                }
            }
        }
    }

    fun onTileSwiped(fromRow: Int, fromCol: Int, dRow: Int, dCol: Int) {
        soundManager.notifyUserInteraction()
        val g = _uiState.value.game
        if (g.phase != GamePhase.IDLE) return
        if (g.activeBooster != null) {
            useActiveBoosterAt(g.activeBooster, fromRow, fromCol)
            return
        }
        val toRow = fromRow + dRow
        val toCol = fromCol + dCol
        if (!g.board.inBounds(fromRow, fromCol) || !g.board.inBounds(toRow, toCol)) return
        if (g.statusBanner != null) {
            _uiState.update { it.copy(game = it.game.copy(statusBanner = null)) }
        }
        attemptSwap(fromRow, fromCol, toRow, toCol)
    }

    fun showHintNow() {
        soundManager.notifyUserInteraction()
        val g = _uiState.value.game
        if (g.phase != GamePhase.IDLE) return
        val hint = matchEngine.findValidMove(g.board)
        if (hint != null) {
            soundManager.playSfx(SoundCue.WATER_RIPPLE)
            hapticManager.trigger(HapticCue.TAP)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        hint = hint,
                        waterChannelCells = setOf(hint.r1 to hint.c1, hint.r2 to hint.c2)
                    )
                )
            }
        }
    }

    private fun scheduleHintTimer() {
        hintIdleJob?.cancel()
        hintIdleJob = viewModelScope.launch {
            delay(7500L)
            val g = _uiState.value.game
            if (g.phase == GamePhase.IDLE && g.hint == null && !g.tutorialActive) {
                val hint = matchEngine.findValidMove(g.board)
                if (hint != null) {
                    _uiState.update { it.copy(game = it.game.copy(hint = hint)) }
                }
            }
        }
    }

    private fun animDelay(baseMs: Long): Long {
        val s = _uiState.value.settings
        return if (!s.animationsEnabled) (baseMs / 3).coerceAtLeast(35L) else baseMs
    }

    private fun playSpecialCues(kinds: Set<SpecialKind>) {
        when {
            SpecialKind.MAGIC_PEACH in kinds -> {
                soundManager.playSfx(SoundCue.MAGIC_PEACH)
                hapticManager.trigger(HapticCue.GOLDEN)
            }
            SpecialKind.RAINBOW in kinds -> {
                soundManager.playSfx(SoundCue.RAINBOW_BURST)
                hapticManager.trigger(HapticCue.GOLDEN)
            }
            SpecialKind.BOMB in kinds -> {
                soundManager.playSfx(SoundCue.BOMB_BLAST)
                hapticManager.trigger(HapticCue.GOLDEN)
            }
            SpecialKind.LIGHTNING_ROW in kinds || SpecialKind.LIGHTNING_COL in kinds -> {
                soundManager.playSfx(SoundCue.LIGHTNING_ZAP)
                hapticManager.trigger(HapticCue.MATCH)
            }
            else -> {
                soundManager.playSfx(SoundCue.GOLDEN_CHARGE)
                hapticManager.trigger(HapticCue.GOLDEN)
            }
        }
    }

    private fun executeSpecialTap(row: Int, col: Int) {
        hintIdleJob?.cancel()
        activeMoveJob?.cancel()
        activeMoveJob = viewModelScope.launch {
            val g0 = _uiState.value.game
            val movesLeft = (g0.movesRemaining - 1).coerceAtLeast(0)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        selectedCell = null,
                        waterChannelCells = emptySet(),
                        hint = null,
                        movesRemaining = movesLeft,
                        phase = GamePhase.CLEARING
                    )
                )
            }
            val waveRes = matchEngine.triggerSpecialCell(g0.board, row, col)
            playSpecialCues(waveRes.triggeredSpecialKinds)
            applyResolutionAndCascade(waveRes, startingCombo = 1, focalRow = row, focalCol = col)
        }
    }

    private fun attemptSwap(r1: Int, c1: Int, r2: Int, c2: Int) {
        val g = _uiState.value.game
        if (!matchEngine.canSwap(g.board, r1, c1, r2, c2)) {
            soundManager.playSfx(SoundCue.INVALID_SWAP)
            hapticManager.trigger(HapticCue.ERROR)
            _uiState.update {
                it.copy(game = it.game.copy(selectedCell = null, waterChannelCells = emptySet()))
            }
            return
        }

        hintIdleJob?.cancel()
        activeMoveJob?.cancel()
        activeMoveJob = viewModelScope.launch {
            soundManager.playSfx(SoundCue.SWAP)
            hapticManager.trigger(HapticCue.TAP)
            val swappedBoard = matchEngine.swapCells(g.board, r1, c1, r2, c2)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        selectedCell = null,
                        waterChannelCells = setOf(r1 to c1, r2 to c2),
                        hint = null,
                        phase = GamePhase.ANIMATING_SWAP,
                        swappingPair = (r1 to c1) to (r2 to c2),
                        board = swappedBoard
                    )
                )
            }
            delay(animDelay(135L))

            val cellA = swappedBoard.get(r1, c1)
            val cellB = swappedBoard.get(r2, c2)

            if (cellA.isSpecialFruit || cellB.isSpecialFruit) {
                val (sRow, sCol, otherCell) = if (cellA.isSpecialFruit) {
                    Triple(r1, c1, cellB)
                } else {
                    Triple(r2, c2, cellA)
                }
                val movesLeft = (_uiState.value.game.movesRemaining - 1).coerceAtLeast(0)
                _uiState.update {
                    it.copy(
                        game = it.game.copy(
                            movesRemaining = movesLeft,
                            swappingPair = null
                        )
                    )
                }
                val waveRes = matchEngine.triggerSpecialCell(
                    board = swappedBoard,
                    row = sRow,
                    col = sCol,
                    swappedWithCell = otherCell
                )
                playSpecialCues(waveRes.triggeredSpecialKinds)
                applyResolutionAndCascade(waveRes, startingCombo = 1, focalRow = sRow, focalCol = sCol)
                return@launch
            }

            val matches = matchEngine.findMatches(swappedBoard)
            if (matches.isEmpty()) {
                soundManager.playSfx(SoundCue.INVALID_SWAP)
                hapticManager.trigger(HapticCue.ERROR)
                _uiState.update {
                    it.copy(
                        game = it.game.copy(
                            phase = GamePhase.REVERSING_SWAP,
                            board = g.board,
                            waterChannelCells = emptySet(),
                            swappingPair = (r2 to c2) to (r1 to c1)
                        )
                    )
                }
                delay(animDelay(145L))
                _uiState.update {
                    it.copy(
                        game = it.game.copy(
                            phase = GamePhase.IDLE,
                            swappingPair = null
                        )
                    )
                }
                scheduleHintTimer()
                return@launch
            }

            if (g.tutorialActive) {
                soundManager.playSfx(SoundCue.TUTORIAL_SUCCESS)
                hapticManager.trigger(HapticCue.REWARD)
                val doneProg = _uiState.value.progress.copy(tutorialCompleted = true)
                persistProgress(doneProg)
                analyticsTracker.logTutorialCompleted()
                _uiState.update {
                    it.copy(
                        progress = doneProg,
                        game = it.game.copy(
                            tutorialActive = false,
                            tutorialHint = null,
                            tutorialCelebration = "Great Swap!"
                        )
                    )
                }
            }

            val movesLeft = (_uiState.value.game.movesRemaining - 1).coerceAtLeast(0)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        movesRemaining = movesLeft,
                        swappingPair = null
                    )
                )
            }
            val firstRes = matchEngine.resolveMatchesStep(swappedBoard, matches, comboStep = 1)
            soundManager.playSfx(SoundCue.MATCH, comboMultiplier = 1)
            soundManager.playSfx(SoundCue.FRUIT_POP)
            hapticManager.trigger(HapticCue.MATCH)
            if (firstRes.createdGoldenCount > 0) {
                soundManager.playSfx(SoundCue.GOLDEN_CHARGE)
                hapticManager.trigger(HapticCue.GOLDEN)
            }
            applyResolutionAndCascade(firstRes, startingCombo = 1, focalRow = r2, focalCol = c2)
        }
    }

    private suspend fun applyResolutionAndCascade(
        initialStep: StepResolution,
        startingCombo: Int,
        focalRow: Int,
        focalCol: Int
    ) {
        var step = initialStep
        var combo = startingCombo

        while (true) {
            val g = _uiState.value.game
            val newFruits = g.collectedFruits.toMutableMap()
            step.collectedFruits.forEach { (f, cnt) ->
                newFruits[f] = (newFruits[f] ?: 0) + cnt
            }
            val newObstacles = g.clearedObstacles.toMutableMap()
            step.clearedObstacles.forEach { (o, cnt) ->
                newObstacles[o] = (newObstacles[o] ?: 0) + cnt
            }
            val newScore = g.score + step.pointsAwarded
            val newWaves = g.goldenWavesTriggered + step.triggeredGoldenWaves
            val peakCombo = maxOf(g.maxComboAchieved, combo)

            val waveWaterCoords = step.clearedIndices.map { idx ->
                (idx / g.board.cols) to (idx % g.board.cols)
            }.toSet()

            val calloutLabel = when {
                SpecialKind.MAGIC_PEACH in step.triggeredSpecialKinds -> "Magic Peach! +${step.pointsAwarded}"
                SpecialKind.RAINBOW in step.triggeredSpecialKinds -> "Rainbow Burst! +${step.pointsAwarded}"
                SpecialKind.BOMB in step.triggeredSpecialKinds -> "Bomb Splash! +${step.pointsAwarded}"
                SpecialKind.LIGHTNING_ROW in step.triggeredSpecialKinds ||
                    SpecialKind.LIGHTNING_COL in step.triggeredSpecialKinds -> "Lightning Zap! +${step.pointsAwarded}"
                combo >= 4 -> "Super Combo! x$combo"
                combo == 3 -> "Amazing! Combo x3"
                combo == 2 -> "Great! +${step.pointsAwarded}"
                step.clearedIndices.size >= 4 -> "Sweet! +${step.pointsAwarded}"
                else -> "+${step.pointsAwarded}"
            }
            val callout = FloatingCallout(
                id = calloutIdCounter++,
                text = calloutLabel,
                row = focalRow,
                col = focalCol,
                isGolden = step.triggeredGoldenWaves > 0 || combo >= 3
            )

            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        phase = GamePhase.CLEARING,
                        activeClearIndices = step.clearedIndices,
                        activeWaveIndices = step.goldenWaveIndices,
                        activeSpecialKinds = step.triggeredSpecialKinds,
                        waterChannelCells = waveWaterCoords,
                        score = newScore,
                        collectedFruits = newFruits,
                        clearedObstacles = newObstacles,
                        goldenWavesTriggered = newWaves,
                        comboCount = combo,
                        maxComboAchieved = peakCombo,
                        callouts = (it.game.callouts + callout).takeLast(3)
                    )
                )
            }
            delay(animDelay(240L))

            val gravityRes = matchEngine.applyGravityAndRefillWithDistances(
                board = step.boardAfterClear,
                availableFruits = g.level.availableFruits
            )
            soundManager.playSfx(SoundCue.FALL)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        phase = GamePhase.FALLING,
                        board = gravityRes.board,
                        fallDistances = gravityRes.fallRowsByCellId,
                        activeClearIndices = emptySet(),
                        activeWaveIndices = emptySet(),
                        activeSpecialKinds = emptySet(),
                        waterChannelCells = emptySet(),
                        tutorialCelebration = null
                    )
                )
            }
            delay(animDelay(225L))

            _uiState.update {
                it.copy(game = it.game.copy(fallDistances = emptyMap()))
            }

            val cascadeMatches = matchEngine.findMatches(gravityRes.board)
            if (cascadeMatches.isEmpty()) break

            combo += 1
            soundManager.playSfx(SoundCue.CASCADE_COMBO, comboMultiplier = combo)
            soundManager.playSfx(SoundCue.WATER_RIPPLE)
            hapticManager.trigger(if (combo >= 3) HapticCue.GOLDEN else HapticCue.MATCH)
            step = matchEngine.resolveMatchesStep(gravityRes.board, cascadeMatches, comboStep = combo)
            if (step.triggeredSpecialKinds.isNotEmpty()) {
                playSpecialCues(step.triggeredSpecialKinds)
            } else if (step.createdGoldenCount > 0) {
                soundManager.playSfx(SoundCue.GOLDEN_CHARGE)
            }
        }

        val settled = _uiState.value.game
        if (areAllObjectivesMet(settled)) {
            val moveBonus = settled.movesRemaining * 75
            val finalScore = settled.score + moveBonus
            val stars = computeStars(finalScore, settled.level.starThresholds)

            soundManager.setMusicMood(MusicMood.VICTORY)
            soundManager.playSfx(SoundCue.VICTORY)
            hapticManager.trigger(HapticCue.VICTORY)

            val prevProg = _uiState.value.progress
            val existingRes = prevProg.levelResults[settled.level.levelNumber]
            val updatedResult = LevelResult(
                levelNumber = settled.level.levelNumber,
                stars = maxOf(existingRes?.stars ?: 0, stars),
                highScore = maxOf(existingRes?.highScore ?: 0, finalScore),
                bestCombo = maxOf(existingRes?.bestCombo ?: 1, settled.maxComboAchieved)
            )
            val newResults = prevProg.levelResults.toMutableMap().apply {
                put(settled.level.levelNumber, updatedResult)
            }
            val nextHighest = maxOf(
                prevProg.highestUnlockedLevel,
                (settled.level.levelNumber + 1).coerceAtMost(30)
            )
            // Reward a bonus booster on first 3-star completion!
            val nextInventory = prevProg.boosterInventory.toMutableMap()
            if (stars == 3 && (existingRes?.stars ?: 0) < 3) {
                val earnedBooster = BoosterType.entries[settled.level.levelNumber % BoosterType.entries.size]
                nextInventory[earnedBooster] = (nextInventory[earnedBooster] ?: 0) + 1
            }

            val updatedProg = prevProg.copy(
                highestUnlockedLevel = nextHighest,
                levelResults = newResults,
                boosterInventory = nextInventory,
                activeSnapshot = null
            )

            val (enrichedProg, newlyUnlockedNotes) = evaluateUnlocksAndAchievements(
                progress = updatedProg,
                goldenWaves = settled.goldenWavesTriggered,
                maxCombo = settled.maxComboAchieved
            )
            persistProgress(enrichedProg)

            updateTelemetry { t ->
                val nextMap = t.levelCompletes.toMutableMap()
                nextMap[settled.level.levelNumber] = (nextMap[settled.level.levelNumber] ?: 0) + 1
                t.copy(levelCompletes = nextMap)
            }
            analyticsTracker.logLevelEnd(
                levelNumber = settled.level.levelNumber,
                success = true,
                stars = stars,
                score = finalScore,
                movesRemaining = settled.movesRemaining
            )

            _uiState.update {
                it.copy(
                    progress = enrichedProg,
                    notifications = (newlyUnlockedNotes + it.notifications).take(8),
                    game = settled.copy(
                        phase = GamePhase.VICTORY,
                        score = finalScore,
                        earnedStars = stars,
                        comboCount = 0,
                        callouts = emptyList()
                    )
                )
            }
            return
        }

        if (settled.movesRemaining <= 0) {
            soundManager.playSfx(SoundCue.RETRY)
            hapticManager.trigger(HapticCue.ERROR)
            val updatedProgress = _uiState.value.progress.copy(activeSnapshot = null)
            persistProgress(updatedProgress)

            updateTelemetry { t ->
                val nextMap = t.levelFailures.toMutableMap()
                nextMap[settled.level.levelNumber] = (nextMap[settled.level.levelNumber] ?: 0) + 1
                t.copy(levelFailures = nextMap)
            }
            analyticsTracker.logLevelEnd(
                levelNumber = settled.level.levelNumber,
                success = false,
                stars = 0,
                score = settled.score,
                movesRemaining = 0
            )

            _uiState.update {
                it.copy(
                    progress = updatedProgress,
                    game = settled.copy(
                        phase = GamePhase.FAILED,
                        comboCount = 0,
                        callouts = emptyList()
                    )
                )
            }
            return
        }

        var currentBoard = settled.board
        if (matchEngine.findValidMove(currentBoard) == null) {
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        phase = GamePhase.SHUFFLING,
                        statusBanner = "Refreshing garden stream..."
                    )
                )
            }
            delay(animDelay(420L))
            currentBoard = matchEngine.shuffleBoard(currentBoard, settled.level.availableFruits)
            _uiState.update {
                it.copy(
                    game = it.game.copy(
                        board = currentBoard,
                        statusBanner = null
                    )
                )
            }
        }

        _uiState.update {
            it.copy(
                game = it.game.copy(
                    phase = GamePhase.IDLE,
                    comboCount = 0
                )
            )
        }
        saveActiveBoardSnapshot()
        scheduleHintTimer()
    }

    private fun evaluateUnlocksAndAchievements(
        progress: PlayerProgress,
        goldenWaves: Int,
        maxCombo: Int
    ): Pair<PlayerProgress, List<GameNotification>> {
        val skins = progress.unlockedFruitSkins.toMutableList()
        val achs = progress.unlockedAchievements.toMutableList()
        val notes = mutableListOf<GameNotification>()

        fun unlockAch(id: String) {
            if (id !in achs) {
                achs += id
                OrchardCatalog.achievements.find { it.id == id }?.let { def ->
                    notes += GameNotification(
                        id = notificationIdCounter++,
                        title = "Badge Unlocked: ${def.title}",
                        message = def.description
                    )
                }
            }
        }

        fun unlockSkin(skin: FruitSkin) {
            if (skin.id !in skins) {
                skins += skin.id
                notes += GameNotification(
                    id = notificationIdCounter++,
                    title = "Fruit Style Unlocked: ${skin.title}",
                    message = "Equip ${skin.title} anytime in Profile & Rewards!"
                )
            }
        }

        if (progress.completedCount >= 1) unlockAch("first_harvest")
        if (progress.totalStars >= 10) {
            unlockAch("star_collector")
            unlockSkin(FruitSkin.CANDY_GLAZE)
        }
        if (goldenWaves >= 1) unlockAch("golden_chef")
        if (maxCombo >= 3) unlockAch("combo_master")
        if (progress.totalStars >= 25) {
            unlockAch("royal_harvester")
            unlockSkin(FruitSkin.ROYAL_CROWN)
        }
        if (progress.completedCount >= 15) unlockAch("bloom_champion")

        if (notes.isNotEmpty()) {
            soundManager.playSfx(SoundCue.NOTIFICATION_POP)
        }

        return progress.copy(
            unlockedFruitSkins = skins,
            unlockedAchievements = achs
        ) to notes
    }

    fun objectiveProgress(objective: LevelObjective, game: GameUiState = _uiState.value.game): Pair<Int, Int> {
        val current = when (objective.kind) {
            ObjectiveKind.SCORE -> game.score
            ObjectiveKind.COLLECT_FRUIT -> game.collectedFruits[objective.fruitType] ?: 0
            ObjectiveKind.CLEAR_OBSTACLE -> game.clearedObstacles[objective.obstacleType] ?: 0
            ObjectiveKind.TRIGGER_GOLDEN_WAVE -> game.goldenWavesTriggered
        }
        return current.coerceAtMost(objective.targetAmount) to objective.targetAmount
    }

    private fun areAllObjectivesMet(game: GameUiState): Boolean =
        game.level.objectives.all { obj ->
            val (cur, target) = objectiveProgress(obj, game)
            cur >= target
        }

    private fun computeStars(score: Int, thresholds: Triple<Int, Int, Int>): Int = when {
        score >= thresholds.third -> 3
        score >= thresholds.second -> 2
        else -> 1
    }

    // ================= SETTINGS =================

    fun setMusicEnabled(enabled: Boolean) {
        updateSettings(if (enabled) SoundCue.TOGGLE_ON else SoundCue.TOGGLE_OFF) {
            it.copy(
                muted = false,
                musicVolume = if (enabled) 0.65f else 0f
            )
        }
    }

    fun setSfxEnabled(enabled: Boolean) {
        updateSettings(if (enabled) SoundCue.TOGGLE_ON else SoundCue.TOGGLE_OFF) {
            it.copy(
                muted = false,
                sfxVolume = if (enabled) 0.85f else 0f
            )
        }
    }

    fun updateSettings(
        playToggleCue: SoundCue? = null,
        transform: (AppSettings) -> AppSettings
    ) {
        soundManager.notifyUserInteraction()
        val updated = transform(_uiState.value.settings)
        soundManager.updateSettings(updated)
        hapticManager.enabled = updated.hapticEnabled
        if (playToggleCue != null) {
            soundManager.playSfx(playToggleCue)
            hapticManager.trigger(HapticCue.TAP)
        }
        _uiState.update { it.copy(settings = updated) }
        viewModelScope.launch(Dispatchers.IO) {
            storage.saveSettings(updated)
        }
    }

    fun resetProgress(clearUsernameToo: Boolean = false) {
        soundManager.playSfx(SoundCue.MENU_CLOSE)
        hapticManager.trigger(HapticCue.ERROR)
        if (clearUsernameToo) {
            storage.wipeAllLocalPlayerData()
            val fresh = PlayerProgress()
            _uiState.update {
                it.copy(
                    progress = fresh,
                    deviceTelemetry = DeviceTelemetrySummary(),
                    currentScreen = AppScreen.UsernameOnboarding
                )
            }
        } else {
            val currentName = _uiState.value.progress.playerUsername
            val legal = _uiState.value.progress.legalAccepted
            val reset = storage.resetProgressKeepLegal(legalAccepted = legal, playerUsername = currentName)
            _uiState.update { it.copy(progress = reset) }
        }
    }

    private fun persistProgress(progress: PlayerProgress) {
        viewModelScope.launch(Dispatchers.IO) {
            storage.saveProgress(progress)
        }
    }

    override fun onCleared() {
        soundManager.release()
        super.onCleared()
    }
}
