package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.ui.theme.AquaButtonBottom
import com.example.ui.theme.AquaButtonTop
import com.example.ui.theme.BerryInk
import com.example.ui.theme.BlossomPink
import com.example.ui.theme.CreamParchment
import com.example.ui.theme.CreamParchmentBevel
import com.example.ui.theme.CreamParchmentLight
import com.example.ui.theme.FreshMint
import com.example.ui.theme.GoldenBevel
import com.example.ui.theme.GoldenStar
import com.example.ui.theme.GreenGlossBottom
import com.example.ui.theme.GreenGlossMid
import com.example.ui.theme.GreenGlossTop
import com.example.ui.theme.LobbyBgBottom
import com.example.ui.theme.LobbyBgMid
import com.example.ui.theme.LobbyBgTop
import com.example.ui.theme.MeadowDeepGreen
import com.example.ui.theme.MeadowGreen
import com.example.ui.theme.PeachBannerBottom
import com.example.ui.theme.PeachBannerShadow
import com.example.ui.theme.PeachBannerStripe
import com.example.ui.theme.PeachBannerTop
import com.example.ui.theme.PeachBubble
import com.example.ui.theme.PeachOrange
import com.example.ui.theme.PeachOrangeDeep
import com.example.ui.theme.PortraitFrameBg
import com.example.ui.theme.SkyDeep
import com.example.ui.theme.SkyHorizon
import com.example.ui.theme.SkyMist
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.SoftPeach
import com.example.ui.theme.StreamBlue
import com.example.ui.theme.SunWarm
import com.example.ui.theme.WaterSurfaceDark
import com.example.ui.theme.WaterSurfaceLight
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun OrchardBackdrop(
    topColor: Color = SkyDeep,
    bottomColor: Color = MeadowDeepGreen,
    graphicsQuality: GraphicsQuality = GraphicsQuality.HIGH,
    animationsEnabled: Boolean = true,
    showFloatingFruits: Boolean = false,
    showOverhangingBranch: Boolean = false,
    showCornerFlowers: Boolean = true,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val showParticles = animationsEnabled && graphicsQuality != GraphicsQuality.LOW_RAM
    val particleCount = if (graphicsQuality == GraphicsQuality.HIGH) 9 else 4

    val driftProgress = if (showParticles) {
        val transition = rememberInfiniteTransition(label = "peach_garden_drift")
        val p by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 14000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "drift"
        )
        p
    } else 0f

    val wingFlap = if (showParticles) {
        val transition = rememberInfiniteTransition(label = "butterfly_flap")
        val f by transition.animateFloat(
            initialValue = 0.25f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 280, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "flap"
        )
        f
    } else 0.85f

    val bgFruits = remember {
        listOf(
            FruitType.PEACH,
            FruitType.STRAWBERRY,
            FruitType.GRAPES,
            FruitType.BANANA
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colorStops = arrayOf(
                        0.0f to topColor,
                        0.38f to SkyHorizon,
                        0.64f to SkyMist,
                        0.72f to MeadowGreen,
                        1.0f to bottomColor
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Radiant sun glow in upper sky
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        SunWarm.copy(alpha = 0.48f),
                        Color.White.copy(alpha = 0.22f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.20f, h * 0.14f),
                    radius = size.minDimension * 0.52f
                ),
                radius = size.minDimension * 0.52f,
                center = Offset(w * 0.20f, h * 0.14f)
            )

            // Soft sculpted clouds
            val cloudDrift = if (showParticles) sin((driftProgress * 2 * PI).toDouble()).toFloat() * 14f else 0f
            drawSculptedCloud(Offset(w * 0.18f + cloudDrift, h * 0.16f), size.minDimension * 0.16f)
            drawSculptedCloud(Offset(w * 0.78f - cloudDrift * 0.7f, h * 0.21f), size.minDimension * 0.19f)

            // Distant deep emerald hills
            val farHill = Path().apply {
                moveTo(0f, h * 0.68f)
                quadraticTo(w * 0.26f, h * 0.60f, w * 0.54f, h * 0.66f)
                quadraticTo(w * 0.82f, h * 0.72f, w, h * 0.63f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(
                farHill,
                Brush.verticalGradient(
                    listOf(Color(0xFF7FD048), MeadowGreen),
                    startY = h * 0.60f,
                    endY = h
                )
            )

            // Foreground golden-sunlit grass bank
            val nearHill = Path().apply {
                moveTo(0f, h * 0.80f)
                quadraticTo(w * 0.28f, h * 0.75f, w * 0.56f, h * 0.81f)
                quadraticTo(w * 0.82f, h * 0.86f, w, h * 0.78f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(
                nearHill,
                Brush.verticalGradient(
                    listOf(Color(0xFF8CD63E), Color(0xFFB3BA31), MeadowDeepGreen),
                    startY = h * 0.76f,
                    endY = h
                )
            )

            // Winding crystal river channel
            val streamPath = Path().apply {
                moveTo(w * 0.10f, h)
                cubicTo(w * 0.26f, h * 0.88f, w * 0.64f, h * 0.90f, w * 0.82f, h * 0.77f)
                lineTo(w * 0.89f, h * 0.79f)
                cubicTo(w * 0.71f, h * 0.94f, w * 0.35f, h * 0.92f, w * 0.24f, h)
                close()
            }
            drawPath(
                path = streamPath,
                brush = Brush.horizontalGradient(
                    listOf(WaterSurfaceDark.copy(alpha = 0.55f), WaterSurfaceLight.copy(alpha = 0.65f))
                )
            )

            // Overhanging peach tree foliage branch (Screenshot 1/3/4/5/8 vibe)
            if (showOverhangingBranch) {
                val sway = if (showParticles) sin((driftProgress * 2 * PI).toDouble()).toFloat() * 3f else 0f
                // Branch wood
                val branch = Path().apply {
                    moveTo(w + 10f, h * 0.17f)
                    quadraticTo(w * 0.80f, h * 0.16f + sway, w * 0.64f, h * 0.10f + sway)
                    lineTo(w * 0.66f, h * 0.085f + sway)
                    quadraticTo(w * 0.82f, h * 0.14f + sway, w + 10f, h * 0.15f)
                    close()
                }
                drawPath(branch, Color(0xFF845F3B))

                // Layered leafy clusters
                val leafCircles = listOf(
                    Triple(0.50f, 0.09f, 0.07f),
                    Triple(0.60f, 0.10f, 0.085f),
                    Triple(0.71f, 0.095f, 0.095f),
                    Triple(0.83f, 0.105f, 0.10f),
                    Triple(0.95f, 0.11f, 0.105f)
                )
                leafCircles.forEachIndexed { i, (lx, ly, lr) ->
                    val rad = size.minDimension * lr
                    val cy = h * ly + sway * 0.5f
                    drawCircle(
                        color = if (i % 2 == 0) Color(0xFF7CB62D) else Color(0xFF93CC3B),
                        radius = rad,
                        center = Offset(w * lx, cy)
                    )
                    drawCircle(
                        color = Color(0xFFB4DF54).copy(alpha = 0.55f),
                        radius = rad * 0.62f,
                        center = Offset(w * lx - rad * 0.18f, cy - rad * 0.18f)
                    )
                }
                // Little hanging peaches on the branch
                drawCircle(PeachOrange, size.minDimension * 0.022f, Offset(w * 0.73f, h * 0.14f + sway))
                drawCircle(PeachOrange, size.minDimension * 0.020f, Offset(w * 0.89f, h * 0.145f + sway))
            }

            // Lush deep pink flowers in bottom-left and deep green leaves in bottom-right
            if (showCornerFlowers) {
                val leafDark = Color(0xFF438C22)
                val leafMid = Color(0xFF6BB332)
                // Bottom-left leaves + big pink blossoms
                drawOval(leafDark, Offset(-16f, h * 0.87f), Size(w * 0.18f, h * 0.11f))
                drawOval(leafMid, Offset(w * 0.06f, h * 0.90f), Size(w * 0.17f, h * 0.10f))
                drawCornerFlower(Offset(w * 0.05f, h * 0.88f), size.minDimension * 0.055f, Color(0xFFFF6D93))
                drawCornerFlower(Offset(w * 0.14f, h * 0.94f), size.minDimension * 0.062f, Color(0xFFE84376))
                drawCornerFlower(Offset(w * 0.22f, h * 0.975f), size.minDimension * 0.044f, Color(0xFFFF85A8))

                // Bottom-right lush foliage
                drawOval(leafDark, Offset(w * 0.82f, h * 0.91f), Size(w * 0.22f, h * 0.11f))
                drawOval(leafMid, Offset(w * 0.72f, h * 0.94f), Size(w * 0.20f, h * 0.10f))
            }

            // Fluttering magical garden butterflies
            if (showParticles) {
                val b1x = w * (0.14f + 0.72f * ((driftProgress + 0.12f) % 1f))
                val b1y = h * (0.24f + 0.045f * sin((driftProgress * 4 * PI).toDouble()).toFloat())
                drawButterfly(
                    center = Offset(b1x, b1y),
                    wingSpan = 16f,
                    flapFraction = wingFlap,
                    wingColor = PeachOrange.copy(alpha = 0.88f),
                    accentColor = SunWarm
                )

                val b2x = w * (0.86f - 0.70f * ((driftProgress + 0.55f) % 1f))
                val b2y = h * (0.76f + 0.035f * cos((driftProgress * 4 * PI).toDouble()).toFloat())
                drawButterfly(
                    center = Offset(b2x, b2y),
                    wingSpan = 14f,
                    flapFraction = wingFlap,
                    wingColor = BlossomPink.copy(alpha = 0.84f),
                    accentColor = SoftLavender
                )
            }

            // Gentle drifting blossom petals & sunlight sparkles
            if (showParticles) {
                for (i in 0 until particleCount) {
                    val xRatio = ((i * 0.19f + 0.07f) % 0.92f)
                    val yBase = ((i * 0.21f + driftProgress) % 1.1f) - 0.05f
                    val sway = sin((driftProgress * 2 * PI + i).toDouble()).toFloat() * 16f
                    val cx = w * xRatio + sway
                    val cy = h * yBase
                    val petalColor = when (i % 3) {
                        0 -> BlossomPink.copy(alpha = 0.30f)
                        1 -> SunWarm.copy(alpha = 0.42f)
                        else -> Color.White.copy(alpha = 0.34f)
                    }
                    drawCircle(color = petalColor, radius = 4.8f + (i % 3) * 2.2f, center = Offset(cx, cy))
                }

                if (showFloatingFruits) {
                    bgFruits.forEachIndexed { idx, fruit ->
                        val x = w * (0.13f + idx * 0.25f)
                        val bob = sin((driftProgress * 2 * PI + idx * 1.3).toDouble()).toFloat() * 10f
                        val y = h * (0.18f + (idx % 2) * 0.62f) + bob
                        drawFruitShape(
                            fruit = fruit,
                            center = Offset(x, y),
                            radius = 17f,
                            alpha = 0.18f
                        )
                    }
                }
            }
        }
        content()
    }
}

private fun DrawScope.drawSculptedCloud(center: Offset, radius: Float) {
    val c = Color.White.copy(alpha = 0.42f)
    drawOval(c, Offset(center.x - radius * 1.3f, center.y - radius * 0.25f), Size(radius * 2.6f, radius * 0.72f))
    drawCircle(c, radius * 0.62f, Offset(center.x - radius * 0.38f, center.y - radius * 0.12f))
    drawCircle(c, radius * 0.50f, Offset(center.x + radius * 0.32f, center.y - radius * 0.05f))
}

private fun DrawScope.drawCornerFlower(center: Offset, r: Float, petalColor: Color) {
    for (i in 0 until 5) {
        val ang = i * (2.0 * PI / 5.0) - PI / 2.0
        val px = center.x + (cos(ang) * r * 0.56f).toFloat()
        val py = center.y + (sin(ang) * r * 0.56f).toFloat()
        drawCircle(petalColor, r * 0.48f, Offset(px, py))
        drawCircle(Color.White.copy(alpha = 0.25f), r * 0.25f, Offset(px - r * 0.08f, py - r * 0.08f))
    }
    drawCircle(SunWarm, r * 0.34f, center)
}

fun DrawScope.drawButterfly(
    center: Offset,
    wingSpan: Float,
    flapFraction: Float,
    wingColor: Color,
    accentColor: Color
) {
    val span = wingSpan * flapFraction.coerceIn(0.3f, 1f)
    drawOval(
        color = wingColor,
        topLeft = Offset(center.x - span * 1.1f, center.y - wingSpan * 0.72f),
        size = Size(span, wingSpan * 0.78f)
    )
    drawOval(
        color = wingColor,
        topLeft = Offset(center.x + span * 0.1f, center.y - wingSpan * 0.72f),
        size = Size(span, wingSpan * 0.78f)
    )
    drawOval(
        color = accentColor.copy(alpha = 0.90f),
        topLeft = Offset(center.x - span * 0.85f, center.y),
        size = Size(span * 0.75f, wingSpan * 0.56f)
    )
    drawOval(
        color = accentColor.copy(alpha = 0.90f),
        topLeft = Offset(center.x + span * 0.1f, center.y),
        size = Size(span * 0.75f, wingSpan * 0.56f)
    )
    drawRoundRect(
        color = Color(0xFF472F2A),
        topLeft = Offset(center.x - 2f, center.y - wingSpan * 0.4f),
        size = Size(4f, wingSpan * 0.8f),
        cornerRadius = CornerRadius(4f, 4f)
    )
}

/**
 * Animated crowned Peach mascot buddy matching Peach Quest's cheerful hero aesthetic.
 */
@Composable
fun PeachMascotCharacter(
    size: Dp = 110.dp,
    animationsEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val bobY = if (animationsEnabled) {
        val inf = rememberInfiniteTransition(label = "mascot_bob")
        val y by inf.animateFloat(
            initialValue = -3.5f,
            targetValue = 3.5f,
            animationSpec = infiniteRepeatable(
                animation = tween(1400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bob"
        )
        y
    } else 0f

    Canvas(
        modifier = modifier
            .size(size)
            .graphicsLayer { translationY = bobY }
    ) {
        val cx = this.size.width / 2f
        val cy = this.size.height * 0.57f
        val r = this.size.minDimension * 0.37f

        drawCircle(
            brush = Brush.radialGradient(
                listOf(SunWarm.copy(alpha = 0.52f), Color.Transparent),
                center = Offset(cx, cy),
                radius = r * 1.4f
            ),
            radius = r * 1.4f,
            center = Offset(cx, cy)
        )

        val bodyPath = Path().apply {
            moveTo(cx, cy - r * 0.56f)
            cubicTo(cx + r * 0.86f, cy - r * 0.96f, cx + r * 1.12f, cy + r * 0.22f, cx, cy + r * 0.95f)
            cubicTo(cx - r * 1.12f, cy + r * 0.22f, cx - r * 0.86f, cy - r * 0.96f, cx, cy - r * 0.56f)
            close()
        }
        drawPath(
            path = bodyPath,
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFE5B8), Color(0xFFFF9658), Color(0xFFE8465E)),
                center = Offset(cx - r * 0.25f, cy - r * 0.25f),
                radius = r * 1.45f
            )
        )
        drawPath(bodyPath, Color(0xFF7D221E), style = Stroke(width = r * 0.075f))

        val leafPath = Path().apply {
            moveTo(cx - r * 0.1f, cy - r * 0.6f)
            quadraticTo(cx - r * 0.72f, cy - r * 1.15f, cx - r * 0.92f, cy - r * 0.64f)
            quadraticTo(cx - r * 0.48f, cy - r * 0.48f, cx - r * 0.1f, cy - r * 0.6f)
            close()
        }
        drawPath(leafPath, GreenGlossMid)
        drawPath(leafPath, Color(0xFF145E09), style = Stroke(width = r * 0.045f))

        val crownPath = Path().apply {
            moveTo(cx - r * 0.12f, cy - r * 0.64f)
            lineTo(cx - r * 0.02f, cy - r * 1.10f)
            lineTo(cx + r * 0.20f, cy - r * 0.85f)
            lineTo(cx + r * 0.36f, cy - r * 1.14f)
            lineTo(cx + r * 0.50f, cy - r * 0.80f)
            lineTo(cx + r * 0.68f, cy - r * 1.00f)
            lineTo(cx + r * 0.54f, cy - r * 0.52f)
            close()
        }
        drawPath(crownPath, GoldenStar)
        drawPath(crownPath, PeachBannerShadow, style = Stroke(width = r * 0.055f, cap = StrokeCap.Round))
        drawCircle(BlossomPink, r * 0.08f, Offset(cx + r * 0.30f, cy - r * 0.74f))

        drawArc(
            color = Color.White.copy(alpha = 0.60f),
            startAngle = 198f,
            sweepAngle = 62f,
            useCenter = false,
            topLeft = Offset(cx - r * 0.72f, cy - r * 0.70f),
            size = Size(r * 1.35f, r * 1.35f),
            style = Stroke(width = r * 0.09f, cap = StrokeCap.Round)
        )

        drawOval(
            color = Color(0xFFFF3860).copy(alpha = 0.42f),
            topLeft = Offset(cx - r * 0.58f, cy + r * 0.10f),
            size = Size(r * 0.28f, r * 0.16f)
        )
        drawOval(
            color = Color(0xFFFF3860).copy(alpha = 0.42f),
            topLeft = Offset(cx + r * 0.30f, cy + r * 0.10f),
            size = Size(r * 0.28f, r * 0.16f)
        )

        drawCircle(Color(0xFF2B120C), r * 0.17f, Offset(cx - r * 0.26f, cy - r * 0.06f))
        drawCircle(Color.White, r * 0.07f, Offset(cx - r * 0.31f, cy - r * 0.11f))
        drawCircle(Color.White, r * 0.03f, Offset(cx - r * 0.21f, cy - r * 0.01f))

        val winkPath = Path().apply {
            moveTo(cx + r * 0.40f, cy - r * 0.14f)
            lineTo(cx + r * 0.18f, cy - r * 0.05f)
            lineTo(cx + r * 0.40f, cy + r * 0.04f)
        }
        drawPath(winkPath, Color(0xFF2B120C), style = Stroke(width = r * 0.075f, cap = StrokeCap.Round))

        val smilePath = Path().apply {
            moveTo(cx - r * 0.14f, cy + r * 0.16f)
            quadraticTo(cx, cy + r * 0.42f, cx + r * 0.14f, cy + r * 0.16f)
            close()
        }
        drawPath(smilePath, Color(0xFF6B1420))
        drawArc(
            color = Color(0xFFFF6E8A),
            startAngle = 15f,
            sweepAngle = 150f,
            useCenter = true,
            topLeft = Offset(cx - r * 0.09f, cy + r * 0.19f),
            size = Size(r * 0.18f, r * 0.12f)
        )
    }
}

/**
 * Top striped tangerine-peach HUD bar inspired by casual puzzle studio banners.
 */
@Composable
fun GameStripedBanner(
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(PeachBannerTop, PeachBannerBottom)))
            .drawBehind {
                // Diagonal warm stripes
                val stripeW = 36f
                var x = -size.height
                while (x < size.width + size.height) {
                    drawLine(
                        color = PeachBannerStripe.copy(alpha = 0.45f),
                        start = Offset(x, 0f),
                        end = Offset(x + size.height * 0.55f, size.height),
                        strokeWidth = 14f
                    )
                    x += stripeW
                }
                // Crisp bottom bevel lip
                drawLine(
                    color = PeachBannerShadow,
                    start = Offset(0f, size.height - 3f),
                    end = Offset(size.width, size.height - 3f),
                    strokeWidth = 6f
                )
            }
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

/**
 * Rounded-square portrait medallion housing the Peach mascot inside deep mahogany background.
 */
@Composable
fun PeachPortraitFrame(
    size: Dp = 64.dp,
    animationsEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(PortraitFrameBg)
            .border(2.5.dp, GoldenBevel, RoundedCornerShape(16.dp))
            .padding(2.dp)
    ) {
        PeachMascotCharacter(
            size = size * 0.88f,
            animationsEnabled = animationsEnabled
        )
    }
}

/**
 * Tactile glossy 3D emerald-lime green Play button framed in warm cream bevel.
 */
@Composable
fun GlossyGreenPlayButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "",
    enabled: Boolean = true,
    minHeight: Dp = 68.dp,
    label: String? = null,
    content: (@Composable RowScope.() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.94f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "gloss_play_press"
    )
    val outerShape = RoundedCornerShape(99.dp)

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(10.dp, outerShape, ambientColor = BerryInk)
            .clip(outerShape)
            .background(if (enabled) CreamParchmentLight else Color(0xFFD8CEC5))
            .border(2.dp, PeachBannerShadow.copy(alpha = 0.55f), outerShape)
            .padding(5.dp)
    ) {
        Button(
            onClick = onClick,
            enabled = enabled,
            interactionSource = interactionSource,
            shape = outerShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Transparent,
                contentColor = Color.White,
                disabledContainerColor = Color(0xFFAEB5A7),
                disabledContentColor = Color.White.copy(alpha = 0.78f)
            ),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = minHeight)
                .clip(outerShape)
                .background(
                    if (enabled) {
                        Brush.verticalGradient(listOf(GreenGlossTop, GreenGlossMid, GreenGlossBottom))
                    } else {
                        Brush.verticalGradient(listOf(Color(0xFFBFC6B8), Color(0xFF939B8B)))
                    }
                )
                .drawWithContent {
                    drawContent()
                    if (enabled) {
                        // Top glossy highlight crescent
                        drawRoundRect(
                            color = Color.White.copy(alpha = 0.34f),
                            topLeft = Offset(size.width * 0.06f, size.height * 0.07f),
                            size = Size(size.width * 0.88f, size.height * 0.34f),
                            cornerRadius = CornerRadius(99f, 99f)
                        )
                        // Subtle bottom darker bevel edge
                        drawLine(
                            color = Color(0xFF105904),
                            start = Offset(14f, size.height - 2f),
                            end = Offset(size.width - 14f, size.height - 2f),
                            strokeWidth = 5f
                        )
                    }
                }
                .minimumInteractiveComponentSize()
                .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
        ) {
            if (content != null) {
                content()
            } else {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = label ?: "Play",
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
                if (!label.isNullOrBlank()) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * Glossy aqua-teal round corner icon button (Settings / Pause / Back) framed in thick cream ring.
 */
@Composable
fun AquaRoundIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "",
    size: Dp = 54.dp
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.91f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "aqua_btn_scale"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .size(size)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(CreamParchmentLight)
            .border(1.5.dp, BerryInk.copy(alpha = 0.25f), CircleShape)
            .padding(4.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(AquaButtonTop, AquaButtonBottom)))
            .drawWithContent {
                drawContent()
                drawOval(
                    color = Color.White.copy(alpha = 0.34f),
                    topLeft = Offset(this.size.width * 0.16f, this.size.height * 0.08f),
                    size = Size(this.size.width * 0.68f, this.size.height * 0.32f)
                )
            }
            .minimumInteractiveComponentSize()
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(bounded = true),
                onClick = onClick
            )
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = Color.White,
            modifier = Modifier.size(size * 0.52f)
        )
    }
}

/**
 * Striped tangerine-peach wooden/card modal matching Screenshot 2's Level Preview & Popup style.
 */
@Composable
fun GameWoodenFrameModal(
    title: String,
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null,
    closeTestTag: String = "modal_close_button",
    content: @Composable ColumnScope.() -> Unit
) {
    val outerShape = RoundedCornerShape(34.dp)
    val innerShape = RoundedCornerShape(26.dp)

    Box(
        modifier = modifier
            .shadow(16.dp, outerShape)
            .clip(outerShape)
            .background(Brush.verticalGradient(listOf(PeachBannerTop, PeachBannerBottom)))
            .border(3.dp, PeachBannerShadow, outerShape)
            .drawBehind {
                // Horizontal/diagonal festive stripes across outer peach frame
                var y = 0f
                while (y < size.height) {
                    drawLine(
                        color = PeachBannerStripe.copy(alpha = 0.42f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y + 24f),
                        strokeWidth = 10f
                    )
                    y += 28f
                }
            }
            .padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CreamParchmentLight,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 36.dp)
                )
                if (onClose != null) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .size(40.dp)
                            .then(Modifier.testTag(closeTestTag))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = PeachBannerShadow,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = innerShape,
                color = CreamParchment,
                border = BorderStroke(3.dp, CreamParchmentBevel),
                shadowElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    content = content
                )
            }
        }
    }
}

@Composable
fun PeachPrimaryButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "",
    enabled: Boolean = true,
    containerColor: Color = PeachOrange,
    contentColor: Color = Color.White,
    minHeight: Dp = 56.dp,
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.94f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "btn_bounce"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(30.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = Color(0xFFDFC8B4),
            disabledContentColor = Color(0xFF7D6354)
        ),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 7.dp,
            pressedElevation = 2.dp
        ),
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .drawWithContent {
                drawContent()
                if (enabled) {
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.28f),
                        topLeft = Offset(size.width * 0.08f, size.height * 0.09f),
                        size = Size(size.width * 0.84f, size.height * 0.28f),
                        cornerRadius = CornerRadius(99f, 99f)
                    )
                }
            }
            .minimumInteractiveComponentSize()
            .heightIn(min = minHeight)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
    ) {
        content()
    }
}

@Composable
fun PeachCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = CreamParchment,
    borderColor: Color = CreamParchmentBevel,
    cornerRadius: Dp = 26.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (onClick != null && isPressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "card_press"
    )

    Surface(
        shape = shape,
        color = backgroundColor,
        border = BorderStroke(2.dp, borderColor),
        tonalElevation = 0.dp,
        shadowElevation = 7.dp,
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(7.dp, shape, ambientColor = PeachBannerShadow.copy(alpha = 0.28f))
            .then(
                if (onClick != null) {
                    Modifier
                        .minimumInteractiveComponentSize()
                        .clickable(
                            interactionSource = interactionSource,
                            indication = androidx.compose.material3.ripple(),
                            onClick = onClick
                        )
                } else Modifier
            )
    ) {
        content()
    }
}
