package com.example.levels

import com.example.model.AchievementDefinition
import com.example.model.Chapter
import com.example.model.FruitType
import com.example.model.GardenSection
import com.example.model.LevelDefinition
import com.example.model.LevelObjective
import com.example.model.ObjectiveKind
import com.example.model.ObstacleType

object LevelRepository {

    private val world1StarterFruits = listOf(
        FruitType.PEACH,
        FruitType.STRAWBERRY,
        FruitType.GRAPES,
        FruitType.BANANA
    )

    private val world1MeadowFruits = listOf(
        FruitType.PEACH,
        FruitType.STRAWBERRY,
        FruitType.GRAPES,
        FruitType.BANANA,
        FruitType.RED_APPLE
    )

    private val world1OrchardFruits = listOf(
        FruitType.PEACH,
        FruitType.STRAWBERRY,
        FruitType.RED_APPLE,
        FruitType.GREEN_APPLE,
        FruitType.PEAR,
        FruitType.GRAPES
    )

    private val world2BerryFruits = listOf(
        FruitType.PEACH,
        FruitType.STRAWBERRY,
        FruitType.CHERRY,
        FruitType.RASPBERRY,
        FruitType.BLUEBERRY,
        FruitType.BLACKBERRY
    )

    private val world2PlumFruits = listOf(
        FruitType.PEACH,
        FruitType.CHERRY,
        FruitType.RASPBERRY,
        FruitType.BLUEBERRY,
        FruitType.BLACKBERRY,
        FruitType.PLUM
    )

    private val world3CitrusFruits = listOf(
        FruitType.PEACH,
        FruitType.ORANGE,
        FruitType.LEMON,
        FruitType.WATERMELON,
        FruitType.PINEAPPLE,
        FruitType.BANANA
    )

    private val world3IslandFruits = listOf(
        FruitType.PEACH,
        FruitType.PINEAPPLE,
        FruitType.MANGO,
        FruitType.PAPAYA,
        FruitType.COCONUT,
        FruitType.WATERMELON
    )

    private val world4ExoticFruits = listOf(
        FruitType.PEACH,
        FruitType.KIWI,
        FruitType.DRAGON_FRUIT,
        FruitType.AVOCADO,
        FruitType.PASSION_FRUIT,
        FruitType.POMEGRANATE
    )

    private val world4FinaleFruits = listOf(
        FruitType.PEACH,
        FruitType.STRAWBERRY,
        FruitType.DRAGON_FRUIT,
        FruitType.MANGO,
        FruitType.PASSION_FRUIT,
        FruitType.POMEGRANATE,
        FruitType.BLUEBERRY
    )

    private fun iceGrid(vararg coords: Pair<Int, Int>, hp: Int = 1): Map<Pair<Int, Int>, Pair<ObstacleType, Int>> =
        coords.associateWith { ObstacleType.ICE to hp }

    private fun combineObstacles(
        vararg groups: Map<Pair<Int, Int>, Pair<ObstacleType, Int>>
    ): Map<Pair<Int, Int>, Pair<ObstacleType, Int>> {
        val out = linkedMapOf<Pair<Int, Int>, Pair<ObstacleType, Int>>()
        groups.forEach { out.putAll(it) }
        return out
    }

    private fun steppedCornersVoid(rows: Int, cols: Int, cutSize: Int = 1): Set<Pair<Int, Int>> {
        val out = linkedSetOf<Pair<Int, Int>>()
        for (r in 0 until cutSize) {
            for (c in 0 until cutSize) {
                out.add(r to c)
                out.add(r to (cols - 1 - c))
                out.add((rows - 1 - r) to c)
                out.add((rows - 1 - r) to (cols - 1 - c))
            }
        }
        return out
    }

    private fun topCornersVoid(cols: Int): Set<Pair<Int, Int>> = setOf(
        0 to 0, 0 to 1, 0 to (cols - 2), 0 to (cols - 1),
        1 to 0, 1 to (cols - 1)
    )

    val allLevels: List<LevelDefinition> = listOf(
        // ================= WORLD 1: SUNNY SPROUT (1–7) =================
        LevelDefinition(
            levelNumber = 1,
            title = "Peach Gate",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 6, cols = 6,
            availableFruits = world1StarterFruits,
            maxMoves = 18,
            objectives = listOf(
                LevelObjective(ObjectiveKind.SCORE, 850, label = "Reach 850 points"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 12, fruitType = FruitType.PEACH, label = "Collect 12 Peaches")
            ),
            starThresholds = Triple(850, 1450, 2200),
            tutorialTip = "Swipe two neighbouring fruits to match 3 in a row!"
        ),
        LevelDefinition(
            levelNumber = 2,
            title = "Dewdrop Stream",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 6, cols = 6,
            availableFruits = world1StarterFruits,
            maxMoves = 20,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 14, fruitType = FruitType.GRAPES, label = "Collect 14 Grapes"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 12, fruitType = FruitType.BANANA, label = "Collect 12 Bananas")
            ),
            starThresholds = Triple(1100, 1800, 2600),
            voidCells = steppedCornersVoid(6, 6, cutSize = 1),
            initialWaterCells = setOf(0 to 2, 0 to 3, 1 to 2, 1 to 3, 2 to 3),
            tutorialTip = "Cascading falls spread the sparkling stream across the garden!"
        ),
        LevelDefinition(
            levelNumber = 3,
            title = "Lightning Spark",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 6, cols = 6,
            availableFruits = world1MeadowFruits,
            maxMoves = 20,
            objectives = listOf(
                LevelObjective(ObjectiveKind.TRIGGER_GOLDEN_WAVE, 1, label = "Trigger 1 Special Wave"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 14, fruitType = FruitType.RED_APPLE, label = "Collect 14 Red Apples")
            ),
            starThresholds = Triple(1350, 2150, 3000),
            tutorialTip = "Match 4 in a line to craft a crackling Lightning Fruit!"
        ),
        LevelDefinition(
            levelNumber = 4,
            title = "Meadow Breeze",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 6, cols = 7,
            availableFruits = world1MeadowFruits,
            maxMoves = 20,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 16, fruitType = FruitType.STRAWBERRY, label = "Collect 16 Strawberries"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 16, fruitType = FruitType.PEACH, label = "Collect 16 Peaches")
            ),
            starThresholds = Triple(1500, 2400, 3300),
            voidCells = topCornersVoid(7),
            initialWaterCells = setOf(0 to 2, 0 to 3, 0 to 4, 1 to 3, 2 to 3, 2 to 4)
        ),
        LevelDefinition(
            levelNumber = 5,
            title = "Fruit Bomb Garden",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 7, cols = 7,
            availableFruits = world1OrchardFruits,
            maxMoves = 22,
            objectives = listOf(
                LevelObjective(ObjectiveKind.SCORE, 2200, label = "Reach 2,200 points"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 18, fruitType = FruitType.GREEN_APPLE, label = "Collect 18 Green Apples"),
                LevelObjective(ObjectiveKind.TRIGGER_GOLDEN_WAVE, 1, label = "Trigger 1 Special Wave")
            ),
            starThresholds = Triple(2200, 3100, 4200),
            voidCells = steppedCornersVoid(7, 7, cutSize = 1),
            initialWaterCells = setOf(0 to 2, 0 to 3, 0 to 4, 1 to 3, 2 to 3),
            tutorialTip = "Match an L or T shape to craft an explosive Bomb Fruit!"
        ),
        LevelDefinition(
            levelNumber = 6,
            title = "Sunny Pears",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 6, cols = 6,
            availableFruits = world1OrchardFruits,
            maxMoves = 22,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.ICE, label = "Clear 6 Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 15, fruitType = FruitType.PEAR, label = "Collect 15 Pears")
            ),
            starThresholds = Triple(1600, 2500, 3500),
            initialObstacles = iceGrid(2 to 1, 2 to 2, 2 to 3, 2 to 4, 3 to 2, 3 to 3),
            tutorialTip = "Match fruits on frosted tiles to melt the frost!"
        ),
        LevelDefinition(
            levelNumber = 7,
            title = "Sprout Archway",
            chapter = Chapter.SUNNY_SPROUT,
            rows = 7, cols = 6,
            availableFruits = world1OrchardFruits,
            maxMoves = 22,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.ICE, label = "Clear 8 Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 18, fruitType = FruitType.PEACH, label = "Collect 18 Peaches")
            ),
            starThresholds = Triple(1850, 2800, 3900),
            initialObstacles = iceGrid(1 to 1, 1 to 4, 2 to 2, 2 to 3, 3 to 2, 3 to 3, 4 to 1, 4 to 4)
        ),

        // ================= WORLD 2: BERRY WOODS (8–15) =================
        LevelDefinition(
            levelNumber = 8,
            title = "Raspberry Brook",
            chapter = Chapter.BERRY_WOODS,
            rows = 6, cols = 6,
            availableFruits = world2BerryFruits,
            maxMoves = 22,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 20, fruitType = FruitType.RASPBERRY, label = "Collect 20 Raspberries"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.ICE, label = "Clear 8 Frost tiles")
            ),
            starThresholds = Triple(1900, 2900, 4000),
            initialObstacles = iceGrid(0 to 2, 0 to 3, 2 to 0, 2 to 5, 3 to 0, 3 to 5, 5 to 2, 5 to 3),
            tutorialTip = "Welcome to Berry Woods! Woodland berries love gentle frost!"
        ),
        LevelDefinition(
            levelNumber = 9,
            title = "Crystal Blackberries",
            chapter = Chapter.BERRY_WOODS,
            rows = 6, cols = 6,
            availableFruits = world2BerryFruits,
            maxMoves = 23,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 10, obstacleType = ObstacleType.ICE, label = "Clear 10 Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 18, fruitType = FruitType.BLACKBERRY, label = "Collect 18 Blackberries")
            ),
            starThresholds = Triple(2200, 3200, 4400),
            initialObstacles = iceGrid(
                1 to 2, 1 to 3, 2 to 1, 2 to 2, 2 to 3, 2 to 4,
                3 to 1, 3 to 4, 4 to 2, 4 to 3
            )
        ),
        LevelDefinition(
            levelNumber = 10,
            title = "Blueberry Hollow",
            chapter = Chapter.BERRY_WOODS,
            rows = 6, cols = 6,
            availableFruits = world2BerryFruits,
            maxMoves = 24,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 12, obstacleType = ObstacleType.ICE, label = "Clear 12 Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 20, fruitType = FruitType.BLUEBERRY, label = "Collect 20 Blueberries"),
                LevelObjective(ObjectiveKind.SCORE, 2600, label = "Reach 2,600 points")
            ),
            starThresholds = Triple(2600, 3600, 4800),
            initialObstacles = iceGrid(
                1 to 1, 1 to 2, 1 to 3, 1 to 4,
                2 to 1, 2 to 4, 3 to 1, 3 to 4,
                4 to 1, 4 to 2, 4 to 3, 4 to 4
            )
        ),
        LevelDefinition(
            levelNumber = 11,
            title = "Rainbow Glade",
            chapter = Chapter.BERRY_WOODS,
            rows = 7, cols = 7,
            availableFruits = world2PlumFruits,
            maxMoves = 24,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 18, fruitType = FruitType.CHERRY, label = "Collect 18 Cherries"),
                LevelObjective(ObjectiveKind.SCORE, 2500, label = "Reach 2,500 points")
            ),
            starThresholds = Triple(2500, 3600, 4800),
            tutorialTip = "Match 5 in a line to craft a Rainbow Fruit that clears a whole colour!"
        ),
        LevelDefinition(
            levelNumber = 12,
            title = "Tangled Vines",
            chapter = Chapter.BERRY_WOODS,
            rows = 7, cols = 7,
            availableFruits = world2PlumFruits,
            maxMoves = 24,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.VINES, label = "Clear 6 Vines"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 18, fruitType = FruitType.PLUM, label = "Collect 18 Plums")
            ),
            starThresholds = Triple(2500, 3700, 5000),
            initialObstacles = mapOf(
                (2 to 2) to (ObstacleType.VINES to 1),
                (2 to 4) to (ObstacleType.VINES to 1),
                (3 to 3) to (ObstacleType.VINES to 1),
                (4 to 2) to (ObstacleType.VINES to 1),
                (4 to 4) to (ObstacleType.VINES to 1),
                (5 to 3) to (ObstacleType.VINES to 1)
            ),
            tutorialTip = "Vines lock fruits in place — match beside them or blast with Specials!"
        ),
        LevelDefinition(
            levelNumber = 13,
            title = "Woodland Terrace",
            chapter = Chapter.BERRY_WOODS,
            rows = 7, cols = 7,
            availableFruits = world2PlumFruits,
            maxMoves = 25,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.VINES, label = "Clear 6 Vines"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 20, fruitType = FruitType.BLUEBERRY, label = "Collect 20 Blueberries")
            ),
            starThresholds = Triple(2700, 3900, 5200),
            initialObstacles = combineObstacles(
                iceGrid(1 to 1, 1 to 5, 3 to 1, 3 to 5, 5 to 1, 5 to 5),
                mapOf(
                    (2 to 3) to (ObstacleType.VINES to 1),
                    (3 to 2) to (ObstacleType.VINES to 1),
                    (3 to 3) to (ObstacleType.VINES to 1),
                    (3 to 4) to (ObstacleType.VINES to 1),
                    (4 to 2) to (ObstacleType.VINES to 1),
                    (4 to 4) to (ObstacleType.VINES to 1)
                )
            )
        ),
        LevelDefinition(
            levelNumber = 14,
            title = "Berry Cascade",
            chapter = Chapter.BERRY_WOODS,
            rows = 7, cols = 7,
            availableFruits = world2PlumFruits,
            maxMoves = 25,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.RASPBERRY, label = "Collect 22 Raspberries"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.PLUM, label = "Collect 22 Plums"),
                LevelObjective(ObjectiveKind.TRIGGER_GOLDEN_WAVE, 2, label = "Trigger 2 Special Waves")
            ),
            starThresholds = Triple(3000, 4300, 5600),
            initialObstacles = mapOf(
                (1 to 3) to (ObstacleType.VINES to 1),
                (3 to 1) to (ObstacleType.VINES to 1),
                (3 to 5) to (ObstacleType.VINES to 1),
                (5 to 3) to (ObstacleType.VINES to 1)
            )
        ),
        LevelDefinition(
            levelNumber = 15,
            title = "Woods Summit",
            chapter = Chapter.BERRY_WOODS,
            rows = 7, cols = 7,
            availableFruits = world2PlumFruits,
            maxMoves = 26,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.ICE, label = "Clear 8 Frost tiles"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.VINES, label = "Clear 6 Vines"),
                LevelObjective(ObjectiveKind.SCORE, 3400, label = "Reach 3,400 points")
            ),
            starThresholds = Triple(3400, 4700, 6200),
            initialObstacles = combineObstacles(
                iceGrid(1 to 2, 1 to 4, 2 to 1, 2 to 5, 4 to 1, 4 to 5, 5 to 2, 5 to 4),
                mapOf(
                    (2 to 3) to (ObstacleType.VINES to 1),
                    (3 to 2) to (ObstacleType.VINES to 1),
                    (3 to 3) to (ObstacleType.VINES to 1),
                    (3 to 4) to (ObstacleType.VINES to 1),
                    (4 to 3) to (ObstacleType.VINES to 1),
                    (5 to 3) to (ObstacleType.VINES to 1)
                )
            )
        ),

        // ================= WORLD 3: TROPICAL PARADISE (16–22) =================
        LevelDefinition(
            levelNumber = 16,
            title = "Wooden Crates",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3CitrusFruits,
            maxMoves = 25,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 5, obstacleType = ObstacleType.CRATE, label = "Break 5 Garden Crates"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 20, fruitType = FruitType.PINEAPPLE, label = "Collect 20 Pineapples")
            ),
            starThresholds = Triple(2800, 4100, 5400),
            initialObstacles = mapOf(
                (2 to 2) to (ObstacleType.CRATE to 1),
                (2 to 4) to (ObstacleType.CRATE to 1),
                (3 to 3) to (ObstacleType.CRATE to 1),
                (4 to 2) to (ObstacleType.CRATE to 1),
                (4 to 4) to (ObstacleType.CRATE to 1)
            ),
            tutorialTip = "Welcome to Tropical Paradise! Swap two Special Fruits together for a Magic Peach Splash!"
        ),
        LevelDefinition(
            levelNumber = 17,
            title = "Citrus Lagoon",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3CitrusFruits,
            maxMoves = 26,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.ORANGE, label = "Collect 22 Oranges"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.LEMON, label = "Collect 22 Lemons"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.CRATE, label = "Break 6 Garden Crates")
            ),
            starThresholds = Triple(3200, 4500, 5900),
            initialObstacles = mapOf(
                (1 to 3) to (ObstacleType.CRATE to 1),
                (2 to 2) to (ObstacleType.CRATE to 1),
                (2 to 4) to (ObstacleType.CRATE to 1),
                (4 to 2) to (ObstacleType.CRATE to 1),
                (4 to 4) to (ObstacleType.CRATE to 1),
                (5 to 3) to (ObstacleType.CRATE to 1)
            )
        ),
        LevelDefinition(
            levelNumber = 18,
            title = "Watermelon Chill",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3CitrusFruits,
            maxMoves = 26,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.ICE, label = "Clear 8 Double-Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 24, fruitType = FruitType.WATERMELON, label = "Collect 24 Watermelons")
            ),
            starThresholds = Triple(3200, 4600, 6100),
            initialObstacles = iceGrid(
                1 to 2, 1 to 4, 2 to 2, 2 to 4,
                4 to 2, 4 to 4, 5 to 2, 5 to 4,
                hp = 2
            ),
            tutorialTip = "Double Frost takes two matches to melt!"
        ),
        LevelDefinition(
            levelNumber = 19,
            title = "Papaya Pathways",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3IslandFruits,
            maxMoves = 27,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 4, obstacleType = ObstacleType.CRATE, label = "Break 4 Garden Crates"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 20, fruitType = FruitType.PAPAYA, label = "Collect 20 Papayas"),
                LevelObjective(ObjectiveKind.SCORE, 3600, label = "Reach 3,600 points")
            ),
            starThresholds = Triple(3600, 5000, 6500),
            initialObstacles = mapOf(
                (1 to 1) to (ObstacleType.CRATE to 1),
                (1 to 5) to (ObstacleType.CRATE to 1),
                (5 to 1) to (ObstacleType.CRATE to 1),
                (5 to 5) to (ObstacleType.CRATE to 1),
                (2 to 3) to (ObstacleType.VINES to 1),
                (3 to 2) to (ObstacleType.VINES to 1),
                (3 to 4) to (ObstacleType.VINES to 1),
                (4 to 3) to (ObstacleType.VINES to 1)
            )
        ),
        LevelDefinition(
            levelNumber = 20,
            title = "Coconut Grove",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3IslandFruits,
            maxMoves = 28,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.COCONUT, label = "Collect 22 Coconuts"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 4, obstacleType = ObstacleType.CRATE, label = "Break 4 Garden Crates"),
                LevelObjective(ObjectiveKind.TRIGGER_GOLDEN_WAVE, 3, label = "Trigger 3 Special Waves")
            ),
            starThresholds = Triple(3800, 5300, 7000),
            initialObstacles = combineObstacles(
                iceGrid(1 to 3, 2 to 2, 2 to 4, 3 to 1, 3 to 5, 4 to 2, 4 to 4, 5 to 3),
                mapOf(
                    (2 to 3) to (ObstacleType.CRATE to 1),
                    (3 to 2) to (ObstacleType.CRATE to 1),
                    (3 to 4) to (ObstacleType.CRATE to 1),
                    (4 to 3) to (ObstacleType.CRATE to 1)
                )
            )
        ),
        LevelDefinition(
            levelNumber = 21,
            title = "Mango Sunset",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3IslandFruits,
            maxMoves = 26,
            objectives = listOf(
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.MANGO, label = "Collect 22 Mangoes"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.PEACH, label = "Collect 22 Peaches")
            ),
            starThresholds = Triple(3500, 5000, 6600)
        ),
        LevelDefinition(
            levelNumber = 22,
            title = "Coral Canopy",
            chapter = Chapter.TROPICAL_PARADISE,
            rows = 7, cols = 7,
            availableFruits = world3CitrusFruits,
            maxMoves = 27,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.VINES, label = "Clear 8 Vines"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 24, fruitType = FruitType.BANANA, label = "Collect 24 Bananas")
            ),
            starThresholds = Triple(3700, 5200, 6800),
            initialObstacles = mapOf(
                (1 to 2) to (ObstacleType.VINES to 1),
                (1 to 4) to (ObstacleType.VINES to 1),
                (2 to 1) to (ObstacleType.VINES to 1),
                (2 to 5) to (ObstacleType.VINES to 1),
                (4 to 1) to (ObstacleType.VINES to 1),
                (4 to 5) to (ObstacleType.VINES to 1),
                (5 to 2) to (ObstacleType.VINES to 1),
                (5 to 4) to (ObstacleType.VINES to 1)
            )
        ),

        // ================= WORLD 4: BLOSSOM VALLEY (23–30) =================
        LevelDefinition(
            levelNumber = 23,
            title = "Kiwi Blossom",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 7, cols = 7,
            availableFruits = world4ExoticFruits,
            maxMoves = 28,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 10, obstacleType = ObstacleType.ICE, label = "Clear 10 Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 22, fruitType = FruitType.KIWI, label = "Collect 22 Kiwis")
            ),
            starThresholds = Triple(3900, 5500, 7200),
            initialObstacles = combineObstacles(
                iceGrid(1 to 1, 1 to 5, 5 to 1, 5 to 5, hp = 1),
                iceGrid(2 to 2, 2 to 4, 3 to 3, 4 to 2, 4 to 4, 3 to 2, hp = 2)
            ),
            tutorialTip = "Welcome to Blossom Valley! Exotic Dragon Fruit, Kiwis & Passion Fruit await!"
        ),
        LevelDefinition(
            levelNumber = 24,
            title = "Passion Treasury",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 7, cols = 7,
            availableFruits = world4ExoticFruits,
            maxMoves = 28,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.CRATE, label = "Break 6 Garden Crates"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 24, fruitType = FruitType.PASSION_FRUIT, label = "Collect 24 Passion Fruit"),
                LevelObjective(ObjectiveKind.SCORE, 4200, label = "Reach 4,200 points")
            ),
            starThresholds = Triple(4200, 5800, 7500),
            initialObstacles = mapOf(
                (1 to 3) to (ObstacleType.CRATE to 1),
                (2 to 2) to (ObstacleType.CRATE to 1),
                (2 to 4) to (ObstacleType.CRATE to 1),
                (4 to 2) to (ObstacleType.CRATE to 1),
                (4 to 4) to (ObstacleType.CRATE to 1),
                (5 to 3) to (ObstacleType.CRATE to 1)
            )
        ),
        LevelDefinition(
            levelNumber = 25,
            title = "Crown Gazebo",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 8, cols = 8,
            availableFruits = world4ExoticFruits,
            maxMoves = 28,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.ICE, label = "Clear 8 Frost tiles"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.VINES, label = "Clear 6 Vines"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 26, fruitType = FruitType.DRAGON_FRUIT, label = "Collect 26 Dragon Fruit")
            ),
            starThresholds = Triple(4500, 6200, 8000),
            initialObstacles = combineObstacles(
                iceGrid(1 to 1, 1 to 6, 2 to 2, 2 to 5, 5 to 2, 5 to 5, 6 to 1, 6 to 6),
                mapOf(
                    (3 to 3) to (ObstacleType.VINES to 1),
                    (3 to 4) to (ObstacleType.VINES to 1),
                    (4 to 3) to (ObstacleType.VINES to 1),
                    (4 to 4) to (ObstacleType.VINES to 1),
                    (2 to 3) to (ObstacleType.VINES to 1),
                    (5 to 4) to (ObstacleType.VINES to 1)
                )
            ),
            tutorialTip = "8×8 Royal Boards unlock huge cascades and Magic Peach blasts!"
        ),
        LevelDefinition(
            levelNumber = 26,
            title = "Avocado Brook",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 8, cols = 8,
            availableFruits = world4ExoticFruits,
            maxMoves = 28,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 12, obstacleType = ObstacleType.ICE, label = "Clear 12 Frost tiles"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 26, fruitType = FruitType.AVOCADO, label = "Collect 26 Avocados")
            ),
            starThresholds = Triple(4600, 6400, 8200),
            initialObstacles = iceGrid(
                1 to 2, 1 to 3, 1 to 4, 1 to 5,
                3 to 1, 3 to 6, 4 to 1, 4 to 6,
                6 to 2, 6 to 3, 6 to 4, 6 to 5
            )
        ),
        LevelDefinition(
            levelNumber = 27,
            title = "Ruby Pomegranate",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 8, cols = 8,
            availableFruits = world4ExoticFruits,
            maxMoves = 29,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.CRATE, label = "Break 8 Garden Crates"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 26, fruitType = FruitType.POMEGRANATE, label = "Collect 26 Pomegranates")
            ),
            starThresholds = Triple(4900, 6800, 8800),
            initialObstacles = mapOf(
                (1 to 2) to (ObstacleType.CRATE to 1),
                (1 to 5) to (ObstacleType.CRATE to 1),
                (2 to 1) to (ObstacleType.CRATE to 1),
                (2 to 6) to (ObstacleType.CRATE to 1),
                (5 to 1) to (ObstacleType.CRATE to 1),
                (5 to 6) to (ObstacleType.CRATE to 1),
                (6 to 2) to (ObstacleType.CRATE to 1),
                (6 to 5) to (ObstacleType.CRATE to 1)
            )
        ),
        LevelDefinition(
            levelNumber = 28,
            title = "Crystal Crown",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 8, cols = 8,
            availableFruits = world4FinaleFruits,
            maxMoves = 30,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 10, obstacleType = ObstacleType.ICE, label = "Clear 10 Frost tiles"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.VINES, label = "Clear 8 Vines"),
                LevelObjective(ObjectiveKind.SCORE, 5200, label = "Reach 5,200 points")
            ),
            starThresholds = Triple(5200, 7200, 9200),
            initialObstacles = combineObstacles(
                iceGrid(1 to 3, 1 to 4, 2 to 2, 2 to 5, 5 to 2, 5 to 5, 6 to 3, 6 to 4, hp = 2),
                iceGrid(3 to 1, 4 to 6, hp = 1),
                mapOf(
                    (3 to 3) to (ObstacleType.VINES to 1),
                    (3 to 4) to (ObstacleType.VINES to 1),
                    (4 to 3) to (ObstacleType.VINES to 1),
                    (4 to 4) to (ObstacleType.VINES to 1),
                    (2 to 3) to (ObstacleType.VINES to 1),
                    (2 to 4) to (ObstacleType.VINES to 1),
                    (5 to 3) to (ObstacleType.VINES to 1),
                    (5 to 4) to (ObstacleType.VINES to 1)
                )
            )
        ),
        LevelDefinition(
            levelNumber = 29,
            title = "Festival Eve",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 8, cols = 8,
            availableFruits = world4FinaleFruits,
            maxMoves = 30,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.CRATE, label = "Break 6 Garden Crates"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 28, fruitType = FruitType.PEACH, label = "Collect 28 Peaches"),
                LevelObjective(ObjectiveKind.TRIGGER_GOLDEN_WAVE, 4, label = "Trigger 4 Special Waves")
            ),
            starThresholds = Triple(5600, 7600, 9800),
            initialObstacles = combineObstacles(
                iceGrid(2 to 3, 2 to 4, 5 to 3, 5 to 4),
                mapOf(
                    (1 to 1) to (ObstacleType.CRATE to 1),
                    (1 to 6) to (ObstacleType.CRATE to 1),
                    (3 to 2) to (ObstacleType.CRATE to 1),
                    (4 to 5) to (ObstacleType.CRATE to 1),
                    (6 to 1) to (ObstacleType.CRATE to 1),
                    (6 to 6) to (ObstacleType.CRATE to 1)
                )
            )
        ),
        LevelDefinition(
            levelNumber = 30,
            title = "Blossom Kingdom",
            chapter = Chapter.BLOSSOM_VALLEY,
            rows = 8, cols = 8,
            availableFruits = world4FinaleFruits,
            maxMoves = 32,
            objectives = listOf(
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 8, obstacleType = ObstacleType.ICE, label = "Clear 8 Frost tiles"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 6, obstacleType = ObstacleType.VINES, label = "Clear 6 Vines"),
                LevelObjective(ObjectiveKind.CLEAR_OBSTACLE, 4, obstacleType = ObstacleType.CRATE, label = "Break 4 Garden Crates"),
                LevelObjective(ObjectiveKind.COLLECT_FRUIT, 32, fruitType = FruitType.PEACH, label = "Collect 32 Peaches")
            ),
            starThresholds = Triple(6200, 8500, 11000),
            initialObstacles = combineObstacles(
                iceGrid(1 to 2, 1 to 5, 2 to 1, 2 to 6, 5 to 1, 5 to 6, 6 to 2, 6 to 5, hp = 2),
                mapOf(
                    (3 to 2) to (ObstacleType.CRATE to 1),
                    (3 to 5) to (ObstacleType.CRATE to 1),
                    (4 to 2) to (ObstacleType.CRATE to 1),
                    (4 to 5) to (ObstacleType.CRATE to 1),
                    (2 to 3) to (ObstacleType.VINES to 1),
                    (2 to 4) to (ObstacleType.VINES to 1),
                    (3 to 3) to (ObstacleType.VINES to 1),
                    (4 to 4) to (ObstacleType.VINES to 1),
                    (5 to 3) to (ObstacleType.VINES to 1),
                    (5 to 4) to (ObstacleType.VINES to 1)
                )
            ),
            tutorialTip = "The Blossom Valley Finale! Bring all 24 orchard fruits together!"
        )
    )

    fun getLevel(levelNumber: Int): LevelDefinition =
        allLevels.find { it.levelNumber == levelNumber } ?: allLevels.first()
}

data class DailyRewardItem(
    val dayNumber: Int,
    val title: String,
    val rewardSummary: String,
    val bonusPoints: Int
)

object OrchardCatalog {

    val gardenSections = listOf(
        GardenSection(0, "Sunny Sprout Gate", "The sunlit golden archway of Peach Quest", 0),
        GardenSection(1, "Peach Blossom Trees", "Unlocked at 5 levels — blooming pink & orange trees", 5),
        GardenSection(2, "Berry Woods Patch", "Unlocked at 10 levels — sweet berries & wildflowers", 10),
        GardenSection(3, "Crystal Brook Pathway", "Unlocked at 15 levels — sunlit stepping stones & clear stream", 15),
        GardenSection(4, "Fluttering Butterflies", "Unlocked at 20 levels — glowing magical butterflies", 20),
        GardenSection(5, "Golden Peach Fountain", "Unlocked at 25 levels — sparkling golden centerpiece", 25),
        GardenSection(6, "Blossom Valley Pavilion", "Unlocked at 30 levels — complete celebratory kingdom!", 30)
    )

    val achievements = listOf(
        AchievementDefinition(
            id = "first_harvest",
            title = "First Harvest",
            description = "Complete your very first Peach Quest level",
            rewardText = "Meadow Ribbon"
        ),
        AchievementDefinition(
            id = "star_collector",
            title = "Star Collector",
            description = "Earn at least 10 Stars across the garden",
            rewardText = "Crystal Sparkle Style"
        ),
        AchievementDefinition(
            id = "golden_chef",
            title = "Magic Peach Splash",
            description = "Trigger a Special Fruit Wave during gameplay",
            rewardText = "Golden Crown Badge"
        ),
        AchievementDefinition(
            id = "combo_master",
            title = "Cascade Wizard",
            description = "Chain a 3x cascade combo or higher",
            rewardText = "Combo Emblem"
        ),
        AchievementDefinition(
            id = "royal_harvester",
            title = "Sunbeam Harvester",
            description = "Earn 25 Stars to unlock the Sunbeam Halo style",
            rewardText = "Sunbeam Halo Style"
        ),
        AchievementDefinition(
            id = "bloom_champion",
            title = "Garden Legend",
            description = "Complete 15 levels in Peach Quest",
            rewardText = "Master Gardener Seal"
        )
    )

    val dailyRewards = listOf(
        DailyRewardItem(1, "Day 1", "Rainbow Booster +1", 150),
        DailyRewardItem(2, "Day 2", "Bomb Booster +1", 250),
        DailyRewardItem(3, "Day 3", "Lightning Booster +1", 350),
        DailyRewardItem(4, "Day 4", "Magic Peach +1", 450),
        DailyRewardItem(5, "Day 5", "Rainbow & Bomb +1", 600),
        DailyRewardItem(6, "Day 6", "Lightning & Magic Peach +1", 800),
        DailyRewardItem(7, "Day 7", "All 4 Boosters +1!", 1200)
    )
}
