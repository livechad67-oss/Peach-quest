package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.SoundCue
import com.example.ui.AppScreen
import com.example.ui.PeachQuestViewModel
import com.example.ui.screens.FruitVaultScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.GardenRevealScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LegalDocumentScreen
import com.example.ui.screens.LevelMapScreen
import com.example.ui.screens.LoadingScreen
import com.example.ui.screens.OwnerDashboardScreen
import com.example.ui.screens.PeachGardenScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UsernameScreen
import com.example.ui.theme.PeachQuestTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PeachQuestViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PeachQuestTheme {
                PeachQuestRoot(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun PeachQuestRoot(viewModel: PeachQuestViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val activity = context as? Activity

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewModel.onForegroundChanged(true)
                Lifecycle.Event.ON_PAUSE -> viewModel.onForegroundChanged(false)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(state.currentScreen) {
        if (state.currentScreen == AppScreen.Game) {
            var lastNs = 0L
            var frames = 0
            var accumNs = 0L
            while (true) {
                val frameNs = withFrameNanos { it }
                if (lastNs != 0L) {
                    accumNs += (frameNs - lastNs)
                    frames += 1
                    if (frames >= 45 && accumNs > 0L) {
                        val fps = (frames * 1_000_000_000.0 / accumNs).toFloat()
                        viewModel.reportEstimatedFps(fps)
                        frames = 0
                        accumNs = 0L
                    }
                }
                lastNs = frameNs
            }
        }
    }

    val effectiveQuality = viewModel.effectiveGraphicsQuality()
    val animDuration = if (state.settings.animationsEnabled) 300 else 60

    AnimatedContent(
        targetState = state.currentScreen,
        transitionSpec = {
            (fadeIn(tween(animDuration, easing = androidx.compose.animation.core.FastOutSlowInEasing)) + scaleIn(
                initialScale = 0.95f,
                animationSpec = tween(animDuration, easing = androidx.compose.animation.core.FastOutSlowInEasing)
            )) togetherWith (fadeOut(tween(animDuration / 2, easing = androidx.compose.animation.core.FastOutSlowInEasing)) + scaleOut(
                targetScale = 1.02f,
                animationSpec = tween(animDuration / 2, easing = androidx.compose.animation.core.FastOutSlowInEasing)
            ))
        },
        label = "peach_quest_screen_transition"
    ) { screen ->
        when (screen) {
            AppScreen.Loading -> LoadingScreen(
                progress = state.loadingProgress,
                statusText = state.loadingStatus,
                errorText = state.loadingError,
                animationsEnabled = state.settings.animationsEnabled,
                onRetry = { viewModel.initializeApp() },
                onResetFresh = { viewModel.recoverWithFreshState() }
            )

            AppScreen.UsernameOnboarding -> UsernameScreen(
                initialUsername = state.progress.playerUsername,
                initialLegalAccepted = state.progress.legalAccepted,
                initialAnalyticsConsent = state.settings.analyticsConsent,
                errorText = state.onboardingError,
                animationsEnabled = state.settings.animationsEnabled,
                graphicsQuality = effectiveQuality,
                onClearError = { viewModel.clearOnboardingError() },
                onOpenDoc = { doc -> viewModel.openLegalDocument(doc) },
                onSubmit = { name, legal, analytics ->
                    viewModel.completeUsernameOnboarding(name, legal, analytics)
                }
            )

            AppScreen.GardenReveal -> GardenRevealScreen(
                username = state.progress.playerUsername,
                animationsEnabled = state.settings.animationsEnabled,
                graphicsQuality = effectiveQuality,
                onFinish = { viewModel.finishGardenReveal() }
            )

            AppScreen.Home -> HomeScreen(
                progress = state.progress,
                settings = state.settings,
                graphicsQuality = effectiveQuality,
                onPlayClick = { viewModel.startOrResumeCurrentLevel() },
                onLevelMapClick = { viewModel.navigateTo(AppScreen.LevelMap) },
                onProfileClick = { viewModel.navigateTo(AppScreen.FruitVault) },
                onSettingsClick = { viewModel.navigateTo(AppScreen.Settings) },
                onOpenOwnerConsole = { viewModel.navigateTo(AppScreen.OwnerDashboard) }
            )

            AppScreen.LevelMap -> LevelMapScreen(
                progress = state.progress,
                settings = state.settings,
                graphicsQuality = effectiveQuality,
                canClaimDaily = viewModel.canClaimDailyReward(),
                onClaimDailyReward = { viewModel.claimDailyReward() },
                onOpenGarden = { viewModel.navigateTo(AppScreen.PeachGarden) },
                onOpenVault = { viewModel.navigateTo(AppScreen.FruitVault) },
                onSelectLevel = { lvl -> viewModel.startLevel(lvl) },
                onBack = { viewModel.navigateBack() }
            )

            AppScreen.Game -> GameScreen(
                game = state.game,
                progress = state.progress,
                settings = state.settings,
                graphicsQuality = effectiveQuality,
                objectiveProgress = { obj -> viewModel.objectiveProgress(obj, state.game) },
                onDismissMechanicTip = { viewModel.dismissMechanicTip() },
                onDismissTutorial = { viewModel.dismissTutorial() },
                onSelectBooster = { booster -> viewModel.selectBooster(booster) },
                onTileTapped = { r, c -> viewModel.onTileTapped(r, c) },
                onTileSwiped = { r, c, dr, dc -> viewModel.onTileSwiped(r, c, dr, dc) },
                onHintClick = { viewModel.showHintNow() },
                onPauseClick = { viewModel.pauseGame() },
                onResumeClick = { viewModel.resumeGame() },
                onRestartLevel = { viewModel.startLevel(state.game.level.levelNumber) },
                onNextLevel = { nextLvl -> viewModel.startLevel(nextLvl) },
                onExitToHome = { viewModel.exitGameToHome() },
                onOpenLevelMap = { viewModel.navigateTo(AppScreen.LevelMap) },
                onOpenGarden = { viewModel.navigateTo(AppScreen.PeachGarden) }
            )

            AppScreen.PeachGarden -> PeachGardenScreen(
                progress = state.progress,
                settings = state.settings,
                graphicsQuality = effectiveQuality,
                onBack = { viewModel.navigateBack() }
            )

            AppScreen.FruitVault -> FruitVaultScreen(
                progress = state.progress,
                settings = state.settings,
                graphicsQuality = effectiveQuality,
                canClaimDaily = viewModel.canClaimDailyReward(),
                onClaimDailyReward = { viewModel.claimDailyReward() },
                onSelectSkin = { skin -> viewModel.selectFruitSkin(skin) },
                onTabChanged = { viewModel.soundManager.playSfx(SoundCue.TAB_SWITCH) },
                onBack = { viewModel.navigateBack() }
            )

            AppScreen.Settings -> SettingsScreen(
                playerUsername = state.progress.playerUsername,
                settings = state.settings,
                effectiveGraphicsQuality = effectiveQuality,
                onToggleMusic = { enabled -> viewModel.setMusicEnabled(enabled) },
                onToggleSfx = { enabled -> viewModel.setSfxEnabled(enabled) },
                onUpdateUsername = { raw -> viewModel.updateDisplayUsername(raw) },
                onOpenLegalDoc = { doc -> viewModel.openLegalDocument(doc) },
                onResetProgress = { clearUsername -> viewModel.resetProgress(clearUsername) },
                onBack = { viewModel.navigateBack() }
            )

            AppScreen.OwnerDashboard -> OwnerDashboardScreen(
                ownerAuth = state.ownerAuth,
                analyticsSdkConnected = state.analyticsSdkConnected,
                analyticsConsentEnabled = state.settings.analyticsConsent,
                deviceTelemetry = state.deviceTelemetry,
                settings = state.settings,
                graphicsQuality = effectiveQuality,
                onSignInOwner = {
                    if (activity != null) viewModel.signInOwner(activity)
                },
                onVerifyFirestore = { viewModel.verifyOwnerFirestoreAccess() },
                onSignOutOwner = { viewModel.signOutOwner(context) },
                onBack = { viewModel.navigateBack() }
            )

            is AppScreen.LegalDocument -> LegalDocumentScreen(
                docType = screen.docType,
                onBack = { viewModel.navigateBack() }
            )
        }
    }
}
