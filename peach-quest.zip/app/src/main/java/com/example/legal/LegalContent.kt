package com.example.legal

object LegalContent {

    const val SUPPORT_CONTACT_PLACEHOLDER = "[DEVELOPER_CONTACT_EMAIL — e.g., support@clastad.example]"
    const val PRIVACY_URL_PLACEHOLDER = "[PUBLIC_HTTPS_PRIVACY_POLICY_URL]"
    const val JURISDICTION_PLACEHOLDER = "[APPLICABLE_COUNTRY_OR_STATE_TO_BE_CONFIRMED_BY_CLASTAD]"

    val privacyPolicyText = """
        PEACH QUEST — PRIVACY INFORMATION
        From CLASTAD
        Last Updated: November 2026

        IMPORTANT NOTE:
        This summary explains how Peach Quest by CLASTAD handles information in clear, plain language. Publishing these pages inside the app does not by itself guarantee legal compliance in every country or store; review and host an official public policy before commercial distribution.

        1. NO ACCOUNT OR LOGIN REQUIRED FOR PLAYERS
        Peach Quest is a cheerful, offline-friendly puzzle adventure. Players are NEVER asked to create an account, enter an email address, set a password, or sign in with Google to play.

        2. WHAT INFORMATION IS STORED LOCALLY ON YOUR DEVICE
        • Your chosen username (stored locally so the garden greets you across sessions without re-entering it). Your local username does NOT create an account, provide authentication, or sync progress across devices.
        • Your level progress, star ratings, high scores, booster inventory, board snapshots, and audio settings (stored locally on this device only).

        3. OPTIONAL AGGREGATED USAGE ANALYTICS
        • When enabled, Peach Quest uses Firebase Analytics to record aggregated gameplay counts (such as app opens, session duration, and level completion counts) to help improve level balance and stability.
        • Peach Quest never collects your username in analytics events, never collects precise GPS location, and never requests camera, microphone, contacts, or photo storage permissions.
        • Zero third-party ads or targeted advertising SDKs.

        4. ADMINISTRATOR ACCESS (OWNER CONSOLE ONLY)
        • The private Owner Dashboard is restricted strictly to allowlisted CLASTAD administrators using verified Google Sign-In via Firebase Authentication and server-side Firestore security rules. Ordinary players cannot access or view this dashboard.

        5. HOW TO RESET OR DELETE YOUR LOCAL DATA
        • Open Settings -> "Reset Local Progress" to erase your saved progress and/or reset your local username on this device.
        • Uninstalling Peach Quest or clearing app storage in Android System Settings also removes all local game data immediately.

        6. CONTACT
        Developer: CLASTAD
        Email: $SUPPORT_CONTACT_PLACEHOLDER
        Public Policy URL: $PRIVACY_URL_PLACEHOLDER
    """.trimIndent()

    val termsOfServiceText = """
        PEACH QUEST — TERMS OF USE
        From CLASTAD
        Last Updated: November 2026

        NOTE: This document describes fair rules for playing Peach Quest and is not a substitute for independent legal advice or jurisdiction-specific compliance review.

        1. PERMITTED PERSONAL USE
        CLASTAD grants you a personal, non-exclusive, revocable, non-transferable licence to play Peach Quest on compatible devices for personal, non-commercial entertainment.

        2. LOCAL SAVES & DISPLAY USERNAMES
        • Your username and level progress are stored locally on your device. Because no player account or cloud sync is used, uninstalling the app or resetting local progress permanently deletes your saved progress on that device.
        • Please choose a friendly, appropriate username that follows our Player Conduct Policy.

        3. ACCEPTABLE USE
        You agree not to tamper with, reverse engineer (except where permitted by law), bypass security controls, or attempt unauthorized access to the CLASTAD Owner Console or backend services.

        4. INTELLECTUAL PROPERTY
        All original Peach Quest game code, visual designs, garden artwork, fairy soundtrack, and sound effects remain the property of CLASTAD or their respective open-source/font licensors.

        5. DISCLAIMER & UPDATES
        Peach Quest is provided "as is" and may receive balance updates, new levels, or fixes over time. Mandatory statutory consumer rights in your jurisdiction remain unaffected.

        6. GOVERNING LAW & CONTACT
        Subject to mandatory local consumer laws, these Terms are governed by the laws of $JURISDICTION_PLACEHOLDER.
        Contact: $SUPPORT_CONTACT_PLACEHOLDER
    """.trimIndent()

    val conductPolicyText = """
        PEACH QUEST — PLAYER CONDUCT POLICY
        From CLASTAD

        Peach Quest is built to be a warm, welcoming, family-friendly puzzle adventure:

        1. KEEP USERNAMES FRIENDLY
        • Choose a respectful username (3–18 characters).
        • Profanity, slurs, hateful language, sexually explicit terms, harassment, and impersonation of CLASTAD staff or administrators are not permitted and will be rejected by username validation.

        2. FAIR PLAY
        • Enjoy puzzles honestly without tampering with app binaries or attempting unauthorized access to owner-only administrative endpoints.

        3. NO PUBLIC CHAT OR SHARING RISK
        • Peach Quest has no public chat, user-to-user messaging, or public player leaderboards, keeping casual play peaceful and private for all ages.
    """.trimIndent()

    val creditsText = """
        PEACH QUEST — CREDITS & LICENCES
        From CLASTAD

        • Design, Gameplay & Visuals: Original Peach Quest garden interface, water channels, 3D cartoon fruit artwork, and animated butterflies rendered natively in Jetpack Compose.
        • Original Audio & Fairy Soundtrack: Synthesized enchanted-garden instrumental soundtrack (celesta, harp, ambient pads, water stream) and bubbly droplet SFX created natively in Kotlin.
        • Typography: Fredoka & Nunito (SIL Open Font License 1.1) via Google Fonts.
        • Android & Cloud Services: Jetpack Compose, Material 3, AndroidX, Kotlin Coroutines, Firebase Analytics, Firebase Authentication (admin-only), and Cloud Firestore (admin-only) under Apache License 2.0.
    """.trimIndent()
}
