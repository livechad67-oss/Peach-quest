package com.example.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppSettings
import com.example.model.BoosterType
import com.example.model.DeviceTelemetrySummary
import com.example.model.FruitSkin
import com.example.model.FruitType
import com.example.model.GraphicsQuality
import com.example.model.LevelResult
import com.example.model.ObstacleType
import com.example.model.PlayerProgress
import com.example.model.SavedBoardSnapshot
import com.example.model.SpecialKind
import com.example.model.TileCell
import org.json.JSONArray
import org.json.JSONObject

class LocalStorageRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadProgress(): PlayerProgress {
        return try {
            val raw = prefs.getString(KEY_PROGRESS, null) ?: return PlayerProgress()
            val obj = JSONObject(raw)
            val playerUsername = obj.optString("playerUsername", "")
            val legalAccepted = obj.optBoolean("legalAccepted", false)
            val tutorialCompleted = obj.optBoolean("tutorialCompleted", false)
            val highestUnlocked = obj.optInt("highestUnlockedLevel", 1).coerceIn(1, 30)
            val dailyStreak = obj.optInt("dailyStreak", 0).coerceAtLeast(0)
            val lastDailyClaimDay = obj.optInt("lastDailyClaimDay", 0).coerceAtLeast(0)
            val selectedFruitSkin = obj.optString("selectedFruitSkin", FruitSkin.CLASSIC.id)
                .ifBlank { FruitSkin.CLASSIC.id }

            val unlockedSkins = mutableListOf<String>()
            val skinsArr = obj.optJSONArray("unlockedFruitSkins")
            if (skinsArr != null) {
                for (i in 0 until skinsArr.length()) {
                    val s = skinsArr.optString(i, "")
                    if (s.isNotBlank() && s !in unlockedSkins) unlockedSkins.add(s)
                }
            }
            if (FruitSkin.CLASSIC.id !in unlockedSkins) {
                unlockedSkins.add(0, FruitSkin.CLASSIC.id)
            }

            val unlockedAchievements = mutableListOf<String>()
            val achArr = obj.optJSONArray("unlockedAchievements")
            if (achArr != null) {
                for (i in 0 until achArr.length()) {
                    val a = achArr.optString(i, "")
                    if (a.isNotBlank() && a !in unlockedAchievements) unlockedAchievements.add(a)
                }
            }

            val seenMechanics = mutableSetOf<String>()
            val mechArr = obj.optJSONArray("seenMechanics")
            if (mechArr != null) {
                for (i in 0 until mechArr.length()) {
                    val m = mechArr.optString(i, "")
                    if (m.isNotBlank()) seenMechanics.add(m)
                }
            }

            val boosterInventory = BoosterType.defaultStarterInventory().toMutableMap()
            val boostersObj = obj.optJSONObject("boosterInventory")
            if (boostersObj != null) {
                BoosterType.entries.forEach { b ->
                    if (boostersObj.has(b.name)) {
                        boosterInventory[b] = boostersObj.optInt(b.name, 0).coerceAtLeast(0)
                    }
                }
            }

            val resultsMap = mutableMapOf<Int, LevelResult>()
            val resultsObj = obj.optJSONObject("levelResults")
            if (resultsObj != null) {
                val keys = resultsObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val levelNum = key.toIntOrNull() ?: continue
                    val item = resultsObj.optJSONObject(key) ?: continue
                    resultsMap[levelNum] = LevelResult(
                        levelNumber = levelNum,
                        stars = item.optInt("stars", 0).coerceIn(0, 3),
                        highScore = item.optInt("highScore", 0).coerceAtLeast(0),
                        bestCombo = item.optInt("bestCombo", 1).coerceAtLeast(1)
                    )
                }
            }

            val snapshotObj = obj.optJSONObject("activeSnapshot")
            val snapshot = snapshotObj?.let { decodeSnapshot(it) }

            PlayerProgress(
                playerUsername = playerUsername,
                legalAccepted = legalAccepted,
                tutorialCompleted = tutorialCompleted,
                highestUnlockedLevel = highestUnlocked,
                levelResults = resultsMap,
                dailyStreak = dailyStreak,
                lastDailyClaimDay = lastDailyClaimDay,
                unlockedFruitSkins = unlockedSkins,
                selectedFruitSkin = selectedFruitSkin,
                unlockedAchievements = unlockedAchievements,
                boosterInventory = boosterInventory,
                seenMechanics = seenMechanics,
                activeSnapshot = snapshot
            )
        } catch (_: Exception) {
            PlayerProgress()
        }
    }

    fun saveProgress(progress: PlayerProgress) {
        val obj = JSONObject().apply {
            put("playerUsername", progress.playerUsername)
            put("legalAccepted", progress.legalAccepted)
            put("tutorialCompleted", progress.tutorialCompleted)
            put("highestUnlockedLevel", progress.highestUnlockedLevel)
            put("dailyStreak", progress.dailyStreak)
            put("lastDailyClaimDay", progress.lastDailyClaimDay)
            put("selectedFruitSkin", progress.selectedFruitSkin)
            put("unlockedFruitSkins", JSONArray(progress.unlockedFruitSkins))
            put("unlockedAchievements", JSONArray(progress.unlockedAchievements))
            put("seenMechanics", JSONArray(progress.seenMechanics.toList()))

            val boostersObj = JSONObject()
            progress.boosterInventory.forEach { (b, count) ->
                boostersObj.put(b.name, count)
            }
            put("boosterInventory", boostersObj)

            val resultsObj = JSONObject()
            progress.levelResults.forEach { (levelNum, result) ->
                resultsObj.put(
                    levelNum.toString(),
                    JSONObject().apply {
                        put("stars", result.stars)
                        put("highScore", result.highScore)
                        put("bestCombo", result.bestCombo)
                    }
                )
            }
            put("levelResults", resultsObj)
            if (progress.activeSnapshot != null) {
                put("activeSnapshot", encodeSnapshot(progress.activeSnapshot))
            }
        }
        prefs.edit().putString(KEY_PROGRESS, obj.toString()).apply()
    }

    fun loadSettings(): AppSettings {
        return try {
            val raw = prefs.getString(KEY_SETTINGS, null) ?: return AppSettings()
            val obj = JSONObject(raw)
            val qualityName = obj.optString("graphicsQuality", GraphicsQuality.AUTO.name)
            val quality = GraphicsQuality.entries.find { it.name == qualityName } ?: GraphicsQuality.AUTO
            AppSettings(
                masterVolume = obj.optDouble("masterVolume", 0.85).toFloat().coerceIn(0f, 1f),
                musicVolume = obj.optDouble("musicVolume", 0.65).toFloat().coerceIn(0f, 1f),
                sfxVolume = obj.optDouble("sfxVolume", 0.85).toFloat().coerceIn(0f, 1f),
                muted = obj.optBoolean("muted", false),
                hapticEnabled = obj.optBoolean("hapticEnabled", true),
                animationsEnabled = obj.optBoolean("animationsEnabled", true),
                notificationsEnabled = obj.optBoolean("notificationsEnabled", true),
                colorblindSymbols = obj.optBoolean("colorblindSymbols", false),
                analyticsConsent = obj.optBoolean("analyticsConsent", false),
                graphicsQuality = quality
            )
        } catch (_: Exception) {
            AppSettings()
        }
    }

    fun saveSettings(settings: AppSettings) {
        val obj = JSONObject().apply {
            put("masterVolume", settings.masterVolume.toDouble())
            put("musicVolume", settings.musicVolume.toDouble())
            put("sfxVolume", settings.sfxVolume.toDouble())
            put("muted", settings.muted)
            put("hapticEnabled", settings.hapticEnabled)
            put("animationsEnabled", settings.animationsEnabled)
            put("notificationsEnabled", settings.notificationsEnabled)
            put("colorblindSymbols", settings.colorblindSymbols)
            put("analyticsConsent", settings.analyticsConsent)
            put("graphicsQuality", settings.graphicsQuality.name)
        }
        prefs.edit().putString(KEY_SETTINGS, obj.toString()).apply()
    }

    fun loadDeviceTelemetry(): DeviceTelemetrySummary {
        return try {
            val raw = prefs.getString(KEY_TELEMETRY, null) ?: return DeviceTelemetrySummary()
            val obj = JSONObject(raw)
            DeviceTelemetrySummary(
                firstOpenTimestampMs = obj.optLong("firstOpenTimestampMs", 0L),
                sessionCount = obj.optInt("sessionCount", 0),
                totalSessionDurationSec = obj.optLong("totalSessionDurationSec", 0L),
                levelStarts = decodeIntMap(obj.optJSONObject("levelStarts")),
                levelCompletes = decodeIntMap(obj.optJSONObject("levelCompletes")),
                levelFailures = decodeIntMap(obj.optJSONObject("levelFailures")),
                avgFpsEstimate = obj.optDouble("avgFpsEstimate", 0.0).toFloat(),
                nonFatalErrorCount = obj.optInt("nonFatalErrorCount", 0)
            )
        } catch (_: Exception) {
            DeviceTelemetrySummary()
        }
    }

    fun saveDeviceTelemetry(summary: DeviceTelemetrySummary) {
        val obj = JSONObject().apply {
            put("firstOpenTimestampMs", summary.firstOpenTimestampMs)
            put("sessionCount", summary.sessionCount)
            put("totalSessionDurationSec", summary.totalSessionDurationSec)
            put("levelStarts", encodeIntMap(summary.levelStarts))
            put("levelCompletes", encodeIntMap(summary.levelCompletes))
            put("levelFailures", encodeIntMap(summary.levelFailures))
            put("avgFpsEstimate", summary.avgFpsEstimate.toDouble())
            put("nonFatalErrorCount", summary.nonFatalErrorCount)
        }
        prefs.edit().putString(KEY_TELEMETRY, obj.toString()).apply()
    }

    fun resetProgressKeepLegal(legalAccepted: Boolean, playerUsername: String = ""): PlayerProgress {
        val reset = PlayerProgress(
            playerUsername = playerUsername,
            legalAccepted = legalAccepted,
            highestUnlockedLevel = 1
        )
        saveProgress(reset)
        return reset
    }

    fun wipeAllLocalPlayerData() {
        prefs.edit().remove(KEY_PROGRESS).remove(KEY_TELEMETRY).apply()
    }

    private fun encodeIntMap(map: Map<Int, Int>): JSONObject {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k.toString(), v) }
        return obj
    }

    private fun decodeIntMap(obj: JSONObject?): Map<Int, Int> {
        if (obj == null) return emptyMap()
        val out = mutableMapOf<Int, Int>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val intKey = k.toIntOrNull() ?: continue
            out[intKey] = obj.optInt(k, 0)
        }
        return out
    }

    private fun encodeSnapshot(snap: SavedBoardSnapshot): JSONObject {
        return JSONObject().apply {
            put("levelNumber", snap.levelNumber)
            put("rows", snap.rows)
            put("cols", snap.cols)
            put("movesRemaining", snap.movesRemaining)
            put("score", snap.score)
            put("goldenWavesTriggered", snap.goldenWavesTriggered)

            val fruitsObj = JSONObject()
            snap.collectedFruits.forEach { (f, count) -> fruitsObj.put(f.name, count) }
            put("collectedFruits", fruitsObj)

            val obsObj = JSONObject()
            snap.clearedObstacles.forEach { (o, count) -> obsObj.put(o.name, count) }
            put("clearedObstacles", obsObj)

            val cellsArr = JSONArray()
            snap.cells.forEach { cell ->
                cellsArr.put(JSONObject().apply {
                    put("id", cell.id)
                    put("row", cell.row)
                    put("col", cell.col)
                    put("fruit", cell.fruit?.name ?: "")
                    put("obstacle", cell.obstacle.name)
                    put("obstacleHp", cell.obstacleHp)
                    put("special", cell.special.name)
                    put("isVoid", cell.isVoid)
                    put("isWatered", cell.isWatered)
                })
            }
            put("cells", cellsArr)
        }
    }

    private fun decodeSnapshot(obj: JSONObject): SavedBoardSnapshot? {
        return try {
            val levelNum = obj.getInt("levelNumber")
            val rows = obj.getInt("rows")
            val cols = obj.getInt("cols")
            val moves = obj.getInt("movesRemaining")
            val score = obj.getInt("score")
            val waves = obj.optInt("goldenWavesTriggered", 0)

            val collectedFruits = mutableMapOf<FruitType, Int>()
            val fruitsObj = obj.optJSONObject("collectedFruits")
            if (fruitsObj != null) {
                val keys = fruitsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    FruitType.entries.find { it.name == k }?.let { f ->
                        collectedFruits[f] = fruitsObj.optInt(k, 0)
                    }
                }
            }

            val clearedObstacles = mutableMapOf<ObstacleType, Int>()
            val obsObj = obj.optJSONObject("clearedObstacles")
            if (obsObj != null) {
                val keys = obsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    ObstacleType.entries.find { it.name == k }?.let { o ->
                        clearedObstacles[o] = obsObj.optInt(k, 0)
                    }
                }
            }

            val cellsArr = obj.getJSONArray("cells")
            val cells = mutableListOf<TileCell>()
            for (i in 0 until cellsArr.length()) {
                val cObj = cellsArr.getJSONObject(i)
                val fName = cObj.optString("fruit", "")
                val fruit = if (fName.isEmpty()) null else FruitType.entries.find { it.name == fName }
                val oName = cObj.optString("obstacle", ObstacleType.NONE.name)
                val obs = ObstacleType.entries.find { it.name == oName } ?: ObstacleType.NONE
                val sName = cObj.optString("special", SpecialKind.NONE.name)
                val sp = SpecialKind.entries.find { it.name == sName } ?: SpecialKind.NONE
                cells.add(
                    TileCell(
                        id = cObj.getLong("id"),
                        row = cObj.getInt("row"),
                        col = cObj.getInt("col"),
                        fruit = fruit,
                        obstacle = obs,
                        obstacleHp = cObj.optInt("obstacleHp", 0),
                        special = sp,
                        isVoid = cObj.optBoolean("isVoid", false),
                        isWatered = cObj.optBoolean("isWatered", false)
                    )
                )
            }
            if (cells.size != rows * cols) return null
            SavedBoardSnapshot(
                levelNumber = levelNum,
                rows = rows,
                cols = cols,
                movesRemaining = moves,
                score = score,
                collectedFruits = collectedFruits,
                clearedObstacles = clearedObstacles,
                goldenWavesTriggered = waves,
                cells = cells
            )
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val PREFS_NAME = "clastad_local_store"
        private const val KEY_PROGRESS = "player_progress_v3"
        private const val KEY_SETTINGS = "app_settings_v3"
        private const val KEY_TELEMETRY = "device_telemetry_v1"
    }
}
