const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "admin_owner_1";
const ADMIN_EMAIL = "livechad67@gmail.com";
const PLAYER_UID = "player_regular_1";
const PLAYER_EMAIL = "someone@example.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validAdminSnapshot(uid, created, updated) {
  return {
    metricKey: "overview",
    sourceNote: "Owner verification snapshot",
    updatedByUid: uid,
    createdAt: created,
    updatedAt: updated,
  };
}

test("Unauthenticated users and non-allowlisted accounts are denied from /adminMetrics", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const nonAdminDb = testEnv.authenticatedContext(PLAYER_UID, {
    email: PLAYER_EMAIL,
    email_verified: true,
  }).firestore();
  const unverifiedAdminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();

  const now = new Date(Date.now() - 1000);
  await assertFails(unauthDb.collection("adminMetrics").get());
  await assertFails(unauthDb.collection("adminMetrics").doc("overview").set(validAdminSnapshot(PLAYER_UID, now, now)));
  await assertFails(nonAdminDb.collection("adminMetrics").get());
  await assertFails(nonAdminDb.collection("adminMetrics").doc("overview").set(validAdminSnapshot(PLAYER_UID, now, now)));
  await assertFails(unverifiedAdminDb.collection("adminMetrics").get());
});

test("Allowlisted verified admin can create, read, and update /adminMetrics", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const created = new Date(Date.now() - 5000);
  const updated = new Date(Date.now() - 1000);

  await assertSucceeds(
    adminDb.collection("adminMetrics").doc("overview").set(validAdminSnapshot(ADMIN_UID, created, created))
  );

  await assertSucceeds(
    adminDb.collection("adminMetrics").doc("overview").update({
      sourceNote: "Verified Firebase Console connection",
      updatedAt: updated,
    })
  );

  await assertSucceeds(adminDb.collection("adminMetrics").get());
});

test("Rejects ghost fields and legacy player collections", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 1000);

  await assertFails(
    adminDb.collection("adminMetrics").doc("overview").set({
      ...validAdminSnapshot(ADMIN_UID, now, now),
      extraField: "not_allowed",
    })
  );

  await assertFails(adminDb.collection("users").doc(PLAYER_UID).get());
});
